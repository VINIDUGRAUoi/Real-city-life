# Créditos e licenças

## Modelos 3D de veículos

Os três modelos abaixo vieram do Sketchfab e foram **modificados** para este jogo: simplificados
(muito menos polígonos), peças internas e escondidas removidas, rodas separadas, texturas reduzidas
e materiais ajustados. Os arquivos estão em `assets/vehicles/<tipo>/model.glb`.

| Tipo no jogo | Modelo original | Autor | Licença | Link |
|---|---|---|---|---|
| hatch | 1999 Volkswagen Gol 2000 GTi (G2) | Ezo | CC BY-NC 4.0 | https://sketchfab.com/3d-models/1999-volkswagen-gol-2000-gti-g2-be772162e96746d0a4470e52dc7fbb1d |
| compact_suv | 2014 Volkswagen Golf GTI Mk7 | Ddiaz Design | CC BY-NC-SA 4.0 | https://sketchfab.com/3d-models/2014-volkswagen-golf-gti-mk7-93f2b79c56c14b269fbe914205c4712e |
| sedan | 2020 Volkswagen Polo / Jetta VA3 | Ddiaz Design | CC BY-NC-SA 4.0 | https://sketchfab.com/3d-models/2020-volkswagen-polo-jetta-va3-4a6d7f33d25a44cab1574e74b9aed6ad |

## O que as licenças exigem (resumo, não é aconselhamento jurídico)

- **BY (todas):** citar o autor e a licença (isso já aparece em Pausa > Créditos) e indicar que o modelo foi modificado.
- **NC (Gol, Golf, Polo):** só uso **não comercial**. Não publique o jogo com venda, anúncios ou compras dentro do app
  enquanto usar esses modelos. Troque por modelos próprios ou de licença livre se for monetizar.
- **SA (Golf, Polo):** as versões modificadas dos modelos devem continuar sob a mesma licença
  (CC BY-NC-SA 4.0 ou CC BY-SA 4.0). Os `.glb` em `assets/vehicles/` ficam, portanto, sob essas licenças.
- **Marcas:** os modelos reproduzem carros de marcas reais (Volkswagen). A licença cobre o modelo 3D,
  não as marcas registradas. Para um jogo gratuito de hobby o risco é baixo, mas evite publicar em loja
  (Google Play) sem verificar isso.

Licenças: https://creativecommons.org/licenses/by-nc/4.0/ , https://creativecommons.org/licenses/by-nc-sa/4.0/ ,
https://creativecommons.org/licenses/by-sa/4.0/

## Modelos enviados pelo autor do jogo (autor e licença a confirmar)

Estes cinco arquivos `.glb` foram enviados pelo dono do projeto. **Eu não sei de onde vieram nem qual é a licença de cada um**:
confira antes de publicar o jogo (principalmente se ele for para loja de aplicativos ou tiver anúncios/compras).
Eles foram muito reduzidos (de 17 a 115 MB para cerca de 0,5 MB cada), perderam as texturas originais (a cor virou cor por
vértice) e tiveram as rodas separadas. Os originais não estão no projeto.

| Tipo no jogo | Arquivo enviado | O que representa |
|---|---|---|
| sport | Nissan_GTR_nismo_2022.glb | Nissan GT-R Nismo 2022 |
| suv | Range_Rover_Sports_2018___GLB_.glb | Range Rover Sport 2018 |
| pickup | dodge_HP.glb | picape Dodge clássica |
| large_pickup | toyota_hilux_002.glb | Toyota Hilux |
| aurelo_x | aurelo_x.glb | esportivo (a malha original se chama "Revuelto") |

Esses modelos reproduzem carros de marcas reais; a licença de um modelo 3D não cobre as marcas registradas.
