# Registro de estado (atualizado a cada etapa)

## Escrito, mas NÃO executado (sem Godot no ambiente de geração)
- Entrada configurável (teclado + gamepad) via autoload
- Jogador: andar, correr com resistência, pular, agachar (com checagem de teto), câmera 3ª pessoa com SpringArm (não atravessa paredes), vida, cura, respawn, queda no vazio
- HUD com vida, resistência, FPS e dicas
- Cidade de 36 quarteirões (praças aleatórias, prédios com colisão), avenidas, rampa e caixas de teste, sol com sombras e céu procedural
- Testes headless (`tests/run_tests.gd`)
- Controles de toque para Android (analógico flutuante, arrastar para a câmera, botões Pular/Correr/Agachar/Usar), HUD ampliado e sombras desligadas em celular
- Preset de exportação Android e fluxo do GitHub Actions (`.github/workflows/build.yml`), que também roda os testes na nuvem

## Adicionado nesta versão (também NÃO verificado em execução)
- Veículos dirigíveis (VehicleBody3D): esportivo, sedã, SUV, caminhonete, caminhão e van; entrar/sair de qualquer veículo; câmera de perseguição; dano simplificado; luz de freio
- Trânsito (carros que seguem as avenidas e freiam diante de obstáculos) e pedestres (andam pelas calçadas, fogem, caem se atingidos); ambos reciclados perto do jogador
- Mapa em tela cheia com GPS (toque para definir o destino), minimapa, marcador no mundo
- Menu de pausa com configurações de gráficos (qualidade, sombras, MSAA, distância, quantidade de NPCs, FOV, sensibilidade, limite de FPS), salvar/carregar posição e vida

## Visuais (versão atual, também NÃO verificada em execução)
- Prédios com janelas texturizadas (vidro, tijolo, concreto), térreo com lojas e toldos, recuos e equipamentos no telhado; casas com porta, janelas, telhado de duas águas e chaminé; árvores, postes de luz, faixas de pedestre e ruas com asfalto
- Pessoas articuladas (cabeça com cabelo e olhos, tronco, braços, pernas, sapatos) com animação de andar, no jogador e nos pedestres
- Carros com capô, para-brisa inclinado, vidros, faróis, lanternas, grade, para-choques, placas, retrovisores, frestas de portas, caixas de roda e rodas com aro e raios; caçamba na caminhonete, baú no caminhão, aerofólio no esportivo
- Botões na tela ao dirigir: setas de direção, Acelerar, Freio, Freio de mão e Sair

## Atualização: direção, visuais e controles (também NÃO verificada em execução)
- Carros: câmbio automático, curva de torque, arrasto, freio motor, freio de mão que solta a traseira, direção que endurece com a velocidade, desvira sozinho se capotar, som de motor e buzina (H / botão Buzina). Correção do sentido da força do motor (ENGINE_SIGN = -1)
- Carros e pessoas com formas arredondadas (carroceria por superelipse, anéis elípticos), pessoa com esqueleto e joelhos/cotovelos, uma malha por pessoa
- NPCs: papéis (caminhante, corredor, parado), mais pedestres, conversa com balão de fala (E perto de um pedestre)
- Mapa: tocar no minimapa abre o mapa (botão de cima removido). Configurações de controles e HUD (tamanho, botões, opacidade, canhoto, minimapa, dicas, inverter câmera)

## Atualização: 13 carros e skins por pasta (também NÃO verificada em execução)
- Carros novos: hatch, picape compacta, van clássica, táxi, viatura, ambulância, ônibus (pintura especial: faixas, giroflex, luz de táxi). Trânsito usa TRAFFIC_MIX; carros novos estacionados perto do início
- Skins por pasta em assets/vehicles/<id>/ (model.glb e/ou skin.png). Veja docs/SKINS.md
- Altura dos carros do trânsito agora depende do raio da roda

## Atualização: mais carros e skins por pasta (NÃO verificada em execução)
- 21 tipos de veículo (13 do conjunto anterior + cupê, perua, minivan, SUV compacto, mini urbano, cupê clássico, picape cabine dupla, micro-ônibus), todos originais gerados por código
- Pintura especial de táxi, viatura, ambulância e ônibus no `vehicle_builder.gd`; trânsito usa `TRAFFIC_MIX`; carros novos estacionados em `main.gd`
- Skins por pasta em `assets/vehicles/<id>/` (`model.glb` e/ou `skin.png`), veja `docs/SKINS.md`
- Altura do carro do trânsito agora depende do raio da roda

## Atualização: direção em curva, cidade maior e postes (NÃO verificada em execução)
- Carro: ao esterçar com o acelerador pressionado, o motor compensa a perda de velocidade das rodas da frente (`CORNER_ASSIST` em `vehicle.gd`; 0 desliga)
- Cidade de 12 x 12 quarteirões (~620 m de lado, antes 6 x 6). Constantes em `world_builder.gd` e `city_graph.gd` (precisam coincidir)
- Os quarteirões mais distantes são construídos aos poucos depois que o jogo abre (`build(true)`), para não travar o celular; cada quarteirão tem semente própria
- Postes de luz agora ficam na calçada, junto ao meio-fio (antes caíam dentro da rua); pedestres também andam na calçada
- Mais bairros: prédios altos até 110 m do centro, médios até 200 m, casas depois

## Atualização: toque ao dirigir (NÃO verificada em execução)
- `touch_controls.gd`: cada botão é independente; o estado do acelerador/direção é recalculado a partir dos dedos e reafirmado a cada quadro (`HEAL_ACTIONS`) se algo soltar sem o dedo sair
- Novo botão **Auto** (acima da Buzina): trava o acelerador; o Freio solta; só precisa de um dedo para virar
- **Causa do acelerador piscando**: os comandos de dirigir também estão ligados a eixos de joystick; celulares que mandam sinais de controle vazios zeravam acelerador e direção. O veículo agora lê os botões da tela direto (`scripts/core/virtual_input.gd`), sem passar pelo InputMap
- Linha amarela de diagnóstico no topo ao dirigir (`DEBUG_TOUCH`): toques na tela, força de acel/freio/esq/dir e toques cancelados pelo sistema. Ponha `DEBUG_TOUCH := false` quando não precisar mais

## Atualização: modelos 3D de carros (NÃO verificada em execução)
- 4 tipos agora usam modelos `.glb` otimizados (hatch, compact_suv, sedan, sport): ~10 mil triângulos cada (os originais tinham de 26 mil a 653 mil), texturas até 512 px, 4 rodas separadas (`wheel_*`), frente em +Z, base nas rodas
- Qualidade: `model.glb` detalhado (23 a 41 mil triângulos, texturas até 1024) + `model_far.glb` leve (~8 mil) usado a mais de 45 m
- (versão anterior: as rodas do modelo ficavam paradas; agora giram e esterçam, veja abaixo)
- Créditos e licenças em `docs/CREDITOS.md` e em Pausa > Créditos. Os modelos são CC BY-NC / BY-NC-SA / BY-SA: uso não comercial
- Picape (Fiat Toro, licença "Sketchfab Standard") NÃO foi incluída: licença incerta e 418 mil triângulos

## Atualização: estabilidade dos carros (NÃO verificada em execução)
- Carros sem motorista e parados dormem (`can_sleep`, sem forças aplicadas): acabam tremores. Acordam sozinhos ao serem tocados
- Amortecimento extra de cabeceio e balanço (`WOBBLE_DAMP`) e suspensão mais amortecida: menos balanço depois de batidas
- Freio de espera com motorista parado
- Rede de segurança: se o carro cair do mundo, volta ao último lugar seguro (`FALL_Y`)
- Carro largado nunca é apagado antes de 45 s e só se estiver a mais de 200 m (`ABANDONED_SECONDS`)

## Atualização: rodas que giram e esterçam nos modelos 3D, 50 carros novos (NÃO verificada em execução)
- Modelos 3D com as 4 rodas separadas (`wheel_fl/fr/rl/rr`): o veículo dirigível usa essas peças dentro dos `VehicleWheel3D`, com posição e raio vindos do modelo. Elas giram e as da frente esterçam. Altura do carro ajustada pelo eixo das rodas (`HUB_Y`)
- As rodas dos 4 modelos foram refeitas: pneu/aro separados da suspensão, redondas e centradas (a roda errada do Golf e as extras do Porsche foram corrigidas)
- 50 modelos novos gerados por código, com nomes de modelo fictícios (ex.: Kiruma 1.0, Tigrex GT, Narvik 4x4) em 10 estilos: mini, compacto, sedã, sedã executivo, perua, esportivo, SUV, picape, van/minivan e 4x4 rústico
- Acessórios novos no construtor: `rack`, `lightbar`, `stripe` (cor), `flares`, `bullbar`, `scoop`, `skirts`, `spare`
- Os carros que já existiam também ganharam nomes de modelo (Cerrado, Sertão, Táxi Lumen...); os 4 com modelo 3D real usam o nome real
- Todos entram no trânsito; 6 dos novos ficam estacionados perto do ponto de partida

## Testes realizados
Nenhum. Nada foi compilado nem executado. Podem existir erros de sintaxe ou de API do Godot; o primeiro passo é abrir o projeto e me enviar a saída do editor.

## Limitações conhecidas
- Tudo é geometria procedural "low-poly" gerada em código; não é realismo fotográfico. Para modelos 3D profissionais (por exemplo .glb de bibliotecas gratuitas CC0) é preciso baixá-los e colocá-los em res://assets/; este ambiente não tem internet para isso
- Texturas repetem em padrão; não há iluminação noturna nem janelas acesas
- Sem motocicletas, sem garagem, sem som de motor/buzina, sem faróis com luz real
- Sem semáforos; trânsito pode ficar parado em cruzamentos até destravar
- Pedestres e carros do trânsito são modelos simples; sem animação de andar
- A rota do GPS é aproximada (em L pelos cruzamentos)
- Renderizador Compatibility: sem escala de resolução 3D
- Polícia, missões, interiores e ciclo dia/noite ainda não existem
- Visuais são caixas e cápsulas coloridas; sem animação de personagem
- Sem degraus automáticos (só rampas e saltos até ~1,5 m)
- Sem interiores, NPCs, veículos, polícia, missões, menus, mapa, salvamento, áudio, ciclo dia/noite ou clima
- Cidade pequena (~310 m de lado), todos os nós carregados de uma vez; sem LOD nem streaming ainda
- `interact` só emite um sinal; nada o consome ainda

## Próximo passo
Etapa 4: veículo dirigível (VehicleBody3D), entrar/sair e câmera de veículo.

## Atualização: novo nome e logo (NÃO verificada em execução)
- Jogo renomeado de Open City para **REAL CITY LIFE** (`project.godot`, `export_presets.cfg`, README, workflow)
- Logo nova em `assets/branding/`: ícone do app (`icon.png`, `icon_192.png`, ícone adaptativo do Android), tela de abertura (`splash.png`) e logo no topo do menu de pausa
- APK agora sai como `build/real-city-life.apk`; o identificador do pacote (`com.opencity.game`) foi mantido de propósito, para o celular tratar como atualização do mesmo app

## Atualização: mundo com várias cidades, celular e combate (NÃO verificada em execução)
- **Cidades:** Real City (principal, agora 16x16 quarteirões) + Porto Azul (leste), Vila Serrana (sul) e Monte Alto (norte). Definidas em `CITIES` (`scripts/ai/city_graph.gd`); cada cidade tem seus raios de prédios altos/médios e chance de parque.
- **Rodovias e pontes:** `HIGHWAYS` liga a cidade principal às outras. Cada uma cruza um rio por uma ponte (laje, muretas, pilares). Há postes de luz e pórticos com o nome da cidade. O trânsito (carros) anda nas rodovias; os pedestres só nas cidades.
- **Rios:** o chão é feito de 4 pedaços; o resto é água (plano em y = -3). Se o jogador cair no rio, volta ao último lugar seguro e leva 10 de dano. Carros que caem voltam sozinhos (já existia).
- **GPS:** a rota entre cidades passa pela rodovia (e pela cidade principal quando vai de uma cidade pequena a outra). O mapa completo mostra o mundo todo.
- **Celular** (`scripts/ui/phone.gd`, tecla P / botão "Cel"): Loja de armas (comprar e equipar), Concessionária (comprar carros), Minha garagem (chamar o carro: aparece ao seu lado), GPS entre cidades e Mapa. Dinheiro inicial R$ 25.000; preço dos carros calculado em `scripts/core/shop.gd`.
- **Combate** (F / clique / botão "Atacar"; Q / botão "Arma" troca de arma): punhos, taco, pé de cabra (corpo a corpo, acerta o pedestre mais perto na frente) e pistola, submetralhadora, espingarda (tiro na direção da câmera). Munição infinita. Armas em `scripts/combat/weapons.gd`.
- **Pedestres:** têm vida, cambaleiam ao apanhar, fogem ou revidam (cerca de 30% são briguentos), caem quando a vida acaba, deixam dinheiro e reaparecem depois.
- **Salvamento:** versão 2 guarda dinheiro, armas, arma equipada e carros comprados.
- **Não existe multiplayer:** "bater em jogadores" funciona só com os NPCs por enquanto.

## Atualização: skins pela pasta de dados do jogo instalado (NÃO verificada em execução)
- Nova pasta `skins/` dentro dos dados do app (criada no início do jogo, `scripts/core/skin_folders.gd`), com `carros/<id>/` e `jogador/`.
- Carros: `vehicle_skin.gd` agora lê `model.glb`, `model_far.glb` e `skin.png` também da pasta de skins (prioridade sobre o que está no APK), carregando .glb em tempo de execução (GLTFDocument).
- Jogador: `scripts/player/player_skin.gd` lê `outfit.json` (roupa/cores), `skin.png` (padrão) e `model.glb` (substitui o personagem; animações idle/walk/run se existirem).
- Celular > Skins: mostra o caminho da pasta, o que foi encontrado, copia o caminho e recarrega as skins sem reiniciar.
- Ponto de atenção: onde o Android coloca essa pasta e como abri-la varia por aparelho; o jogo mostra o caminho real.

## Correção: pasta de skins não aparecia no celular (NÃO verificada em execução)
- A primeira versão usava só `user://`, que no Android costuma ficar na área interna do app (invisível). Agora `skin_folders.gd` tenta `/storage/emulated/0/RealCityLife/skins`, `Android/data/com.opencity.game/files/skins` e a pasta interna, e lê de todas.
- `export_presets.cfg`: permissão `permissions/manage_external_storage=true` (acesso a todos os arquivos, necessário para criar a pasta pública no Android 11+).
- Aplicativo Skins mostra cada pasta com "existe" ou "não foi possível criar", e tem o botão "Permitir acesso a arquivos".

## Correção: skins de carro na pasta não mudavam nada (NÃO verificada em execução)
- `skin_folders.gd`: `pick_file()` aceita qualquer nome de arquivo (por extensão), `load_image()` lê png/jpg/webp pelo conteúdo e reduz imagens acima de 2048 px.
- Recarregar skins agora refaz os carros vazios já existentes (`phone.gd`) e renova o trânsito (`NpcManager.refresh_cars()`).
- Celular > Skins > "Ver nomes das pastas dos carros" lista o id de cada carro.

## Novos modelos de carros (NÃO verificados em execução)
- Cinco `.glb` enviados pelo dono do projeto foram reduzidos (de 17 a 115 MB para ~0,5 MB cada, 19 a 26 mil triângulos) e colocados em `assets/vehicles/<id>/model.glb`: sport (Nissan GTR), suv (Range Rover Sport), pickup (Dodge clássica), large_pickup (Hilux), aurelo_x.
- O modelo antigo do tipo `sport` (Porsche 911, com `model_far.glb`) foi retirado do projeto e dos créditos.
- Cada modelo novo tem 4 rodas separadas (`wheel_fl`, `wheel_fr`, `wheel_rl`, `wheel_rr`) para girar e esterçar, vidros semitransparentes e cor por vértice (no GTR as cores de pneus, vidros e para-choques foram estimadas pela forma).
- Como o modelo deixa de aceitar a cor sorteada, todos os carros desse tipo aparecem com a cor do modelo.
- Processo usado (scripts em Python, fora do projeto): leitura do .glb, rotação/escala, detecção das rodas, decimação por agrupamento de vértices com quadrics e gravação do .glb.

## Cores variadas e rodas animadas (NÃO verificadas em execução)
- Os cinco modelos novos foram refeitos com a pintura separada num material chamado `paint`; `vehicle_skin.gd` (`tint_paint`) pinta esse material com a cor sorteada do tipo (as cores de `vehicle_data.gd`).
- Carro do jogador: as rodas já giravam e esterçavam pela física (`VehicleWheel3D`), e isso vale para os modelos novos (4 rodas separadas).
- Carros do trânsito (`traffic_car.gd`): as rodas agora giram com a velocidade e as da frente esterçam nas curvas (ângulo estimado pela taxa de giro do carro).

## Correção: qualidade dos carros novos (NÃO verificada em execução)
- A primeira versão estava reduzida demais (20 mil triângulos, normais recalculadas): superfícies amassadas e rodas deformadas.
- Agora cada carro tem `model.glb` detalhado (Hilux ~40 mil, Dodge ~130 mil, Aurelo ~110 mil, Range Rover ~140 mil, GTR ~160 mil triângulos no corpo, mais ~6 mil por roda) e `model_far.glb` leve (~20 mil), que o jogo usa a mais de 45 m (`FAR_DISTANCE`).
- As normais originais são transferidas para a malha reduzida (superfície lisa) e as janelas do GTR (que não tem vidro no arquivo) foram pintadas por região.
- Se o jogo ficar pesado com vários desses carros por perto, diminuir o número de triângulos em `HQ_BODY` do processo de redução ou a distância `FAR_DISTANCE`.
