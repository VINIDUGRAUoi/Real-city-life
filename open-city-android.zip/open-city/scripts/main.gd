extends Node3D
## Ponto de entrada. Monta mundo, HUD, jogador, veículos estacionados, NPCs, mapa e menus.
## A ordem importa: o HUD é conectado antes do jogador emitir o estado inicial.

const WorldBuilder := preload("res://scripts/world/world_builder.gd")
const PlayerScript := preload("res://scripts/player/player.gd")
const HudScript := preload("res://scripts/ui/hud.gd")
const TouchScript := preload("res://scripts/ui/touch_controls.gd")
const MapScreenScript := preload("res://scripts/ui/map_screen.gd")
const PauseScript := preload("res://scripts/ui/pause_menu.gd")
const PhoneScript := preload("res://scripts/ui/phone.gd")
const SkinFoldersScript := preload("res://scripts/core/skin_folders.gd")
const NpcManagerScript := preload("res://scripts/ai/npc_manager.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")

const SPAWN_POSITION := Vector3(0.0, 0.1, 0.0)

## [tipo, posição, rotação Y em graus]. Rotação -90 = frente para +X, 90 = frente para -X, 0 = frente para -Z.
const PARKED := [
    ["sport", Vector3(14.0, 1.3, 4.5), -90.0],
    ["sedan", Vector3(26.0, 1.3, 4.5), -90.0],
    ["suv", Vector3(-14.0, 1.3, -4.5), 90.0],
    ["pickup", Vector3(-27.0, 1.3, -4.5), 90.0],
    ["truck", Vector3(42.0, 1.3, -4.5), 90.0],
    ["van", Vector3(-40.0, 1.3, 4.5), -90.0],
    ["sedan", Vector3(56.5, 1.3, -30.0), 0.0],
    ["sport", Vector3(-56.5, 1.3, 30.0), 180.0],
    ["hatch", Vector3(38.0, 1.3, 4.5), -90.0],
    ["taxi", Vector3(-12.0, 1.3, 4.5), -90.0],
    ["police", Vector3(-26.0, 1.3, 4.5), -90.0],
    ["classic_van", Vector3(10.0, 1.3, -4.5), 90.0],
    ["ambulance", Vector3(28.0, 1.3, -4.5), 90.0],
    ["small_pickup", Vector3(-40.0, 1.3, -4.5), 90.0],
    ["bus", Vector3(-47.5, 1.3, -30.0), 0.0],
    ["zunta_pop", Vector3(56.5, 1.3, 10.0), 0.0],
    ["narvik_4x4", Vector3(56.5, 1.3, 20.0), 0.0],
    ["tigrex_gt", Vector3(56.5, 1.3, -12.0), 0.0],
    ["wexon_cabine", Vector3(-56.5, 1.3, -12.0), 180.0],
    ["aurelo_x", Vector3(-56.5, 1.3, -22.0), 180.0],
    ["garoa_4x4", Vector3(-56.5, 1.3, 12.0), 180.0],
]

var _beacon: MeshInstance3D


func _ready() -> void:
    SkinFoldersScript.setup() # cria a pasta de skins (carros e jogador) do jogo instalado
    var mobile := OS.has_feature("mobile")

    var world := WorldBuilder.new()
    world.name = "World"
    add_child(world)
    world.build(true)
    var map_data: Dictionary = world.get_map_data()

    for entry in PARKED:
        var vehicle = FactoryScript.create(entry[0])
        vehicle.position = entry[1]
        vehicle.rotation_degrees.y = entry[2]
        add_child(vehicle)

    var hud := HudScript.new()
    hud.name = "Hud"
    hud.touch_mode = mobile
    add_child(hud)

    var player := PlayerScript.new()
    player.name = "Player"
    player.spawn_position = SPAWN_POSITION
    player.health_changed.connect(hud.set_health)
    player.stamina_changed.connect(hud.set_stamina)
    player.driving_changed.connect(hud.on_driving_changed)
    player.speed_changed.connect(hud.on_speed_changed)
    player.prompt_changed.connect(hud.on_prompt_changed)
    add_child(player)
    player.global_position = SPAWN_POSITION
    hud.bind(player, map_data)

    var npcs := NpcManagerScript.new()
    npcs.name = "NpcManager"
    npcs.player = player
    add_child(npcs)

    var map_screen := MapScreenScript.new()
    map_screen.name = "MapScreen"
    add_child(map_screen)
    map_screen.bind(map_data, player)

    var pause_menu := PauseScript.new()
    pause_menu.name = "PauseMenu"
    pause_menu.player = player
    pause_menu.map_screen = map_screen
    add_child(pause_menu)

    # depois do menu de pausa: recebe a tecla Esc primeiro quando o celular está aberto
    var phone := PhoneScript.new()
    phone.name = "Phone"
    phone.player = player
    phone.map_screen = map_screen
    add_child(phone)

    if mobile:
        var layer := CanvasLayer.new()
        layer.name = "TouchLayer"
        add_child(layer)
        var touch := TouchScript.new()
        layer.add_child(touch)
        touch.look_dragged.connect(player.apply_look)
        touch.move_changed.connect(player.set_touch_move)
        touch.move_changed.connect(hud.on_stick_changed)
        player.driving_changed.connect(func(driving: bool, _vehicle_name: String) -> void: touch.set_driving(driving))

    _build_beacon()
    GameState.waypoint_changed.connect(_on_waypoint_changed)


func _build_beacon() -> void:
    _beacon = MeshInstance3D.new()
    var cyl := CylinderMesh.new()
    cyl.top_radius = 0.5
    cyl.bottom_radius = 0.5
    cyl.height = 80.0
    _beacon.mesh = cyl
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.1, 0.1, 0.35)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    _beacon.material_override = mat
    _beacon.visible = false
    add_child(_beacon)


func _on_waypoint_changed() -> void:
    _beacon.visible = GameState.has_waypoint
    if GameState.has_waypoint:
        _beacon.position = Vector3(GameState.waypoint.x, 40.0, GameState.waypoint.y)
