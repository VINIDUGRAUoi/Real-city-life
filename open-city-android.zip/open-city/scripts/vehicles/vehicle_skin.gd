extends RefCounted
## Skins de veículos por pasta. Veja docs/SKINS.md.
##
## Para cada tipo de veículo (id em vehicle_data.gd), o jogo procura na pasta
## res://assets/vehicles/<id>/ :
##   model.glb  (ou model.gltf)  -> troca a carroceria por um modelo 3D seu
##   model_far.glb               -> (opcional) versão leve, usada quando o carro está longe
##   skin.png   (ou .jpg/.webp)  -> aplica uma imagem como pintura (repete em padrão)
## Se a pasta não tiver nada, o carro continua com o visual gerado por código.
##
## Com o jogo já instalado, os mesmos arquivos também são lidos da pasta de skins do app
## (veja scripts/core/skin_folders.gd): skins/carros/<id>/. Essa pasta tem prioridade.
##
## Rodas: se o modelo tiver 4 nós chamados wheel_fl, wheel_fr, wheel_rl e wheel_rr (cada um com a malha
## da roda centrada na origem), as rodas do carro dirigível usam essas peças: giram e as da frente
## esterçam como as rodas geradas por código. A posição e o raio vêm do próprio modelo.

const FoldersScript := preload("res://scripts/core/skin_folders.gd")

const FOLDER := "res://assets/vehicles/"
const MODEL_NAMES := ["model.glb", "model.gltf"]
const TEXTURE_NAMES := ["skin.png", "skin.jpg", "skin.jpeg", "skin.webp"]
## Versão leve do modelo (opcional): usada quando o carro está longe da câmera.
const FAR_NAMES := ["model_far.glb", "model_far.gltf"]
## Distância (m) em que o modelo detalhado dá lugar ao leve.
const FAR_DISTANCE := 45.0
const WHEEL_NAMES := ["wheel_fl", "wheel_fr", "wheel_rl", "wheel_rr"]
## Altura (y, em relação ao centro do carro) do eixo das rodas com o carro parado.
const HUB_Y := -0.5

## Modelos .glb costumam olhar para +Z e o jogo usa a frente em -Z, então giramos 180 graus.
## Se o seu modelo aparecer de ré, troque para false.
const MODEL_FACES_PLUS_Z := true

## Tamanho (em metros) que a imagem de pintura leva para se repetir.
const TEXTURE_TILE_METERS := 4.0

static var _info_cache := {}
static var _tex_cache := {}
static var _far_cache := {}


static func _find(id: String, names: Array) -> String:
    # pasta de skins do jogo instalado: qualquer nome de arquivo serve (veja FoldersScript.pick_file)
    var kind := "model"
    if names == TEXTURE_NAMES:
        kind = "skin"
    elif names == FAR_NAMES:
        kind = "far"
    var ext := FoldersScript.car_file(id, kind)
    if ext != "":
        return ext
    for n: String in names:
        var path := FOLDER + id + "/" + n
        if ResourceLoader.exists(path):
            return path
    return ""


## Esquece o que foi lido (use depois de trocar arquivos na pasta de skins).
## Carros que já estão no mundo não mudam; os novos usam as skins novas.
static func reload() -> void:
    _info_cache.clear()
    _tex_cache.clear()
    _far_cache.clear()


## Cena de um modelo: PackedScene (dentro do jogo) ou Node-molde (arquivo da pasta de skins).
static func _load_scene(path: String) -> Variant:
    if path.begins_with("res://"):
        var res = load(path)
        if res is PackedScene:
            return res
        return null
    var doc := GLTFDocument.new()
    var state := GLTFState.new()
    if doc.append_from_file(path, state) != OK:
        push_warning("Skin de veículo: não consegui ler %s" % path)
        return null
    return doc.generate_scene(state)


static func _inst(scene: Variant) -> Node:
    if scene is PackedScene:
        return (scene as PackedScene).instantiate()
    if scene is Node:
        return (scene as Node).duplicate()
    return null


# ------------------------------------------------------------ pintura (imagem)

static func texture_for(id: String) -> Texture2D:
    if id == "":
        return null
    if _tex_cache.has(id):
        return _tex_cache[id]
    var tex: Texture2D = null
    var path := _find(id, TEXTURE_NAMES)
    if path != "":
        if path.begins_with("res://"):
            var res = load(path)
            if res is Texture2D:
                tex = res
        else:
            var img := FoldersScript.load_image(path)
            if img != null:
                img.generate_mipmaps()
                tex = ImageTexture.create_from_image(img)
    _tex_cache[id] = tex
    return tex


## A imagem é projetada nos três eixos (triplanar), então funciona sem mapeamento UV.
static func apply_texture(mat: StandardMaterial3D, tex: Texture2D) -> void:
    mat.albedo_texture = tex
    mat.albedo_color = Color.WHITE
    mat.uv1_triplanar = true
    mat.uv1_world_triplanar = false
    var s := 1.0 / TEXTURE_TILE_METERS
    mat.uv1_scale = Vector3(s, s, s)
    mat.texture_repeat = true


# ------------------------------------------------------------ modelo 3D (.glb)

static func has_model(id: String) -> bool:
    return not _info(id).is_empty()


## true se o modelo já tem rodas próprias (nó com "wheel", "roda", "tire" ou "pneu" no nome).
static func has_own_wheels(id: String) -> bool:
    var info := _info(id)
    return not info.is_empty() and bool(info["wheels"])


## true se o modelo tem as 4 rodas separadas (wheel_fl, wheel_fr, wheel_rl, wheel_rr).
static func has_wheel_layout(id: String) -> bool:
    var info := _info(id)
    return not info.is_empty() and info.has("hubs")


## Raio das rodas como aparecem no jogo (do modelo, se tiver rodas separadas; senão o dos dados).
static func ride_radius(id: String, data: Dictionary) -> float:
    var info := _info(id)
    if info.is_empty() or not info.has("hubs"):
        return float(data["wheel_radius"])
    var s: float = _fit(info, data)["scale"]
    var hubs: Dictionary = info["hubs"]
    var sum := 0.0
    for wname: String in WHEEL_NAMES:
        sum += float((hubs[wname] as Dictionary)["radius"])
    return sum / float(WHEEL_NAMES.size()) * s


## Posição (no carro) e raio de cada roda do modelo: [{name, hub, radius}] ou [] se não houver.
static func wheel_layout(id: String, data: Dictionary) -> Array:
    var info := _info(id)
    if info.is_empty() or not info.has("hubs"):
        return []
    var fit := _fit(info, data)
    var s: float = fit["scale"]
    var off: Vector3 = fit["offset"]
    var hubs: Dictionary = info["hubs"]
    var out: Array = []
    for wname: String in WHEEL_NAMES:
        var h: Dictionary = hubs[wname]
        var pos: Vector3 = h["pos"]
        out.append({"name": wname, "hub": off + pos * s, "radius": float(h["radius"]) * s})
    return out


## Peças visuais de uma roda (detalhada e, se existir, leve), prontas para ficar dentro do
## VehicleWheel3D: malha centrada, já girada e na escala certa.
static func make_wheel_visuals(id: String, wname: String, data: Dictionary) -> Array:
    var out: Array = []
    var info := _info(id)
    if info.is_empty() or not info.has("hubs"):
        return out
    var s: float = _fit(info, data)["scale"]
    var scenes: Array = [info["scene"]]
    var far_scene = _far_scene(id)
    if far_scene != null:
        scenes.append(far_scene)
    for i in scenes.size():
        var inst: Node = _inst(scenes[i])
        var wn: Node = inst.get_node_or_null(NodePath(wname))
        if wn == null or not (wn is Node3D):
            inst.free()
            continue
        inst.remove_child(wn)
        inst.free()
        var n3 := wn as Node3D
        n3.position = Vector3.ZERO
        n3.basis = Basis(Vector3.UP, PI if MODEL_FACES_PLUS_Z else 0.0).scaled(Vector3(s, s, s))
        if far_scene != null:
            if i == 0:
                _set_range(n3, 0.0, FAR_DISTANCE)
            else:
                _set_range(n3, FAR_DISTANCE, 0.0)
        out.append(n3)
    return out


## Cria o modelo já girado, escalado e posicionado para ocupar o lugar da carroceria.
## keep_wheels = false: tira as rodas do modelo (o veículo dirigível põe as suas, que giram).
static func instance_model(id: String, data: Dictionary, keep_wheels: bool = true) -> Node3D:
    var info := _info(id)
    if info.is_empty():
        return null
    var inst = _inst(info["scene"])
    if not (inst is Node3D):
        if inst != null:
            inst.free()
        return null
    _orient(inst)
    var fit := _fit(info, data)
    var s: float = fit["scale"]
    var strip := (not keep_wheels) and info.has("hubs")
    var holder := Node3D.new()
    holder.name = "SkinModel"
    holder.scale = Vector3(s, s, s)
    holder.position = fit["offset"]
    if strip:
        _strip_wheels(inst)
    holder.add_child(inst)
    var far_scene = _far_scene(id)
    if far_scene != null:
        _set_range(inst, 0.0, FAR_DISTANCE)
        var far_inst = _inst(far_scene)
        if far_inst is Node3D:
            _orient(far_inst)
            if strip:
                _strip_wheels(far_inst)
            _set_range(far_inst, FAR_DISTANCE, 0.0)
            holder.add_child(far_inst)
        else:
            far_inst.free()
    return holder


static func _fit(info: Dictionary, data: Dictionary) -> Dictionary:
    var box: AABB = info["aabb"]
    var size: Vector3 = data["size"]
    var s := size.z / maxf(box.size.z, 0.001)
    var center := box.position + box.size * 0.5
    var y: float
    if info.has("hubs"):
        y = HUB_Y - float(info["hub_y"]) * s       # eixo das rodas na altura certa
    elif bool(info["wheels"]):
        y = -0.5 - float(data["wheel_radius"]) - box.position.y * s
    else:
        y = float(data["sill"]) - box.position.y * s
    return {"scale": s, "offset": Vector3(-center.x * s, y, -center.z * s)}


static func _far_scene(id: String) -> Variant:
    if _far_cache.has(id):
        return _far_cache[id]
    var scene: Variant = null
    var path := _find(id, FAR_NAMES)
    if path != "":
        scene = _load_scene(path)
    _far_cache[id] = scene
    return scene


## begin/end em metros (0 = sem limite). A margem evita piscar na troca.
static func _set_range(node: Node, begin: float, end: float) -> void:
    if node is GeometryInstance3D:
        var g := node as GeometryInstance3D
        g.visibility_range_begin = begin
        g.visibility_range_end = end
        g.visibility_range_begin_margin = 4.0 if begin > 0.0 else 0.0
        g.visibility_range_end_margin = 4.0 if end > 0.0 else 0.0
    for child in node.get_children():
        _set_range(child, begin, end)


static func _strip_wheels(root: Node) -> void:
    for wname: String in WHEEL_NAMES:
        var n := root.get_node_or_null(NodePath(wname))
        if n != null:
            root.remove_child(n)
            n.free()


static func _orient(inst: Node3D) -> void:
    if MODEL_FACES_PLUS_Z:
        inst.rotation.y += PI


static func _info(id: String) -> Dictionary:
    if id == "":
        return {}
    if _info_cache.has(id):
        return _info_cache[id]
    var info := {}
    var path := _find(id, MODEL_NAMES)
    if path != "":
        var res = _load_scene(path)
        if res != null:
            var inst = _inst(res)
            if inst is Node3D:
                _orient(inst)
                var out: Array = []
                _collect_aabb(inst, Transform3D.IDENTITY, out)
                if not out.is_empty():
                    info = {"scene": res, "aabb": out[0], "wheels": _has_wheel_nodes(inst)}
                    var hubs := _collect_hubs(inst)
                    if not hubs.is_empty():
                        info["hubs"] = hubs
                        var ysum := 0.0
                        for wname: String in WHEEL_NAMES:
                            ysum += ((hubs[wname] as Dictionary)["pos"] as Vector3).y
                        info["hub_y"] = ysum / float(WHEEL_NAMES.size())
                        info["wheels"] = true
                else:
                    push_warning("Skin de veículo '%s': o modelo não tem nenhuma malha." % id)
            if inst != null:
                inst.free()
    _info_cache[id] = info
    return info


## As 4 rodas separadas: nós wheel_fl/fr/rl/rr, filhos diretos da raiz, com malha centrada.
static func _collect_hubs(inst: Node3D) -> Dictionary:
    var hubs := {}
    for wname: String in WHEEL_NAMES:
        var n := inst.get_node_or_null(NodePath(wname))
        if not (n is MeshInstance3D) or (n as MeshInstance3D).mesh == null:
            return {}
        var mi := n as MeshInstance3D
        var bb := mi.mesh.get_aabb()
        hubs[wname] = {
            "pos": inst.transform * mi.position,
            "radius": maxf(bb.size.y, bb.size.z) * 0.5,
            "width": bb.size.x,
        }
    return hubs


static func _collect_aabb(node: Node, parent_xf: Transform3D, out: Array) -> void:
    var xf := parent_xf
    if node is Node3D:
        xf = parent_xf * (node as Node3D).transform
    if node is MeshInstance3D and (node as MeshInstance3D).mesh != null:
        var box: AABB = xf * (node as MeshInstance3D).mesh.get_aabb()
        if out.is_empty():
            out.append(box)
        else:
            out[0] = (out[0] as AABB).merge(box)
    for child in node.get_children():
        _collect_aabb(child, xf, out)


static func _has_wheel_nodes(node: Node) -> bool:
    var n := String(node.name).to_lower()
    if n.contains("wheel") or n.contains("roda") or n.contains("tire") or n.contains("pneu"):
        return true
    for child in node.get_children():
        if _has_wheel_nodes(child):
            return true
    return false
