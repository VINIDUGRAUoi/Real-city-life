extends RefCounted
## Cria veículos dirigíveis a partir do id definido em vehicle_data.gd.

const VehicleScript := preload("res://scripts/vehicles/vehicle.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const SkinScript := preload("res://scripts/vehicles/vehicle_skin.gd")


static func create(type_id: String, color: Variant = null) -> Node3D:
    var id := type_id if DataScript.TYPES.has(type_id) else "sedan"
    var chosen: Color
    if SkinScript.texture_for(id) != null:
        chosen = Color.WHITE
    elif color is Color:
        chosen = color
    else:
        var options: Array = DataScript.TYPES[id]["colors"]
        chosen = options.pick_random()
    var vehicle = VehicleScript.new()
    vehicle.setup(id, chosen)
    return vehicle
