extends VehicleBody3D
## Veículo dirigível (física VehicleBody3D) com câmbio automático, curva de torque,
## arrasto, freio motor, freio de mão que solta a traseira, direção que endurece com a
## velocidade, som de motor e buzina. Controles (mesmas ações do jogador):
## move_forward = acelerar, move_back = freio/ré, move_left/right = direção,
## jump = freio de mão, horn = buzina, interact = sair.

signal crashed(impact: float)

const BuilderScript := preload("res://scripts/vehicles/vehicle_builder.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const SkinScript := preload("res://scripts/vehicles/vehicle_skin.gd")
const VirtualInput := preload("res://scripts/core/virtual_input.gd")

## No Godot, força positiva empurra o veículo para +Z, mas os modelos têm a frente em -Z.
const ENGINE_SIGN := -1.0
const CRASH_DELTA_V := 5.0
const MAX_HEALTH := 100.0
const IDLE_RPM := 900.0
const REDLINE_RPM := 6500.0
const GRIP := 8.0
## Compensa a perda de velocidade ao esterçar (rodas da frente viradas "freiam" o carro).
## 1.0 = o carro mantém a aceleração em curva; 0.0 = desliga a compensação.
const CORNER_ASSIST := 1.0
const DRIFT_GRIP := 2.4
## Estabilidade: amortecimento extra só de "cabeceio" (pitch) e "balanço" (roll), sem prender a curva (yaw).
const WOBBLE_DAMP := 5.0
## Parado e sem motorista por este tempo, o carro "dorme" (sem física) e fica firme no chão.
const REST_SPEED := 0.12
## Se o carro cair do mundo ou virar NaN, volta para a última posição segura.
const FALL_Y := -8.0
const MIX_RATE := 22050.0

var type_id := "sedan"
var body_color := Color(0.5, 0.5, 0.5)
var data: Dictionary = {}
var driver = null
var health := MAX_HEALTH
var recyclable := false
var idle_time := 0.0 # segundos sem motorista (usado para limpar carros abandonados)
var display_name := ""
var gear := 1
var rpm := IDLE_RPM

var _body_mat: StandardMaterial3D
var _tail_mat: StandardMaterial3D
var _last_velocity := Vector3.ZERO
var _safe_xform := Transform3D.IDENTITY
var _safe_timer := 0.0
var _rest_timer := 0.0
var _braking_lights := false
var _gear_tops: Array = []
var _shift_cooldown := 0.0
var _rear_wheels: Array = []
var _drifting := false
var _flip_timer := 0.0
var _traction_wheels := 2
var _throttle_smooth := 0.0
var _audio: AudioStreamPlayer
var _playback: AudioStreamGeneratorPlayback
var _snd_phase := 0.0
var _horn_phase := 0.0
var _horn := false


func setup(id: String, color: Color) -> void:
    type_id = id if DataScript.TYPES.has(id) else "sedan"
    body_color = color


func _ready() -> void:
    data = DataScript.TYPES[type_id]
    display_name = data["name"]
    mass = data["mass"]
    center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
    center_of_mass = Vector3(0.0, -0.5, 0.0)
    angular_damp = 1.0
    linear_damp = 0.02
    can_sleep = true

    var parts: Dictionary = BuilderScript.build(self, data, body_color, false)
    _body_mat = parts["body_mat"]
    _tail_mat = parts["tail_mat"]
    _build_wheels()
    var gears := int(data.get("gears", 5))
    var top: float = data["max_speed"]
    for g in gears:
        _gear_tops.append(top * float(g + 1) / float(gears))
    add_to_group("vehicles")
    add_to_group("enterable")
    _last_velocity = linear_velocity
    _safe_xform = global_transform if is_inside_tree() else Transform3D.IDENTITY


func _build_wheels() -> void:
    var radius: float = data["wheel_radius"]
    _traction_wheels = 0
    # Posição e raio de cada roda: do modelo 3D (se tiver as 4 rodas separadas) ou dos dados.
    var specs: Array = []
    var layout := SkinScript.wheel_layout(type_id, data)
    if layout.size() == 4:
        var compress := clampf(9.81 / (4.0 * float(data["suspension"])), 0.0, 0.25)
        for e: Dictionary in layout:
            var hub: Vector3 = e["hub"]
            # o eixo fica abaixo do ponto de fixação: descanso da mola (0.2) menos a compressão do peso
            specs.append({"pos": hub + Vector3(0.0, 0.2 - compress, 0.0), "radius": float(e["radius"]), "name": str(e["name"])})
    else:
        for wp: Vector3 in BuilderScript.wheel_positions(data):
            specs.append({"pos": wp, "radius": radius, "name": ""})
    for spec: Dictionary in specs:
        var p: Vector3 = spec["pos"]
        var wr: float = spec["radius"]
        var wheel := VehicleWheel3D.new()
        wheel.position = p
        var front := p.z < 0.0
        wheel.use_as_steering = front
        wheel.use_as_traction = bool(data["awd"]) or not front
        if wheel.use_as_traction:
            _traction_wheels += 1
        wheel.wheel_radius = wr
        wheel.wheel_rest_length = 0.2
        wheel.suspension_travel = 0.35
        wheel.suspension_stiffness = data["suspension"]
        wheel.suspension_max_force = float(data["mass"]) * 10.0
        wheel.damping_compression = 0.9
        wheel.damping_relaxation = 0.95
        wheel.wheel_friction_slip = GRIP
        wheel.wheel_roll_influence = 0.05
        add_child(wheel)
        if str(spec["name"]) != "":
            for visual in SkinScript.make_wheel_visuals(type_id, str(spec["name"]), data):
                wheel.add_child(visual)
        elif not SkinScript.has_own_wheels(type_id):
            wheel.add_child(BuilderScript.make_wheel(wr))
        if not front:
            _rear_wheels.append(wheel)


# ------------------------------------------------------------ interface comum
# (usada pelo jogador, pelos pedestres e pelo mapa)

func can_enter() -> bool:
    return driver == null


func get_display_name() -> String:
    return display_name


func get_drivable():
    return self


func set_driver(new_driver) -> void:
    driver = new_driver
    sleeping = false
    idle_time = 0.0
    _rest_timer = 0.0
    if new_driver != null:
        _start_audio()
    else:
        _stop_audio()


func clear_driver() -> void:
    set_driver(null)


func get_speed() -> float:
    return linear_velocity.length()


func get_forward_xz() -> Vector2:
    var f := -global_transform.basis.z
    var v := Vector2(f.x, f.z)
    return v.normalized() if v.length() > 0.001 else Vector2(0.0, -1.0)


# ------------------------------------------------------------------- física

func _physics_process(delta: float) -> void:
    # ---- rede de segurança: caiu do mundo ou posição inválida -> volta para o último lugar seguro
    var gp := global_position
    if gp.y < FALL_Y or is_nan(gp.x) or is_nan(gp.y) or is_nan(gp.z):
        global_transform = _safe_xform
        linear_velocity = Vector3.ZERO
        angular_velocity = Vector3.ZERO
        return

    # ---- parado e sem motorista: não aplica nada e deixa o carro dormir (sem tremer)
    if driver == null:
        idle_time += delta
        if linear_velocity.length() < REST_SPEED and angular_velocity.length() < REST_SPEED:
            _rest_timer += delta
        else:
            _rest_timer = 0.0
        if _rest_timer > 0.6 and global_transform.basis.y.y > 0.8:
            engine_force = 0.0
            brake = 0.04 * mass
            steering = 0.0
            _last_velocity = linear_velocity
            if _rest_timer > 1.2:
                _safe_xform = global_transform
            return
    else:
        idle_time = 0.0
        _rest_timer = 0.0

    var fwd := -global_transform.basis.z
    var speed := linear_velocity.dot(fwd) # positivo = andando para a frente (-Z)
    var speed_abs := absf(speed)
    var throttle := 0.0
    var brake_amount := 0.0
    var steer_input := 0.0
    var handbrake := false
    var alive := health > 0.0
    _horn = false

    if driver != null and alive:
        # maior valor entre teclado/controle e botões da tela (que não passam pelo InputMap)
        var accel := maxf(Input.get_action_strength("move_forward"), VirtualInput.accel)
        var reverse := maxf(Input.get_action_strength("move_back"), VirtualInput.reverse)
        steer_input = maxf(Input.get_action_strength("move_left"), VirtualInput.steer_left) \
            - maxf(Input.get_action_strength("move_right"), VirtualInput.steer_right)
        handbrake = Input.is_action_pressed("jump") or VirtualInput.handbrake
        _horn = Input.is_action_pressed("horn") or VirtualInput.horn
        if accel > 0.0:
            if speed < -1.5:
                brake_amount = accel # está de ré: o acelerador freia primeiro
            else:
                throttle = accel
        if reverse > 0.0:
            if speed > 1.5:
                brake_amount = maxf(brake_amount, reverse)
            else:
                throttle = -reverse * 0.6
        if accel == 0.0 and reverse == 0.0:
            brake_amount = 0.12 if speed_abs > 0.5 else 0.6 # freio motor / segura o carro parado
    else:
        brake_amount = 1.0 # estacionado ou quebrado: fica parado

    # ---- câmbio automático e rotação do motor
    var gears := _gear_tops.size()
    _shift_cooldown = maxf(_shift_cooldown - delta, 0.0)
    if throttle > 0.0 and _shift_cooldown <= 0.0:
        if gear < gears and speed > float(_gear_tops[gear - 1]) * 0.93:
            gear += 1
            _shift_cooldown = 0.35
        elif gear > 1 and speed < float(_gear_tops[gear - 2]) * 0.72:
            gear -= 1
            _shift_cooldown = 0.2
    elif throttle <= 0.0 and gear > 1 and speed < float(_gear_tops[gear - 2]) * 0.6:
        gear -= 1
    var gear_top: float = _gear_tops[gear - 1]
    var frac := clampf(speed_abs / gear_top, 0.0, 1.05)
    var target_rpm := lerpf(IDLE_RPM, REDLINE_RPM, frac)
    if throttle != 0.0:
        target_rpm = maxf(target_rpm, lerpf(IDLE_RPM, 3500.0, absf(throttle)))
    rpm = lerpf(rpm, target_rpm, minf(1.0, 6.0 * delta))

    # ---- força do motor (curva de torque por marcha, limite de aderência, velocidade máxima)
    var max_speed: float = data["max_speed"]
    var gear_mult := lerpf(1.5, 0.62, float(gear - 1) / maxf(float(gears - 1), 1.0))
    if throttle < 0.0:
        gear_mult = 1.0
    var curve := 1.0 - 0.45 * pow(frac, 3.0)
    var limiter := clampf((max_speed - speed_abs) / (0.08 * max_speed), 0.0, 1.0)
    if throttle < 0.0:
        limiter = clampf((10.0 - speed_abs) / 2.0, 0.0, 1.0)
    var power_factor := 0.4 + 0.6 * health / MAX_HEALTH
    var shift_factor := 0.5 if _shift_cooldown > 0.15 else 1.0
    var force := absf(throttle) * float(data["power"]) * gear_mult * curve * limiter * power_factor * shift_factor
    force = minf(force, mass * 2.4)
    engine_force = signf(throttle) * force * ENGINE_SIGN

    # ---- acelerar enquanto vira: devolve a velocidade que a direção "rouba" nas rodas da frente
    if throttle > 0.0 and speed > 1.0:
        var sz: Vector3 = data["size"]
        var wheelbase := maxf(sz.z - 1.4, 1.5)
        var turn := minf(absf(steering), 0.8)
        var scrub := 0.5 * mass * speed * speed * tan(turn) * sin(turn) / wheelbase
        scrub = minf(scrub, mass * 3.0)
        apply_central_force(fwd * scrub * CORNER_ASSIST * throttle * limiter * power_factor)

    # ---- freios, arrasto e aerodinâmica
    var brake_force := brake_amount * 0.03 * mass
    if handbrake:
        brake_force = maxf(brake_force, 0.05 * mass)
    brake = brake_force
    var vel_len := linear_velocity.length()
    apply_central_force(-linear_velocity * vel_len * mass * 0.0005)
    apply_central_force(Vector3.DOWN * vel_len * vel_len * mass * 0.0004)
    # amortece o balanço do carro (depois de batidas ou lombadas) sem atrapalhar as curvas
    var av := angular_velocity
    var b := global_transform.basis
    var pitch_rate := av.dot(b.x)
    var roll_rate := av.dot(b.z)
    apply_torque(-(b.x * pitch_rate + b.z * roll_rate) * WOBBLE_DAMP * mass)

    # ---- freio de mão solta a traseira (derrapagem)
    if handbrake != _drifting:
        _drifting = handbrake
        for wheel: VehicleWheel3D in _rear_wheels:
            wheel.wheel_friction_slip = DRIFT_GRIP if handbrake else GRIP

    # ---- direção: endurece com a velocidade, volta ao centro mais rápido
    var speed_factor := clampf(speed_abs / 32.0, 0.0, 1.0)
    var steer_limit: float = float(data["steer"]) * lerpf(1.0, 0.3, pow(speed_factor, 0.8))
    var steer_target := steer_input * steer_limit
    var rate := 2.4 if absf(steer_target) > absf(steering) else 4.5
    steering = move_toward(steering, steer_target, rate * delta)

    # ---- luzes de freio
    var lights_on := (brake_amount > 0.3 and driver != null) or handbrake
    if lights_on != _braking_lights:
        _braking_lights = lights_on
        _tail_mat.emission_energy_multiplier = 2.5 if lights_on else 0.4

    # ---- guarda um lugar seguro (carro em pé e perto do chão) para a rede de segurança
    _safe_timer += delta
    if _safe_timer > 1.0 and global_transform.basis.y.y > 0.85 and global_position.y > -0.5:
        _safe_timer = 0.0
        _safe_xform = global_transform

    # ---- capotou? desvira sozinho depois de uns segundos
    if driver != null and global_transform.basis.y.y < 0.3 and vel_len < 3.0:
        _flip_timer += delta
        if _flip_timer > 2.5:
            _flip_timer = 0.0
            var pos := global_position + Vector3.UP * 1.0
            var yaw := global_transform.basis.get_euler().y
            global_transform = Transform3D(Basis(Vector3.UP, yaw), pos)
            linear_velocity = Vector3.ZERO
            angular_velocity = Vector3.ZERO
    else:
        _flip_timer = 0.0

    # ---- batidas
    var dv := (linear_velocity - _last_velocity).length()
    _last_velocity = linear_velocity
    if dv > CRASH_DELTA_V:
        _on_crash(dv)

    _throttle_smooth = lerpf(_throttle_smooth, absf(throttle), minf(1.0, 8.0 * delta))
    _fill_audio()


func _on_crash(impact: float) -> void:
    health = maxf(health - ((impact - CRASH_DELTA_V) * 6.0 + 5.0), 0.0)
    _body_mat.albedo_color = body_color.lerp(Color(0.1, 0.1, 0.1), 1.0 - health / MAX_HEALTH)
    crashed.emit(impact)
    if driver != null and impact > 8.0 and driver.has_method("take_damage"):
        driver.take_damage((impact - 8.0) * 3.0)


# -------------------------------------------------------------------- som

func _start_audio() -> void:
    if _audio != null:
        return
    var gen := AudioStreamGenerator.new()
    gen.mix_rate = MIX_RATE
    gen.buffer_length = 0.15
    _audio = AudioStreamPlayer.new()
    _audio.stream = gen
    _audio.volume_db = -8.0
    add_child(_audio)
    _audio.play()
    _playback = _audio.get_stream_playback() as AudioStreamGeneratorPlayback


func _stop_audio() -> void:
    if _audio != null:
        _audio.queue_free()
    _audio = null
    _playback = null


## Som de motor sintetizado: frequência acompanha a rotação; buzina com dois tons.
func _fill_audio() -> void:
    if _playback == null:
        return
    var frames := _playback.get_frames_available()
    if frames <= 0:
        return
    var step := (rpm / 60.0 * 2.0) / MIX_RATE
    var amp := 0.10 + 0.20 * _throttle_smooth
    var buffer := PackedVector2Array()
    buffer.resize(frames)
    for i in frames:
        _snd_phase += step
        if _snd_phase >= 1.0:
            _snd_phase -= 1.0
        var saw := _snd_phase * 2.0 - 1.0
        var s := saw * 0.45 + sin(_snd_phase * TAU) * 0.35 + sin(_snd_phase * TAU * 3.0) * 0.12
        s *= amp
        if _horn:
            _horn_phase += 1.0 / MIX_RATE
            s += (signf(sin(_horn_phase * TAU * 420.0)) + signf(sin(_horn_phase * TAU * 520.0))) * 0.07
        buffer[i] = Vector2(s, s)
    _playback.push_buffer(buffer)
