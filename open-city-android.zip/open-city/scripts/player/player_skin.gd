extends RefCounted
## Skin do jogador lida da pasta de skins do jogo instalado (veja scripts/core/skin_folders.gd):
##   jogador/outfit.json  cores e roupa (sobrescreve a roupa padrão)
##   jogador/skin.png     imagem aplicada sobre o corpo (padrão que se repete a cada 1 m)
##   jogador/model.glb    modelo 3D que substitui o personagem

const FoldersScript := preload("res://scripts/core/skin_folders.gd")

const TEXTURE_NAMES := ["skin.png", "skin.jpg", "skin.jpeg", "skin.webp"]
const MODEL_NAMES := ["model.glb", "model.gltf"]
## Altura (m) do personagem com modelo próprio.
const TARGET_HEIGHT := 1.78
## Modelos .glb costumam olhar para +Z e o jogo usa a frente em -Z.
const MODEL_FACES_PLUS_Z := true


static func _find(names: Array) -> String:
    var kind := "skin" if names == TEXTURE_NAMES else "model"
    return FoldersScript.player_file(kind)


## Valores de outfit.json que trocam a roupa padrão (vazio se não houver arquivo).
static func outfit_overrides() -> Dictionary:
    var out := {}
    var path := FoldersScript.player_file("outfit")
    if path == "":
        return out
    var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
    if not (parsed is Dictionary):
        push_warning("Skin do jogador: outfit.json inválido.")
        return out
    var data: Dictionary = parsed
    for key: String in ["skin", "shirt", "pants", "hair", "shoe"]:
        if data.has(key):
            out[key] = Color.from_string(str(data[key]), Color.MAGENTA)
    if data.has("hat"):
        var h: Variant = data["hat"]
        if h == null or str(h) == "" or str(h).to_lower() == "none" or str(h).to_lower() == "nenhum":
            out["hat"] = null
        else:
            out["hat"] = Color.from_string(str(h), Color.RED)
    for key: String in ["long_hair", "short_sleeves", "shorts", "backpack"]:
        if data.has(key):
            out[key] = bool(data[key])
    if data.has("scale"):
        out["scale"] = clampf(float(data["scale"]), 0.6, 1.6)
    return out


static func _meshes(node: Node, out: Array) -> void:
    if node is MeshInstance3D:
        out.append(node)
    for child in node.get_children():
        _meshes(child, out)


static func _collect_aabb(node: Node, parent_xf: Transform3D, out: Array) -> void:
    var xf := parent_xf
    if node is Node3D:
        xf = parent_xf * (node as Node3D).transform
    if node is MeshInstance3D and (node as MeshInstance3D).mesh != null:
        var box: AABB = xf * (node as MeshInstance3D).mesh.get_aabb()
        if out.is_empty():
            out.append(box)
        else:
            out[0] = (out[0] as AABB).merge(box)
    for child in node.get_children():
        _collect_aabb(child, xf, out)


static func _find_anim(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node
    for child in node.get_children():
        var found := _find_anim(child)
        if found != null:
            return found
    return null


## Aplica imagem e/ou modelo ao personagem montado por HumanoidScript.build().
## Retorna {"model": Node3D ou null, "anim": AnimationPlayer ou null}.
static func apply(rig: Dictionary) -> Dictionary:
    var result := {"model": null, "anim": null}
    var root: Node3D = rig["root"]
    var meshes: Array = []
    _meshes(root, meshes)

    var tex_path := _find(TEXTURE_NAMES)
    if tex_path != "":
        var img := FoldersScript.load_image(tex_path)
        if img != null:
            img.generate_mipmaps()
            var tex := ImageTexture.create_from_image(img)
            for mi: MeshInstance3D in meshes:
                var mat := mi.get_active_material(0)
                if mat is StandardMaterial3D:
                    var copy := (mat as StandardMaterial3D).duplicate() as StandardMaterial3D
                    copy.albedo_texture = tex
                    copy.uv1_triplanar = true
                    copy.uv1_scale = Vector3.ONE
                    copy.texture_repeat = true
                    mi.material_override = copy

    var model_path := _find(MODEL_NAMES)
    if model_path != "":
        var doc := GLTFDocument.new()
        var state := GLTFState.new()
        if doc.append_from_file(model_path, state) == OK:
            var model := doc.generate_scene(state)
            if model is Node3D:
                var holder := Node3D.new()
                holder.name = "SkinModel"
                root.add_child(holder)
                holder.add_child(model)
                if MODEL_FACES_PLUS_Z:
                    (model as Node3D).rotation.y = PI
                var boxes: Array = []
                _collect_aabb(model, Transform3D.IDENTITY, boxes)
                if not boxes.is_empty():
                    var box: AABB = boxes[0]
                    var s := TARGET_HEIGHT / maxf(box.size.y, 0.001)
                    var center := box.position + box.size * 0.5
                    holder.scale = Vector3(s, s, s)
                    holder.position = Vector3(-center.x * s, -box.position.y * s, -center.z * s)
                    # o corpo gerado fica escondido (o esqueleto continua animando, para a arma na mão)
                    for mi: MeshInstance3D in meshes:
                        if not holder.is_ancestor_of(mi):
                            mi.visible = false
                    result["model"] = holder
                    result["anim"] = _find_anim(model)
                else:
                    push_warning("Skin do jogador: o modelo não tem nenhuma malha.")
                    holder.queue_free()
            elif model != null:
                model.queue_free()
        else:
            push_warning("Skin do jogador: não consegui ler %s" % model_path)
    return result


## Nome da animação do modelo que combina com "idle", "walk" ou "run" ("" se não houver).
static func pick_animation(player: AnimationPlayer, want: String) -> String:
    var tries: Array[String] = [want]
    if want == "run":
        tries.append("walk")
    for t: String in tries:
        for a: String in player.get_animation_list():
            if a.to_lower().contains(t):
                var anim := player.get_animation(a)
                if anim != null:
                    anim.loop_mode = Animation.LOOP_LINEAR
                return a
    return ""
