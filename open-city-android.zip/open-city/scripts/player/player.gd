class_name Player
extends CharacterBody3D
## Personagem em terceira pessoa + motorista. Colisão, visual e câmera são criados em
## código. O visual é um PLACEHOLDER (cápsula + "nariz" indicando a frente).
## Entrar/sair de veículos: ação "interact" (E) perto de qualquer veículo.

signal health_changed(current: float, maximum: float)
signal stamina_changed(current: float, maximum: float)
signal interact_requested
signal died
signal driving_changed(driving: bool, vehicle_name: String)
signal speed_changed(kmh: float)
signal prompt_changed(vehicle_name: String)

const HumanoidScript := preload("res://scripts/ai/humanoid.gd")
const WeaponsScript := preload("res://scripts/combat/weapons.gd")

const STAND_HEIGHT := 1.8
const CROUCH_HEIGHT := 1.1
const RADIUS := 0.4
const PITCH_MIN := -1.25
const PITCH_MAX := 0.6
const FALL_LIMIT := -30.0
const STAMINA_DRAIN := 22.0
const STAMINA_REGEN := 18.0
const STAMINA_RECOVER_AT := 25.0
const MOUSE_BASE := 0.0025
const TOUCH_BASE := 0.006
const ENTER_DISTANCE := 4.5
const VEHICLE_CAMERA_DISTANCE := 7.0
const WATER_LIMIT := -2.0 # abaixo disso o jogador caiu no rio
const AIM_RANGE := 120.0
const SWING_TIME := 0.32

@export var walk_speed := 4.0
@export var run_speed := 8.0
@export var crouch_speed := 2.0
@export var jump_velocity := 5.5
@export var acceleration := 25.0
@export var stick_sensitivity := 2.5
@export var camera_distance := 4.5
@export var max_health := 100.0
@export var max_stamina := 100.0

var mouse_sensitivity := MOUSE_BASE
var touch_sensitivity := TOUCH_BASE
var spawn_position := Vector3.ZERO
var health := 0.0
var stamina := 0.0
var crouching := false

var _yaw := 0.0
var _pitch := -0.25
var _exhausted := false
var _vehicle = null
var _touch_move := Vector2.ZERO
var _invert := 1.0
var _rig: Dictionary = {}
var _phase := 0.0
var _prompt := ""
var _prompt_timer := 0.0
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _collider: CollisionShape3D
var _capsule: CapsuleShape3D
var _visual: Node3D
var _pivot: Node3D
var _arm: SpringArm3D
var _camera: Camera3D
var _attack_cd := 0.0
var _attack_time := 0.0 # tempo restante da animação de golpe
var _melee_pending := false
var _attack_held := false
var _weapon_id := "fists"
var _weapon_attach: BoneAttachment3D
var _safe_pos := Vector3(0.0, 0.1, 0.0)
var _safe_timer := 0.0


func _ready() -> void:
    collision_layer = 1
    collision_mask = 3 # chão/prédios/veículos + pedestres
    health = max_health
    stamina = max_stamina
    _build_collision()
    _build_visual()
    _build_camera_rig()
    var gs := get_node_or_null("/root/GameSettings")
    if gs != null:
        gs.changed.connect(_apply_settings)
        _apply_settings()
    var state := get_node_or_null("/root/GameState")
    if state != null:
        state.weapon_changed.connect(_equip_weapon)
        _equip_weapon(state.weapon_id)
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    health_changed.emit(health, max_health)
    stamina_changed.emit(stamina, max_stamina)


func _apply_settings() -> void:
    var gs := get_node_or_null("/root/GameSettings")
    if gs == null:
        return
    mouse_sensitivity = MOUSE_BASE * gs.sensitivity
    touch_sensitivity = TOUCH_BASE * gs.sensitivity
    _invert = -1.0 if gs.invert_y else 1.0
    if _camera != null:
        _camera.fov = gs.fov
        _camera.far = gs.view_distance


# ---------------------------------------------------------------- construção

func _build_collision() -> void:
    _capsule = CapsuleShape3D.new()
    _capsule.radius = RADIUS
    _capsule.height = STAND_HEIGHT
    _collider = CollisionShape3D.new()
    _collider.shape = _capsule
    _collider.position.y = STAND_HEIGHT * 0.5
    add_child(_collider)


func _build_visual() -> void:
    var outfit := {
        "skin": Color(0.85, 0.65, 0.5), "shirt": Color(0.9, 0.5, 0.1), "pants": Color(0.15, 0.2, 0.35),
        "hair": Color(0.1, 0.07, 0.05), "shoe": Color(0.9, 0.9, 0.9), "long_hair": false,
        "scale": 1.0, "backpack": true,
    }
    _rig = HumanoidScript.build(self, outfit)
    _visual = _rig["root"]


func _build_camera_rig() -> void:
    _pivot = Node3D.new()
    _pivot.position = Vector3(0.0, STAND_HEIGHT - 0.3, 0.0)
    add_child(_pivot)

    _arm = SpringArm3D.new()
    _arm.spring_length = camera_distance
    var probe := SphereShape3D.new()
    probe.radius = 0.25
    _arm.shape = probe
    _arm.add_excluded_object(get_rid())
    _pivot.add_child(_arm)

    _camera = Camera3D.new()
    _camera.fov = 75.0
    _camera.near = 0.1
    _arm.add_child(_camera)
    _camera.make_current()


# ------------------------------------------------------------------- entrada

func _unhandled_input(event: InputEvent) -> void:
    var motion := event as InputEventMouseMotion
    if motion != null:
        # No celular o toque também gera "mouse"; a câmera usa apply_look().
        if not OS.has_feature("mobile") and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
            _yaw -= motion.relative.x * mouse_sensitivity
            _pitch = clampf(_pitch - motion.relative.y * mouse_sensitivity * _invert, PITCH_MIN, PITCH_MAX)
        return

    var click := event as InputEventMouseButton
    if click != null and click.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
        if not OS.has_feature("mobile"):
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
        return

    if event.is_action_pressed("interact"):
        _try_interact()
    elif event.is_action_pressed("weapon_next"):
        var gs := get_node_or_null("/root/GameState")
        if gs != null and _vehicle == null:
            gs.cycle_weapon()
    elif event.is_action_pressed("debug_damage"):
        take_damage(10.0)


func _process(delta: float) -> void:
    var look := Input.get_vector("look_left", "look_right", "look_up", "look_down")
    _yaw -= look.x * stick_sensitivity * delta
    _pitch = clampf(_pitch - look.y * stick_sensitivity * delta * _invert, PITCH_MIN, PITCH_MAX)
    _pivot.rotation = Vector3(_pitch, _yaw, 0.0)


## Analógico virtual do celular (x: direita +, y: para baixo +). Tem prioridade sobre as teclas.
func set_touch_move(value: Vector2) -> void:
    _touch_move = value.limit_length(1.0)


## Chamado pelos controles de toque (deslocamento do dedo em pixels).
func apply_look(relative: Vector2) -> void:
    _yaw -= relative.x * touch_sensitivity
    _pitch = clampf(_pitch - relative.y * touch_sensitivity * _invert, PITCH_MIN, PITCH_MAX)


# ------------------------------------------------------------------- veículos

func is_driving() -> bool:
    return _vehicle != null


func get_forward_xz() -> Vector2:
    var f: Vector3
    if _vehicle != null and is_instance_valid(_vehicle):
        f = -_vehicle.global_transform.basis.z
    else:
        f = -_visual.global_transform.basis.z
    var v := Vector2(f.x, f.z)
    return v.normalized() if v.length() > 0.001 else Vector2(0.0, -1.0)


func _nearest_enterable():
    var best = null
    var best_dist := ENTER_DISTANCE
    for node in get_tree().get_nodes_in_group("enterable"):
        if not node.has_method("can_enter") or not node.can_enter():
            continue
        var off: Vector3 = node.global_position - global_position
        off.y = 0.0
        var d := off.length()
        if d < best_dist:
            best_dist = d
            best = node
    return best


func _try_interact() -> void:
    if _vehicle != null:
        exit_vehicle()
        return
    var target = _nearest_enterable()
    if target != null:
        var drivable = target.get_drivable()
        if drivable != null:
            enter_vehicle(drivable)
        return
    var npc = _nearest_npc(2.6)
    if npc != null:
        npc.talk(self)
        return
    interact_requested.emit()


func _nearest_npc(max_distance: float):
    var best = null
    var best_dist := max_distance
    for node in get_tree().get_nodes_in_group("pedestrians"):
        if not node.has_method("talk"):
            continue
        var off: Vector3 = node.global_position - global_position
        off.y = 0.0
        if off.length() < best_dist:
            best_dist = off.length()
            best = node
    return best


func enter_vehicle(v) -> void:
    _vehicle = v
    v.set_driver(self)
    _visual.visible = false
    collision_layer = 0
    collision_mask = 0
    _collider.set_deferred("disabled", true)
    velocity = Vector3.ZERO
    _arm.add_excluded_object(v.get_rid())
    _arm.spring_length = VEHICLE_CAMERA_DISTANCE
    _pivot.position.y = 1.2
    _set_prompt("")
    driving_changed.emit(true, v.get_display_name())


func exit_vehicle() -> void:
    var v = _vehicle
    if v == null:
        return
    var exit_pos := _find_exit_position(v) if is_instance_valid(v) else global_position
    _vehicle = null
    if is_instance_valid(v):
        v.clear_driver()
        _arm.remove_excluded_object(v.get_rid())
    global_position = exit_pos
    velocity = Vector3.ZERO
    collision_layer = 1
    collision_mask = 3
    _collider.set_deferred("disabled", false)
    _visual.visible = true
    _arm.spring_length = camera_distance
    _pivot.position.y = STAND_HEIGHT - 0.3
    crouching = false
    _capsule.height = STAND_HEIGHT
    _collider.position.y = STAND_HEIGHT * 0.5
    _visual.scale.y = 1.0
    driving_changed.emit(false, "")


func _find_exit_position(v) -> Vector3:
    var xform: Transform3D = v.global_transform
    var origin: Vector3 = xform.origin
    var side := xform.basis.x
    var back := xform.basis.z
    var candidates := [origin - side * 2.4, origin + side * 2.4, origin + back * 3.5, origin - back * 3.5]
    var space := get_world_3d().direct_space_state
    var probe := SphereShape3D.new()
    probe.radius = 0.45
    for c: Vector3 in candidates:
        var ray := PhysicsRayQueryParameters3D.create(c + Vector3.UP * 2.0, c + Vector3.DOWN * 3.0, 1)
        ray.exclude = [v.get_rid()]
        var hit := space.intersect_ray(ray)
        if hit.is_empty():
            continue
        var ground: Vector3 = hit["position"]
        var q := PhysicsShapeQueryParameters3D.new()
        q.shape = probe
        q.transform = Transform3D(Basis(), ground + Vector3.UP * 0.9)
        q.collision_mask = 1
        q.exclude = [v.get_rid()]
        if space.intersect_shape(q, 1).is_empty():
            return ground + Vector3.UP * 0.1
    return origin + Vector3.UP * 2.5


func _set_prompt(text: String) -> void:
    if text != _prompt:
        _prompt = text
        prompt_changed.emit(text)


# ------------------------------------------------------------------- física

func _physics_process(delta: float) -> void:
    if _vehicle != null:
        if not is_instance_valid(_vehicle):
            _vehicle = null
            exit_vehicle()
            return
        _drive_follow(delta)
        return

    _prompt_timer -= delta
    if _prompt_timer <= 0.0:
        _prompt_timer = 0.15
        var near = _nearest_enterable()
        _set_prompt(near.get_display_name() if near != null else "")

    _set_crouching(Input.is_action_pressed("crouch"))

    var move := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    if _touch_move.length() > 0.01:
        move = _touch_move
    var dir := Basis(Vector3.UP, _yaw) * Vector3(move.x, 0.0, move.y)

    var wants_sprint := Input.is_action_pressed("sprint") and move.length() > 0.1 and not crouching
    var sprinting := wants_sprint and not _exhausted and stamina > 0.0
    var speed := walk_speed
    if crouching:
        speed = crouch_speed
    elif sprinting:
        speed = run_speed
    _update_stamina(sprinting, delta)

    var target := dir * speed
    velocity.x = move_toward(velocity.x, target.x, acceleration * delta)
    velocity.z = move_toward(velocity.z, target.z, acceleration * delta)

    if is_on_floor():
        if Input.is_action_just_pressed("jump") and not crouching:
            velocity.y = jump_velocity
    else:
        velocity.y -= _gravity * delta

    move_and_slide()

    var hspeed := Vector2(velocity.x, velocity.z).length()
    _phase += hspeed * delta * 1.6
    HumanoidScript.animate(_rig, _phase, clampf(hspeed / 3.0, 0.0, 1.0))
    _update_combat(delta)
    _update_safe_position(delta)

    if dir.length() > 0.1:
        var target_angle := atan2(-dir.x, -dir.z)
        _visual.rotation.y = lerp_angle(_visual.rotation.y, target_angle, 12.0 * delta)

    if global_position.y < WATER_LIMIT and global_position.y >= FALL_LIMIT:
        _recover_from_water()
    if global_position.y < FALL_LIMIT:
        respawn()


func _drive_follow(delta: float) -> void:
    global_position = _vehicle.global_position
    var spd: float = _vehicle.get_speed()
    if spd > 3.0:
        var fwd: Vector3 = -_vehicle.global_transform.basis.z
        _yaw = lerp_angle(_yaw, atan2(-fwd.x, -fwd.z), minf(1.0, 3.0 * delta))
    speed_changed.emit(spd * 3.6)


func _set_crouching(value: bool) -> void:
    if value == crouching:
        return
    if not value and not _can_stand():
        return
    crouching = value
    var h := CROUCH_HEIGHT if crouching else STAND_HEIGHT
    _capsule.height = h
    _collider.position.y = h * 0.5
    _visual.scale.y = h / STAND_HEIGHT
    _pivot.position.y = h - 0.3


func _can_stand() -> bool:
    var space := get_world_3d().direct_space_state
    var from := global_position + Vector3.UP * CROUCH_HEIGHT
    var to := global_position + Vector3.UP * (STAND_HEIGHT + 0.05)
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.exclude = [get_rid()]
    return space.intersect_ray(query).is_empty()


func _update_stamina(sprinting: bool, delta: float) -> void:
    var previous := stamina
    if sprinting:
        stamina = maxf(stamina - STAMINA_DRAIN * delta, 0.0)
        if stamina <= 0.0:
            _exhausted = true
    else:
        stamina = minf(stamina + STAMINA_REGEN * delta, max_stamina)
        if _exhausted and stamina >= STAMINA_RECOVER_AT:
            _exhausted = false
    if not is_equal_approx(previous, stamina):
        stamina_changed.emit(stamina, max_stamina)


# ---------------------------------------------------------------- combate

func _equip_weapon(id: String) -> void:
    _weapon_id = id if WeaponsScript.exists(id) else "fists"
    if _weapon_attach != null and is_instance_valid(_weapon_attach):
        _weapon_attach.queue_free()
        _weapon_attach = null
    var model := WeaponsScript.build_model(_weapon_id)
    if model == null:
        return
    var skeleton: Skeleton3D = _rig["skeleton"]
    _weapon_attach = BoneAttachment3D.new()
    skeleton.add_child(_weapon_attach)
    _weapon_attach.bone_name = "farm_r"
    _weapon_attach.add_child(model)


func get_weapon_id() -> String:
    return _weapon_id


func _weapon() -> Dictionary:
    return WeaponsScript.DATA[_weapon_id]


func _update_combat(delta: float) -> void:
    _attack_cd = maxf(_attack_cd - delta, 0.0)
    var w := _weapon()
    if _attack_time > 0.0:
        _attack_time = maxf(_attack_time - delta, 0.0)
        var total := SWING_TIME if w["kind"] == "melee" else 0.12
        var t := 1.0 - _attack_time / total
        if w["kind"] == "melee" and _melee_pending and t >= 0.5:
            _melee_pending = false
            _melee_hit(w)
        HumanoidScript.pose_attack(_rig, t, str(w["anim"]) if w["kind"] == "melee" else "aim")
        _visual.rotation.y = lerp_angle(_visual.rotation.y, _yaw, minf(1.0, 20.0 * delta))
    elif w["kind"] == "gun":
        HumanoidScript.pose_attack(_rig, 0.0, "aim")
    if _attack_cd <= 0.0 and Input.is_action_pressed("attack"):
        if w["kind"] == "gun" and not w.get("auto", false) and _attack_held:
            return
        _attack_held = true
        _start_attack(w)
    if not Input.is_action_pressed("attack"):
        _attack_held = false


func _start_attack(w: Dictionary) -> void:
    _attack_cd = float(w["cooldown"])
    _visual.rotation.y = _yaw # o personagem vira para onde a câmera olha
    if w["kind"] == "melee":
        _attack_time = SWING_TIME
        _melee_pending = true
    else:
        _attack_time = 0.12
        _shoot(w)


## Direção horizontal para onde a câmera olha.
func _aim_forward() -> Vector3:
    return Basis(Vector3.UP, _yaw) * Vector3(0.0, 0.0, -1.0)


func _melee_hit(w: Dictionary) -> void:
    var fwd := _aim_forward()
    var best = null
    var best_score := INF
    var reach := float(w["range"])
    for node in get_tree().get_nodes_in_group("pedestrians"):
        if not node.has_method("hit_by") or node.is_dead():
            continue
        var off: Vector3 = node.global_position - global_position
        off.y = 0.0
        var d := off.length()
        if d > reach or d < 0.001:
            continue
        if off.normalized().dot(fwd) < 0.35: # cerca de 70 graus para cada lado
            continue
        if d < best_score:
            best_score = d
            best = node
    if best != null:
        var dir: Vector3 = best.global_position - global_position
        best.hit_by(self, float(w["damage"]), dir, float(w["knock"]))


func _shoot(w: Dictionary) -> void:
    var space := get_world_3d().direct_space_state
    var cam_from := _camera.global_position
    var cam_dir := -_camera.global_transform.basis.z
    var muzzle := _pivot.global_position + Vector3.UP * 0.0 + _aim_forward() * 0.5
    var spread := float(w["spread"])
    for n in int(w["pellets"]):
        var dir := cam_dir
        if spread > 0.0:
            dir = (dir + Vector3(randf_range(-spread, spread), randf_range(-spread, spread), randf_range(-spread, spread))).normalized()
        var reach := minf(float(w["range"]), AIM_RANGE)
        var q1 := PhysicsRayQueryParameters3D.create(cam_from, cam_from + dir * (reach + 6.0), 3)
        q1.exclude = [get_rid()]
        var h1 := space.intersect_ray(q1)
        var target := cam_from + dir * (reach + 6.0)
        if not h1.is_empty():
            target = h1["position"]
        # segundo raio: da arma até o ponto mirado (para não acertar o que está atrás de uma quina)
        var q2 := PhysicsRayQueryParameters3D.create(muzzle, muzzle + (target - muzzle).normalized() * (reach + 2.0), 3)
        q2.exclude = [get_rid()]
        var h2 := space.intersect_ray(q2)
        var end := muzzle + (target - muzzle).normalized() * reach
        if not h2.is_empty():
            end = h2["position"]
            var body: Object = h2["collider"]
            if body != null and body.has_method("hit_by"):
                body.hit_by(self, float(w["damage"]), end - muzzle, float(w["knock"]))
        if n < 3:
            _spawn_tracer(muzzle, end)


func _spawn_tracer(from: Vector3, to: Vector3) -> void:
    var length := from.distance_to(to)
    if length < 0.5:
        return
    var mi := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(0.03, 0.03, length)
    mi.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1.0, 0.9, 0.5)
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mi.material_override = mat
    get_parent().add_child(mi)
    mi.global_position = (from + to) * 0.5
    mi.look_at(to, Vector3.UP)
    get_tree().create_timer(0.05).timeout.connect(mi.queue_free)


func _update_safe_position(delta: float) -> void:
    _safe_timer -= delta
    if _safe_timer <= 0.0:
        _safe_timer = 0.5
        if is_on_floor() and global_position.y > -0.2 and global_position.y < 3.0:
            _safe_pos = global_position


func _recover_from_water() -> void:
    global_position = _safe_pos + Vector3.UP * 0.3
    velocity = Vector3.ZERO
    take_damage(10.0)


# ----------------------------------------------------------------- vida

func take_damage(amount: float) -> void:
    if amount <= 0.0:
        return
    health = maxf(health - amount, 0.0)
    health_changed.emit(health, max_health)
    if health <= 0.0:
        died.emit()
        respawn()


func heal(amount: float) -> void:
    if amount <= 0.0:
        return
    health = minf(health + amount, max_health)
    health_changed.emit(health, max_health)


func set_health(value: float) -> void:
    health = clampf(value, 1.0, max_health)
    health_changed.emit(health, max_health)


func teleport(pos: Vector3) -> void:
    if _vehicle != null:
        exit_vehicle()
    global_position = pos
    velocity = Vector3.ZERO


func respawn() -> void:
    if _vehicle != null:
        exit_vehicle()
    global_position = spawn_position
    velocity = Vector3.ZERO
    health = max_health
    stamina = max_stamina
    _exhausted = false
    health_changed.emit(health, max_health)
    stamina_changed.emit(stamina, max_stamina)
