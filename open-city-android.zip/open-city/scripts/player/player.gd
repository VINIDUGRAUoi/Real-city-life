class_name Player
extends CharacterBody3D
## Personagem em terceira pessoa + motorista. Colisão, visual e câmera são criados em
## código. O visual é um PLACEHOLDER (cápsula + "nariz" indicando a frente).
## Entrar/sair de veículos: ação "interact" (E) perto de qualquer veículo.

signal health_changed(current: float, maximum: float)
signal stamina_changed(current: float, maximum: float)
signal interact_requested
signal died
signal driving_changed(driving: bool, vehicle_name: String)
signal speed_changed(kmh: float)
signal prompt_changed(vehicle_name: String)

const HumanoidScript := preload("res://scripts/ai/humanoid.gd")

const STAND_HEIGHT := 1.8
const CROUCH_HEIGHT := 1.1
const RADIUS := 0.4
const PITCH_MIN := -1.25
const PITCH_MAX := 0.6
const FALL_LIMIT := -30.0
const STAMINA_DRAIN := 22.0
const STAMINA_REGEN := 18.0
const STAMINA_RECOVER_AT := 25.0
const MOUSE_BASE := 0.0025
const TOUCH_BASE := 0.006
const ENTER_DISTANCE := 4.5
const VEHICLE_CAMERA_DISTANCE := 7.0

@export var walk_speed := 4.0
@export var run_speed := 8.0
@export var crouch_speed := 2.0
@export var jump_velocity := 5.5
@export var acceleration := 25.0
@export var stick_sensitivity := 2.5
@export var camera_distance := 4.5
@export var max_health := 100.0
@export var max_stamina := 100.0

var mouse_sensitivity := MOUSE_BASE
var touch_sensitivity := TOUCH_BASE
var spawn_position := Vector3.ZERO
var health := 0.0
var stamina := 0.0
var crouching := false

var _yaw := 0.0
var _pitch := -0.25
var _exhausted := false
var _vehicle = null
var _touch_move := Vector2.ZERO
var _invert := 1.0
var _rig: Dictionary = {}
var _phase := 0.0
var _prompt := ""
var _prompt_timer := 0.0
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var _collider: CollisionShape3D
var _capsule: CapsuleShape3D
var _visual: Node3D
var _pivot: Node3D
var _arm: SpringArm3D
var _camera: Camera3D


func _ready() -> void:
    collision_layer = 1
    collision_mask = 3 # chão/prédios/veículos + pedestres
    health = max_health
    stamina = max_stamina
    _build_collision()
    _build_visual()
    _build_camera_rig()
    var gs := get_node_or_null("/root/GameSettings")
    if gs != null:
        gs.changed.connect(_apply_settings)
        _apply_settings()
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    health_changed.emit(health, max_health)
    stamina_changed.emit(stamina, max_stamina)


func _apply_settings() -> void:
    var gs := get_node_or_null("/root/GameSettings")
    if gs == null:
        return
    mouse_sensitivity = MOUSE_BASE * gs.sensitivity
    touch_sensitivity = TOUCH_BASE * gs.sensitivity
    _invert = -1.0 if gs.invert_y else 1.0
    if _camera != null:
        _camera.fov = gs.fov
        _camera.far = gs.view_distance


# ---------------------------------------------------------------- construção

func _build_collision() -> void:
    _capsule = CapsuleShape3D.new()
    _capsule.radius = RADIUS
    _capsule.height = STAND_HEIGHT
    _collider = CollisionShape3D.new()
    _collider.shape = _capsule
    _collider.position.y = STAND_HEIGHT * 0.5
    add_child(_collider)


func _build_visual() -> void:
    var outfit := {
        "skin": Color(0.85, 0.65, 0.5), "shirt": Color(0.9, 0.5, 0.1), "pants": Color(0.15, 0.2, 0.35),
        "hair": Color(0.1, 0.07, 0.05), "shoe": Color(0.9, 0.9, 0.9), "long_hair": false,
        "scale": 1.0, "backpack": true,
    }
    _rig = HumanoidScript.build(self, outfit)
    _visual = _rig["root"]


func _build_camera_rig() -> void:
    _pivot = Node3D.new()
    _pivot.position = Vector3(0.0, STAND_HEIGHT - 0.3, 0.0)
    add_child(_pivot)

    _arm = SpringArm3D.new()
    _arm.spring_length = camera_distance
    var probe := SphereShape3D.new()
    probe.radius = 0.25
    _arm.shape = probe
    _arm.add_excluded_object(get_rid())
    _pivot.add_child(_arm)

    _camera = Camera3D.new()
    _camera.fov = 75.0
    _camera.near = 0.1
    _arm.add_child(_camera)
    _camera.make_current()


# ------------------------------------------------------------------- entrada

func _unhandled_input(event: InputEvent) -> void:
    var motion := event as InputEventMouseMotion
    if motion != null:
        # No celular o toque também gera "mouse"; a câmera usa apply_look().
        if not OS.has_feature("mobile") and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
            _yaw -= motion.relative.x * mouse_sensitivity
            _pitch = clampf(_pitch - motion.relative.y * mouse_sensitivity * _invert, PITCH_MIN, PITCH_MAX)
        return

    var click := event as InputEventMouseButton
    if click != null and click.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
        if not OS.has_feature("mobile"):
            Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
        return

    if event.is_action_pressed("interact"):
        _try_interact()
    elif event.is_action_pressed("debug_damage"):
        take_damage(10.0)


func _process(delta: float) -> void:
    var look := Input.get_vector("look_left", "look_right", "look_up", "look_down")
    _yaw -= look.x * stick_sensitivity * delta
    _pitch = clampf(_pitch - look.y * stick_sensitivity * delta * _invert, PITCH_MIN, PITCH_MAX)
    _pivot.rotation = Vector3(_pitch, _yaw, 0.0)


## Analógico virtual do celular (x: direita +, y: para baixo +). Tem prioridade sobre as teclas.
func set_touch_move(value: Vector2) -> void:
    _touch_move = value.limit_length(1.0)


## Chamado pelos controles de toque (deslocamento do dedo em pixels).
func apply_look(relative: Vector2) -> void:
    _yaw -= relative.x * touch_sensitivity
    _pitch = clampf(_pitch - relative.y * touch_sensitivity * _invert, PITCH_MIN, PITCH_MAX)


# ------------------------------------------------------------------- veículos

func is_driving() -> bool:
    return _vehicle != null


func get_forward_xz() -> Vector2:
    var f: Vector3
    if _vehicle != null and is_instance_valid(_vehicle):
        f = -_vehicle.global_transform.basis.z
    else:
        f = -_visual.global_transform.basis.z
    var v := Vector2(f.x, f.z)
    return v.normalized() if v.length() > 0.001 else Vector2(0.0, -1.0)


func _nearest_enterable():
    var best = null
    var best_dist := ENTER_DISTANCE
    for node in get_tree().get_nodes_in_group("enterable"):
        if not node.has_method("can_enter") or not node.can_enter():
            continue
        var off: Vector3 = node.global_position - global_position
        off.y = 0.0
        var d := off.length()
        if d < best_dist:
            best_dist = d
            best = node
    return best


func _try_interact() -> void:
    if _vehicle != null:
        exit_vehicle()
        return
    var target = _nearest_enterable()
    if target != null:
        var drivable = target.get_drivable()
        if drivable != null:
            enter_vehicle(drivable)
        return
    var npc = _nearest_npc(2.6)
    if npc != null:
        npc.talk(self)
        return
    interact_requested.emit()


func _nearest_npc(max_distance: float):
    var best = null
    var best_dist := max_distance
    for node in get_tree().get_nodes_in_group("pedestrians"):
        if not node.has_method("talk"):
            continue
        var off: Vector3 = node.global_position - global_position
        off.y = 0.0
        if off.length() < best_dist:
            best_dist = off.length()
            best = node
    return best


func enter_vehicle(v) -> void:
    _vehicle = v
    v.set_driver(self)
    _visual.visible = false
    collision_layer = 0
    collision_mask = 0
    _collider.set_deferred("disabled", true)
    velocity = Vector3.ZERO
    _arm.add_excluded_object(v.get_rid())
    _arm.spring_length = VEHICLE_CAMERA_DISTANCE
    _pivot.position.y = 1.2
    _set_prompt("")
    driving_changed.emit(true, v.get_display_name())


func exit_vehicle() -> void:
    var v = _vehicle
    if v == null:
        return
    var exit_pos := _find_exit_position(v) if is_instance_valid(v) else global_position
    _vehicle = null
    if is_instance_valid(v):
        v.clear_driver()
        _arm.remove_excluded_object(v.get_rid())
    global_position = exit_pos
    velocity = Vector3.ZERO
    collision_layer = 1
    collision_mask = 3
    _collider.set_deferred("disabled", false)
    _visual.visible = true
    _arm.spring_length = camera_distance
    _pivot.position.y = STAND_HEIGHT - 0.3
    crouching = false
    _capsule.height = STAND_HEIGHT
    _collider.position.y = STAND_HEIGHT * 0.5
    _visual.scale.y = 1.0
    driving_changed.emit(false, "")


func _find_exit_position(v) -> Vector3:
    var xform: Transform3D = v.global_transform
    var origin: Vector3 = xform.origin
    var side := xform.basis.x
    var back := xform.basis.z
    var candidates := [origin - side * 2.4, origin + side * 2.4, origin + back * 3.5, origin - back * 3.5]
    var space := get_world_3d().direct_space_state
    var probe := SphereShape3D.new()
    probe.radius = 0.45
    for c: Vector3 in candidates:
        var ray := PhysicsRayQueryParameters3D.create(c + Vector3.UP * 2.0, c + Vector3.DOWN * 3.0, 1)
        ray.exclude = [v.get_rid()]
        var hit := space.intersect_ray(ray)
        if hit.is_empty():
            continue
        var ground: Vector3 = hit["position"]
        var q := PhysicsShapeQueryParameters3D.new()
        q.shape = probe
        q.transform = Transform3D(Basis(), ground + Vector3.UP * 0.9)
        q.collision_mask = 1
        q.exclude = [v.get_rid()]
        if space.intersect_shape(q, 1).is_empty():
            return ground + Vector3.UP * 0.1
    return origin + Vector3.UP * 2.5


func _set_prompt(text: String) -> void:
    if text != _prompt:
        _prompt = text
        prompt_changed.emit(text)


# ------------------------------------------------------------------- física

func _physics_process(delta: float) -> void:
    if _vehicle != null:
        if not is_instance_valid(_vehicle):
            _vehicle = null
            exit_vehicle()
            return
        _drive_follow(delta)
        return

    _prompt_timer -= delta
    if _prompt_timer <= 0.0:
        _prompt_timer = 0.15
        var near = _nearest_enterable()
        _set_prompt(near.get_display_name() if near != null else "")

    _set_crouching(Input.is_action_pressed("crouch"))

    var move := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    if _touch_move.length() > 0.01:
        move = _touch_move
    var dir := Basis(Vector3.UP, _yaw) * Vector3(move.x, 0.0, move.y)

    var wants_sprint := Input.is_action_pressed("sprint") and move.length() > 0.1 and not crouching
    var sprinting := wants_sprint and not _exhausted and stamina > 0.0
    var speed := walk_speed
    if crouching:
        speed = crouch_speed
    elif sprinting:
        speed = run_speed
    _update_stamina(sprinting, delta)

    var target := dir * speed
    velocity.x = move_toward(velocity.x, target.x, acceleration * delta)
    velocity.z = move_toward(velocity.z, target.z, acceleration * delta)

    if is_on_floor():
        if Input.is_action_just_pressed("jump") and not crouching:
            velocity.y = jump_velocity
    else:
        velocity.y -= _gravity * delta

    move_and_slide()

    var hspeed := Vector2(velocity.x, velocity.z).length()
    _phase += hspeed * delta * 1.6
    HumanoidScript.animate(_rig, _phase, clampf(hspeed / 3.0, 0.0, 1.0))

    if dir.length() > 0.1:
        var target_angle := atan2(-dir.x, -dir.z)
        _visual.rotation.y = lerp_angle(_visual.rotation.y, target_angle, 12.0 * delta)

    if global_position.y < FALL_LIMIT:
        respawn()


func _drive_follow(delta: float) -> void:
    global_position = _vehicle.global_position
    var spd: float = _vehicle.get_speed()
    if spd > 3.0:
        var fwd: Vector3 = -_vehicle.global_transform.basis.z
        _yaw = lerp_angle(_yaw, atan2(-fwd.x, -fwd.z), minf(1.0, 3.0 * delta))
    speed_changed.emit(spd * 3.6)


func _set_crouching(value: bool) -> void:
    if value == crouching:
        return
    if not value and not _can_stand():
        return
    crouching = value
    var h := CROUCH_HEIGHT if crouching else STAND_HEIGHT
    _capsule.height = h
    _collider.position.y = h * 0.5
    _visual.scale.y = h / STAND_HEIGHT
    _pivot.position.y = h - 0.3


func _can_stand() -> bool:
    var space := get_world_3d().direct_space_state
    var from := global_position + Vector3.UP * CROUCH_HEIGHT
    var to := global_position + Vector3.UP * (STAND_HEIGHT + 0.05)
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.exclude = [get_rid()]
    return space.intersect_ray(query).is_empty()


func _update_stamina(sprinting: bool, delta: float) -> void:
    var previous := stamina
    if sprinting:
        stamina = maxf(stamina - STAMINA_DRAIN * delta, 0.0)
        if stamina <= 0.0:
            _exhausted = true
    else:
        stamina = minf(stamina + STAMINA_REGEN * delta, max_stamina)
        if _exhausted and stamina >= STAMINA_RECOVER_AT:
            _exhausted = false
    if not is_equal_approx(previous, stamina):
        stamina_changed.emit(stamina, max_stamina)


# ----------------------------------------------------------------- vida

func take_damage(amount: float) -> void:
    if amount <= 0.0:
        return
    health = maxf(health - amount, 0.0)
    health_changed.emit(health, max_health)
    if health <= 0.0:
        died.emit()
        respawn()


func heal(amount: float) -> void:
    if amount <= 0.0:
        return
    health = minf(health + amount, max_health)
    health_changed.emit(health, max_health)


func set_health(value: float) -> void:
    health = clampf(value, 1.0, max_health)
    health_changed.emit(health, max_health)


func teleport(pos: Vector3) -> void:
    if _vehicle != null:
        exit_vehicle()
    global_position = pos
    velocity = Vector3.ZERO


func respawn() -> void:
    if _vehicle != null:
        exit_vehicle()
    global_position = spawn_position
    velocity = Vector3.ZERO
    health = max_health
    stamina = max_stamina
    _exhausted = false
    health_changed.emit(health, max_health)
    stamina_changed.emit(stamina, max_stamina)
