extends CanvasLayer
## Celular (tecla P / botão "Cel"). Aplicativos: Armas (comprar e escolher a arma em uso),
## Carros (comprar), Garagem (chamar um carro seu: ele aparece ao seu lado), GPS (ir para
## outra cidade) e Mapa. O dinheiro, as armas e os carros ficam no GameState e são salvos.

const ShopScript := preload("res://scripts/core/shop.gd")
const WeaponsScript := preload("res://scripts/combat/weapons.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const FoldersScript := preload("res://scripts/core/skin_folders.gd")
const VehicleSkinScript := preload("res://scripts/vehicles/vehicle_skin.gd")

var player: Node3D
var map_screen: Node
var is_open := false

var _panel: PanelContainer
var _title: Label
var _money: Label
var _message: Label
var _list: VBoxContainer
var _back: Button
var _page := "home"
var _spawned := {} # id do carro -> nó do carro chamado


func _ready() -> void:
    layer = 10
    process_mode = Node.PROCESS_MODE_ALWAYS
    visible = false

    var root := Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var theme := Theme.new()
    theme.default_font_size = 22
    root.theme = theme

    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.0, 0.6)
    root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var center := CenterContainer.new()
    root.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    _panel = PanelContainer.new()
    center.add_child(_panel)
    var margin := MarginContainer.new()
    for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
        margin.add_theme_constant_override(side, 14)
    _panel.add_child(margin)
    var stack := VBoxContainer.new()
    margin.add_child(stack)

    var header := HBoxContainer.new()
    stack.add_child(header)
    _back = Button.new()
    _back.text = "< Início"
    _back.pressed.connect(func() -> void: _show_home())
    header.add_child(_back)
    _title = Label.new()
    _title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    header.add_child(_title)
    var close_button := Button.new()
    close_button.text = "Fechar"
    close_button.pressed.connect(close)
    header.add_child(close_button)

    _money = Label.new()
    _money.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _money.add_theme_color_override("font_color", Color(0.5, 1.0, 0.5))
    stack.add_child(_money)
    _message = Label.new()
    _message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    stack.add_child(_message)

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    stack.add_child(scroll)
    _list = VBoxContainer.new()
    _list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(_list)

    GameState.money_changed.connect(_refresh_money)
    _refresh_money()


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("phone"):
        if is_open:
            close()
        elif not get_tree().paused:
            open()
        get_viewport().set_input_as_handled()
    elif is_open and event.is_action_pressed("pause"):
        close()
        get_viewport().set_input_as_handled()


func open() -> void:
    var vp := get_viewport().get_visible_rect().size
    _panel.custom_minimum_size = Vector2(minf(vp.x * 0.92, 640.0), vp.y * 0.92)
    visible = true
    is_open = true
    _message.text = ""
    _show_home()
    GameState.set_paused(true)


func close() -> void:
    visible = false
    is_open = false
    GameState.set_paused(false)


func _refresh_money() -> void:
    if _money != null:
        _money.text = "Saldo: " + ShopScript.fmt_money(GameState.money)


func _clear() -> void:
    for child in _list.get_children():
        _list.remove_child(child)
        child.queue_free()


func _set_page(page: String, title: String) -> void:
    _page = page
    _title.text = title
    _back.visible = page != "home"
    _clear()


func _button(text: String, callback: Callable, min_width: float = 0.0) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(min_width, 54.0)
    b.pressed.connect(callback)
    return b


func _row(label_text: String, button: Button) -> void:
    var row := HBoxContainer.new()
    _list.add_child(row)
    var label := Label.new()
    label.text = label_text
    label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    row.add_child(label)
    row.add_child(button)


# ------------------------------------------------------------------- páginas

func _show_home() -> void:
    _set_page("home", "Celular")
    for item in [["Loja de armas", "weapons"], ["Concessionária (comprar carros)", "cars"], ["Minha garagem (chamar carro)", "garage"], ["GPS entre cidades", "gps"], ["Skins (carros e personagem)", "skins"], ["Mapa", "map"]]:
        var page: String = item[1]
        var b := _button(item[0], func() -> void: _open_page(page))
        _list.add_child(b)


func _open_page(page: String) -> void:
    _message.text = ""
    match page:
        "weapons":
            _show_weapons()
        "cars":
            _show_cars()
        "garage":
            _show_garage()
        "gps":
            _show_gps()
        "skins":
            _show_skins()
        "map":
            close()
            if map_screen != null:
                map_screen.open()


func _show_weapons() -> void:
    _set_page("weapons", "Loja de armas")
    for id: String in WeaponsScript.ORDER:
        var w: Dictionary = WeaponsScript.DATA[id]
        var info := "%s\n%s" % [w["name"], w["desc"]]
        if GameState.has_weapon(id):
            if GameState.weapon_id == id:
                var b := _button("Em uso", func() -> void: pass, 170.0)
                b.disabled = true
                _row(info, b)
            else:
                _row(info, _button("Equipar", func() -> void: _equip(id), 170.0))
        else:
            _row(info, _button(ShopScript.fmt_money(int(w["price"])), func() -> void: _buy_weapon(id), 170.0))


func _buy_weapon(id: String) -> void:
    if GameState.buy_weapon(id):
        GameState.equip_weapon(id)
        _message.text = "Você comprou: %s (equipada)." % WeaponsScript.weapon_name(id)
    else:
        _message.text = "Dinheiro insuficiente."
    _show_weapons()


func _equip(id: String) -> void:
    GameState.equip_weapon(id)
    _message.text = "Arma em uso: %s." % WeaponsScript.weapon_name(id)
    _show_weapons()


func _show_cars() -> void:
    _set_page("cars", "Concessionária")
    for id: String in ShopScript.car_ids():
        var label := "%s" % ShopScript.car_name(id)
        if GameState.has_car(id):
            var b := _button("Você tem", func() -> void: pass, 170.0)
            b.disabled = true
            _row(label, b)
        else:
            _row(label, _button(ShopScript.fmt_money(ShopScript.car_price(id)), func() -> void: _buy_car(id), 170.0))


func _buy_car(id: String) -> void:
    var colors: Array = DataScript.TYPES[id]["colors"]
    var color: Color = colors.pick_random()
    if GameState.buy_car(id, color.to_html()):
        _message.text = "Comprado: %s! Chame o carro na Minha garagem." % ShopScript.car_name(id)
    else:
        _message.text = "Dinheiro insuficiente."
    _show_cars()


func _show_garage() -> void:
    _set_page("garage", "Minha garagem")
    var ids: Array = GameState.owned_cars.keys()
    if ids.is_empty():
        var empty := Label.new()
        empty.text = "Você ainda não comprou nenhum carro."
        empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        _list.add_child(empty)
        return
    ids.sort_custom(func(a: String, b: String) -> bool: return ShopScript.car_name(a) < ShopScript.car_name(b))
    for id: String in ids:
        _row(ShopScript.car_name(id), _button("Chamar", func() -> void: _call_car(id), 170.0))


## Faz o carro aparecer ao lado do jogador. Se você já chamou esse carro antes e ninguém
## está dentro, ele é movido para perto de você.
func _call_car(id: String) -> void:
    if player == null or not is_instance_valid(player):
        return
    var old: Variant = _spawned.get(id)
    if old != null and is_instance_valid(old):
        if old.driver != null:
            _message.text = "Você já está nesse carro."
            return
        old.queue_free()
    var color := Color(str(GameState.owned_cars[id]))
    var car = FactoryScript.create(id, color)
    var fwd: Vector2 = player.get_forward_xz()
    var right := Vector2(-fwd.y, fwd.x)
    var ahead := 9.0 if player.is_driving() else 4.0
    var xz := Vector2(player.global_position.x, player.global_position.z) + fwd * ahead + right * 3.0
    car.position = Vector3(xz.x, player.global_position.y + 1.4, xz.y)
    car.rotation.y = atan2(-fwd.x, -fwd.y)
    player.get_parent().add_child(car)
    _spawned[id] = car
    close()


func _show_gps() -> void:
    _set_page("gps", "GPS")
    for ci in GraphScript.city_count():
        var index := ci
        _row(GraphScript.city_name(ci), _button("Ir", func() -> void: _go_to_city(index), 120.0))
    var cancel := _button("Cancelar destino", func() -> void:
        GameState.clear_waypoint()
        _message.text = "Destino removido.")
    _list.add_child(cancel)


func _show_skins() -> void:
    _set_page("skins", "Skins")
    var info := Label.new()
    info.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
    info.text = "Pasta de skins do jogo:\n%s\n\nColoque os arquivos nas pastas carros/<id> e jogador/ (veja o LEIA-ME.txt dentro dela) e toque em Recarregar.\n\n%s" % [FoldersScript.root_dir(), FoldersScript.report()]
    _list.add_child(info)
    _list.add_child(_button("Recarregar skins", func() -> void: _reload_skins()))
    _list.add_child(_button("Copiar caminho da pasta", func() -> void:
        DisplayServer.clipboard_set(FoldersScript.root_dir())
        _message.text = "Caminho copiado."))


func _reload_skins() -> void:
    FoldersScript.setup()
    VehicleSkinScript.reload()
    if player != null and is_instance_valid(player):
        player.reload_skin()
    _message.text = "Skins recarregadas. Carros novos (chamados ou do trânsito) já usam as skins novas."
    _show_skins()


func _go_to_city(ci: int) -> void:
    var target := GraphScript.snap_to_road(GraphScript.city_center(ci))
    GameState.set_waypoint(target)
    if player != null:
        GameState.update_route(Vector2(player.global_position.x, player.global_position.z))
    close()
