extends CanvasLayer
## Celular (tecla P / botão "Cel"). Aplicativos: Armas (comprar e escolher a arma em uso),
## Carros (comprar), Garagem (chamar um carro seu: ele aparece ao seu lado), GPS (ir para
## outra cidade) e Mapa. O dinheiro, as armas e os carros ficam no GameState e são salvos.

const ShopScript := preload("res://scripts/core/shop.gd")
const WeaponsScript := preload("res://scripts/combat/weapons.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const ShopNamesScript := preload("res://scripts/core/shop.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const FoldersScript := preload("res://scripts/core/skin_folders.gd")
const BusinessScript := preload("res://scripts/jobs/business.gd")
const JobManagerScript := preload("res://scripts/jobs/job_manager.gd")
const VehicleSkinScript := preload("res://scripts/vehicles/vehicle_skin.gd")

var player: Node3D
var map_screen: Node
var jobs: Node # JobManager (scripts/jobs/job_manager.gd)
var is_open := false

var _panel: PanelContainer
var _title: Label
var _money: Label
var _message: Label
var _list: VBoxContainer
var _back: Button
var _page := "home"
var _spawned := {} # id do carro -> nó do carro chamado


func _ready() -> void:
    layer = 10
    process_mode = Node.PROCESS_MODE_ALWAYS
    visible = false

    var root := Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var theme := Theme.new()
    theme.default_font_size = 22
    root.theme = theme

    var dim := ColorRect.new()
    dim.color = Color(0.0, 0.0, 0.0, 0.6)
    root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var center := CenterContainer.new()
    root.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    _panel = PanelContainer.new()
    center.add_child(_panel)
    var margin := MarginContainer.new()
    for side in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
        margin.add_theme_constant_override(side, 14)
    _panel.add_child(margin)
    var stack := VBoxContainer.new()
    margin.add_child(stack)

    var header := HBoxContainer.new()
    stack.add_child(header)
    _back = Button.new()
    _back.text = "< Início"
    _back.pressed.connect(func() -> void: _show_home())
    header.add_child(_back)
    _title = Label.new()
    _title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    header.add_child(_title)
    var close_button := Button.new()
    close_button.text = "Fechar"
    close_button.pressed.connect(close)
    header.add_child(close_button)

    _money = Label.new()
    _money.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _money.add_theme_color_override("font_color", Color(0.5, 1.0, 0.5))
    stack.add_child(_money)
    _message = Label.new()
    _message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    stack.add_child(_message)

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    stack.add_child(scroll)
    _list = VBoxContainer.new()
    _list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(_list)

    GameState.money_changed.connect(_refresh_money)
    _refresh_money()


func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("phone"):
        if is_open:
            close()
        elif not get_tree().paused:
            open()
        get_viewport().set_input_as_handled()
    elif is_open and event.is_action_pressed("pause"):
        close()
        get_viewport().set_input_as_handled()


func open() -> void:
    var vp := get_viewport().get_visible_rect().size
    _panel.custom_minimum_size = Vector2(minf(vp.x * 0.92, 640.0), vp.y * 0.92)
    visible = true
    is_open = true
    _message.text = ""
    _show_home()
    GameState.set_paused(true)


func close() -> void:
    visible = false
    is_open = false
    GameState.set_paused(false)


func _refresh_money() -> void:
    if _money != null:
        _money.text = "Saldo: " + ShopScript.fmt_money(GameState.money)


func _clear() -> void:
    for child in _list.get_children():
        _list.remove_child(child)
        child.queue_free()


func _set_page(page: String, title: String) -> void:
    _page = page
    _title.text = title
    _back.visible = page != "home"
    _clear()


func _button(text: String, callback: Callable, min_width: float = 0.0) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(min_width, 54.0)
    b.pressed.connect(callback)
    return b


func _row(label_text: String, button: Button) -> void:
    var row := HBoxContainer.new()
    _list.add_child(row)
    var label := Label.new()
    label.text = label_text
    label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    row.add_child(label)
    row.add_child(button)


# ------------------------------------------------------------------- páginas

func _show_home() -> void:
    _set_page("home", "Celular")
    for item in [["Loja de armas", "weapons"], ["Trabalhos", "jobs"], ["Minha loja (comerciante)", "business"], ["Concessionária (carros e motos)", "cars"], ["Minha garagem (chamar veículo)", "garage"], ["GPS entre cidades", "gps"], ["Skins (carros e personagem)", "skins"], ["Mapa", "map"]]:
        var page: String = item[1]
        var b := _button(item[0], func() -> void: _open_page(page))
        _list.add_child(b)


func _open_page(page: String) -> void:
    _message.text = ""
    match page:
        "weapons":
            _show_weapons()
        "cars":
            _show_cars()
        "garage":
            _show_garage()
        "gps":
            _show_gps()
        "skins":
            _show_skins()
        "jobs":
            _show_jobs()
        "business":
            _show_business()
        "map":
            close()
            if map_screen != null:
                map_screen.open()


func _show_weapons() -> void:
    _set_page("weapons", "Loja de armas")
    for id: String in WeaponsScript.ORDER:
        var w: Dictionary = WeaponsScript.DATA[id]
        var info := "%s\n%s" % [w["name"], w["desc"]]
        if GameState.has_weapon(id):
            if GameState.weapon_id == id:
                var b := _button("Em uso", func() -> void: pass, 170.0)
                b.disabled = true
                _row(info, b)
            else:
                _row(info, _button("Equipar", func() -> void: _equip(id), 170.0))
        else:
            _row(info, _button(ShopScript.fmt_money(int(w["price"])), func() -> void: _buy_weapon(id), 170.0))


func _buy_weapon(id: String) -> void:
    if GameState.buy_weapon(id):
        GameState.equip_weapon(id)
        _message.text = "Você comprou: %s (equipada)." % WeaponsScript.weapon_name(id)
    else:
        _message.text = "Dinheiro insuficiente."
    _show_weapons()


func _equip(id: String) -> void:
    GameState.equip_weapon(id)
    _message.text = "Arma em uso: %s." % WeaponsScript.weapon_name(id)
    _show_weapons()


func _show_cars() -> void:
    _set_page("cars", "Concessionária")
    for id: String in ShopScript.car_ids():
        var label := "%s" % ShopScript.car_name(id)
        if GameState.has_car(id):
            var b := _button("Você tem", func() -> void: pass, 170.0)
            b.disabled = true
            _row(label, b)
        else:
            _row(label, _button(ShopScript.fmt_money(ShopScript.car_price(id)), func() -> void: _buy_car(id), 170.0))


func _buy_car(id: String) -> void:
    var colors: Array = DataScript.TYPES[id]["colors"]
    var color: Color = colors.pick_random()
    if GameState.buy_car(id, color.to_html()):
        _message.text = "Comprado: %s! Chame o carro na Minha garagem." % ShopScript.car_name(id)
    else:
        _message.text = "Dinheiro insuficiente."
    _show_cars()


func _show_garage() -> void:
    _set_page("garage", "Minha garagem")
    var ids: Array = GameState.owned_cars.keys()
    if ids.is_empty():
        var empty := Label.new()
        empty.text = "Você ainda não comprou nenhum carro."
        empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        _list.add_child(empty)
        return
    ids.sort_custom(func(a: String, b: String) -> bool: return ShopScript.car_name(a) < ShopScript.car_name(b))
    for id: String in ids:
        _row(ShopScript.car_name(id), _button("Chamar", func() -> void: _call_car(id), 170.0))


## Faz o carro aparecer ao lado do jogador. Se você já chamou esse carro antes e ninguém
## está dentro, ele é movido para perto de você.
func _call_car(id: String) -> void:
    if player == null or not is_instance_valid(player):
        return
    var old: Variant = _spawned.get(id)
    if old != null and is_instance_valid(old):
        if old.driver != null:
            _message.text = "Você já está nesse carro."
            return
        old.queue_free()
    var color := Color(str(GameState.owned_cars[id]))
    var car = FactoryScript.create(id, color)
    var fwd: Vector2 = player.get_forward_xz()
    var right := Vector2(-fwd.y, fwd.x)
    var ahead := 9.0 if player.is_driving() else 4.0
    var xz := Vector2(player.global_position.x, player.global_position.z) + fwd * ahead + right * 3.0
    car.position = Vector3(xz.x, player.global_position.y + 1.4, xz.y)
    car.rotation.y = atan2(-fwd.x, -fwd.y)
    player.get_parent().add_child(car)
    _spawned[id] = car
    close()


func _show_gps() -> void:
    _set_page("gps", "GPS")
    for ci in GraphScript.city_count():
        var index := ci
        _row(GraphScript.city_name(ci), _button("Ir", func() -> void: _go_to_city(index), 120.0))
    var cancel := _button("Cancelar destino", func() -> void:
        GameState.clear_waypoint()
        _message.text = "Destino removido.")
    _list.add_child(cancel)


# ----------------------------------------------------------------- trabalhos

func _show_jobs() -> void:
    _set_page("jobs", "Trabalhos")
    if jobs == null:
        var none := Label.new()
        none.text = "Trabalhos indisponíveis."
        _list.add_child(none)
        return
    if jobs.active != "":
        var st := Label.new()
        st.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        st.text = "Em turno: %s\nGanho no turno: %s" % [JobManagerScript.JOBS[jobs.active]["name"], ShopScript.fmt_money(jobs.earned)]
        _list.add_child(st)
        _list.add_child(_button("Encerrar turno", func() -> void:
            jobs.stop()
            close()))
    for kind: String in JobManagerScript.ORDER:
        var info: Dictionary = JobManagerScript.JOBS[kind]
        var total := int(GameState.job_totals.get(kind, 0))
        var text := "%s\nPrecisa de %s. Total ganho: %s" % [info["name"], info["need"], ShopScript.fmt_money(total)]
        if kind == "bus":
            _row(text, _button("Linhas", func() -> void: _show_bus_routes(), 150.0))
        else:
            _row(text, _button("Começar", func() -> void: _start_job(kind, ""), 150.0))
        _list.add_child(_button("Pegar o veículo da empresa (grátis)", func() -> void: _company_vehicle(kind)))


func _show_bus_routes() -> void:
    _set_page("jobs", "Linhas de ônibus")
    for rid: String in JobManagerScript.BUS_ROUTE_ORDER:
        var route: Dictionary = JobManagerScript.BUS_ROUTES[rid]
        _row("%s\n%d pontos, tarifa %s" % [route["name"], (route["nodes"] as Array).size(), ShopScript.fmt_money(int(route["fare"]))], _button("Começar", func() -> void: _start_job("bus", rid), 150.0))


func _start_job(kind: String, route: String) -> void:
    var err: String = jobs.start(kind, route)
    if err != "":
        _message.text = err
        return
    close()


func _company_vehicle(kind: String) -> void:
    var err: String = jobs.spawn_company_vehicle(kind)
    if err != "":
        _message.text = err
        return
    close()


# ------------------------------------------------------------------- negócio

func _show_business() -> void:
    _set_page("business", "Minha loja")
    GameState.tick_business()
    var b: Dictionary = GameState.business
    if not BusinessScript.exists(b):
        var intro := Label.new()
        intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        intro.text = "Abra um negócio, compre estoque e a loja vende sozinha, até com o jogo fechado (até 8 horas). Depois é só recolher o caixa."
        _list.add_child(intro)
        for type: String in BusinessScript.ORDER:
            var t: Dictionary = BusinessScript.TYPES[type]
            _row("%s\nVende cerca de %.1f %s por minuto a %s" % [t["name"], float(t["rate"]), t["item"], ShopScript.fmt_money(int(t["sell_price"]))], _button(ShopScript.fmt_money(int(t["price"])), func() -> void: _open_business(type), 170.0))
        return
    var info: Dictionary = BusinessScript.info(b)
    var status := Label.new()
    status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    status.text = "%s - nível %d\nEstoque: %d de %d %s\nVendas: %.1f por minuto (%s cada)\nCaixa: %s" % [info["name"], BusinessScript.level(b), int(b["stock"]), BusinessScript.capacity(b), info["item"], BusinessScript.rate(b), ShopScript.fmt_money(int(info["sell_price"])), ShopScript.fmt_money(int(b["cash"]))]
    _list.add_child(status)
    _list.add_child(_button("Recolher o caixa (%s)" % ShopScript.fmt_money(int(b["cash"])), func() -> void: _collect_cash()))
    _list.add_child(_button("Comprar 50 de estoque (%s)" % ShopScript.fmt_money(BusinessScript.stock_cost(b, 50)), func() -> void: _buy_stock(50)))
    _list.add_child(_button("Encher o estoque (%s)" % ShopScript.fmt_money(BusinessScript.stock_cost(b, BusinessScript.free_space(b))), func() -> void: _buy_stock(BusinessScript.free_space(GameState.business))))
    if BusinessScript.level(b) < BusinessScript.MAX_LEVEL:
        _list.add_child(_button("Melhorar a loja (%s)" % ShopScript.fmt_money(BusinessScript.upgrade_cost(b)), func() -> void: _upgrade_business()))


func _open_business(type: String) -> void:
    _message.text = "Negócio aberto! Compre estoque para começar a vender." if GameState.open_business(type) else "Dinheiro insuficiente."
    _show_business()


func _collect_cash() -> void:
    var cash := GameState.collect_business_cash()
    _message.text = "Você recolheu %s." % ShopScript.fmt_money(cash) if cash > 0 else "O caixa está vazio."
    _show_business()


func _buy_stock(units: int) -> void:
    _message.text = "Estoque comprado." if GameState.buy_stock(units) else "Sem dinheiro ou sem espaço no estoque."
    _show_business()


func _upgrade_business() -> void:
    _message.text = "Loja melhorada! Agora vende mais por minuto." if GameState.upgrade_business() else "Dinheiro insuficiente."
    _show_business()


func _show_skins() -> void:
    _set_page("skins", "Skins")
    var info := Label.new()
    info.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
    info.text = "Pastas de skins (carros/<id> e jogador/, veja o LEIA-ME.txt dentro delas):\n%s" % FoldersScript.report()
    _list.add_child(info)
    if OS.get_name() == "Android":
        var help := Label.new()
        help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        help.text = "\nPara criar a pasta RealCityLife no armazenamento do celular: toque em Permitir acesso, ative \"Permitir gerenciar todos os arquivos\" para o jogo, volte e toque em Recarregar."
        _list.add_child(help)
        _list.add_child(_button("Permitir acesso a arquivos", func() -> void:
            OS.request_permissions()
            _message.text = "Depois de permitir, volte ao jogo e toque em Recarregar skins."))
    _list.add_child(_button("Recarregar skins", func() -> void: _reload_skins()))
    _list.add_child(_button("Ver nomes das pastas dos carros", func() -> void: _show_car_folders()))
    _list.add_child(_button("Copiar caminho da pasta", func() -> void:
        DisplayServer.clipboard_set(FoldersScript.main_root())
        _message.text = "Caminho copiado: " + FoldersScript.main_root()))


func _reload_skins() -> void:
    FoldersScript.setup()
    VehicleSkinScript.reload()
    if player != null and is_instance_valid(player):
        player.reload_skin()
    var replaced := _refresh_world_cars()
    _message.text = "Skins recarregadas. %d carros parados foram atualizados; o trânsito se renova sozinho." % replaced
    _show_skins()


## Refaz os carros parados e vazios que já estão no mundo, para usarem as skins novas.
func _refresh_world_cars() -> int:
    var count := 0
    for node in get_tree().get_nodes_in_group("vehicles"):
        if not is_instance_valid(node) or node.driver != null:
            continue
        var parent := node.get_parent()
        if parent == null:
            continue
        var car = FactoryScript.create(node.type_id, node.body_color)
        car.transform = node.transform
        car.recyclable = node.recyclable
        for id in _spawned.keys():
            if _spawned[id] == node:
                _spawned[id] = car
        parent.remove_child(node)
        node.free()
        parent.add_child(car)
        count += 1
    var npcs := get_tree().root.find_child("NpcManager", true, false)
    if npcs != null and npcs.has_method("refresh_cars"):
        npcs.refresh_cars()
    return count


func _show_car_folders() -> void:
    _set_page("skins", "Pastas dos carros")
    var root := FoldersScript.main_root()
    var intro := Label.new()
    intro.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
    intro.text = "Cada carro tem uma pasta com o nome (id) abaixo, dentro de:\n%s/carros/" % root
    _list.add_child(intro)
    var ids: Array = DataScript.IDS.duplicate()
    ids.sort_custom(func(a: String, b: String) -> bool: return ShopNamesScript.car_name(a) < ShopNamesScript.car_name(b))
    for id: String in ids:
        var row := Label.new()
        row.text = "%s  ->  %s" % [ShopNamesScript.car_name(id), id]
        _list.add_child(row)


func _go_to_city(ci: int) -> void:
    var target := GraphScript.snap_to_road(GraphScript.city_center(ci))
    GameState.set_waypoint(target)
    if player != null:
        GameState.update_route(Vector2(player.global_position.x, player.global_position.z))
    close()
