extends Control
## Controles de toque (Android). A pé: analógico flutuante, arrastar para girar a câmera,
## botões Pular/Correr/Agachar/Usar. Dirigindo: setas de direção, Acelerar, Freio,
## Freio de mão, Buzina e Sair. Tocar no minimapa abre o mapa. Tamanho, opacidade e
## modo canhoto vêm das configurações (GameSettings). Tudo desenhado em código.

signal look_dragged(relative: Vector2)
## Posição do analógico virtual (x: direita +, y: para baixo +), de -1 a 1. Vai direto ao jogador.
signal move_changed(value: Vector2)

const STICK_RADIUS := 90.0
const DEADZONE := 0.15
const MINIMAP_POS := Vector2(16.0, 84.0)
const MINIMAP_SIZE := Vector2(170.0, 170.0)
const VirtualInput := preload("res://scripts/core/virtual_input.gd")
## Mostra uma linha de diagnóstico no topo ao dirigir (dedos na tela, força de cada ação, toques cancelados).
## Ponha false quando o problema de toque estiver resolvido.
const DEBUG_TOUCH := true

var _driving := false
var _stick_id := -1
var _stick_origin := Vector2.ZERO
var _stick_pos := Vector2.ZERO
var _look_id := -1
var _held := {} # índice do dedo -> nome do botão
var _applied := {} # ações que os botões estão mantendo pressionadas
var _fingers := {} # dedos atualmente na tela (índice -> true), só para diagnóstico
var _cancels := 0
var _auto_gas := false # acelerador travado: botão "Auto" liga/desliga


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    get_viewport().size_changed.connect(queue_redraw)
    GameSettings.changed.connect(_on_settings_changed)
    _on_settings_changed()
    set_process(true)


func _on_settings_changed() -> void:
    modulate = Color(1.0, 1.0, 1.0, GameSettings.touch_opacity)
    queue_redraw()


## Troca o layout (a pé / dirigindo).
func set_driving(value: bool) -> void:
    if value == _driving:
        return
    reset_state()
    _driving = value
    queue_redraw()


func _notification(what: int) -> void:
    # Ao pausar/despausar, os "soltar dedo" se perdem: zera tudo para não ficar andando sozinho.
    if what == NOTIFICATION_PAUSED or what == NOTIFICATION_UNPAUSED:
        reset_state()


func reset_state() -> void:
    _held.clear()
    _auto_gas = false
    _fingers.clear()
    _apply_buttons()
    if _stick_id != -1:
        _update_stick(Vector2.ZERO)
    move_changed.emit(Vector2.ZERO)
    _stick_id = -1
    _look_id = -1
    queue_redraw()


func _minimap_rect() -> Rect2:
    var s: float = GameSettings.hud_scale
    return Rect2(MINIMAP_POS * s, MINIMAP_SIZE * s)


func _buttons() -> Dictionary:
    var s := get_viewport_rect().size
    var k: float = GameSettings.touch_scale
    var mirror: bool = GameSettings.left_handed
    var b := {
        "pause": {"action": "pause", "pos": Vector2(s.x - 70.0, 50.0), "r": 34.0 * k, "label": "Menu"},
        "minimap": {"action": "map", "pos": _minimap_rect().get_center(), "r": 0.0, "hidden": true},
    }
    var defs := {}
    if _driving:
        defs["steer_left"] = ["move_left", Vector2(110.0, s.y - 110.0), 62.0, "", "left"]
        defs["steer_right"] = ["move_right", Vector2(290.0, s.y - 110.0), 62.0, "", "right"]
        defs["gas"] = ["move_forward", Vector2(s.x - 110.0, s.y - 140.0), 72.0, "Acelerar", ""]
        defs["brake"] = ["move_back", Vector2(s.x - 270.0, s.y - 100.0), 54.0, "Freio", ""]
        defs["handbrake"] = ["jump", Vector2(s.x - 110.0, s.y - 290.0), 42.0, "F. mão", ""]
        defs["exit"] = ["interact", Vector2(s.x - 270.0, s.y - 220.0), 42.0, "Sair", ""]
        defs["horn"] = ["horn", Vector2(s.x - 400.0, s.y - 150.0), 38.0, "Buzina", ""]
        defs["auto"] = ["auto_gas", Vector2(s.x - 400.0, s.y - 265.0), 40.0, "Auto", ""]
    else:
        defs["jump"] = ["jump", Vector2(s.x - 110.0, s.y - 130.0), 60.0, "Pular", ""]
        defs["interact"] = ["interact", Vector2(s.x - 260.0, s.y - 90.0), 45.0, "Usar", ""]
        defs["crouch"] = ["crouch", Vector2(s.x - 260.0, s.y - 200.0), 45.0, "Agachar", ""]
        defs["sprint"] = ["sprint", Vector2(s.x - 110.0, s.y - 270.0), 45.0, "Correr", ""]
    for name: String in defs:
        var d: Array = defs[name]
        var pos: Vector2 = d[1]
        if mirror:
            pos.x = s.x - pos.x
        var entry := {"action": d[0], "pos": pos, "r": float(d[2]) * k}
        if d[4] != "":
            entry["icon"] = d[4]
        else:
            entry["label"] = d[3]
        b[name] = entry
    return b


func _button_at(pos: Vector2) -> String:
    if GameSettings.show_minimap and _minimap_rect().has_point(pos):
        return "minimap"
    var layout := _buttons()
    for name: String in layout:
        var b: Dictionary = layout[name]
        if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.2:
            return name
    return ""


func _in_stick_zone(pos: Vector2) -> bool:
    var width := get_viewport_rect().size.x
    if GameSettings.left_handed:
        return pos.x > width * 0.55
    return pos.x < width * 0.45


func _input(event: InputEvent) -> void:
    var touch := event as InputEventScreenTouch
    if touch != null:
        if touch.pressed and not touch.canceled:
            _fingers[touch.index] = true
            if touch.index == _stick_id or touch.index == _look_id or _held.has(touch.index):
                _on_release(touch.index) # dedo "preso" de um toque perdido
            _on_press(touch.index, touch.position)
        else:
            _fingers.erase(touch.index)
            if touch.canceled:
                _cancels += 1
            _on_release(touch.index)
        return
    var drag := event as InputEventScreenDrag
    if drag != null:
        _on_drag(drag.index, drag.position, drag.relative)


func _on_press(index: int, pos: Vector2) -> void:
    var name := _button_at(pos)
    if name != "":
        _held[index] = name
        if name == "auto":
            _auto_gas = not _auto_gas
        _apply_buttons()
    elif not _driving and _in_stick_zone(pos) and _stick_id == -1:
        _stick_id = index
        _stick_origin = pos
        _stick_pos = pos
    elif _look_id == -1:
        _look_id = index
    queue_redraw()


func _on_release(index: int) -> void:
    if _held.has(index):
        _held.erase(index)
        _apply_buttons()
    if index == _stick_id:
        _stick_id = -1
        _update_stick(Vector2.ZERO)
    if index == _look_id:
        _look_id = -1
    queue_redraw()


func _on_drag(index: int, pos: Vector2, relative: Vector2) -> void:
    if index == _stick_id:
        _stick_pos = pos
        var v := (_stick_pos - _stick_origin) / STICK_RADIUS
        if v.length() > 1.0:
            v = v.normalized()
        if v.length() < DEADZONE:
            v = Vector2.ZERO
        _update_stick(v)
        queue_redraw()
    elif index == _look_id:
        look_dragged.emit(relative)


## Ações que os botões seguram agora. Cada botão é independente: acelerar e virar ao mesmo tempo
## são dois dedos em dois botões. Com o "Auto" ligado, o acelerador fica travado (até usar o Freio).
func _desired() -> Dictionary:
    var want := {}
    var layout := _buttons()
    for index in _held:
        var name: String = _held[index]
        if layout.has(name):
            want[layout[name]["action"]] = 1.0
    if _driving and _auto_gas and not want.has("move_back"):
        want["move_forward"] = 1.0
    return want


func _apply_buttons() -> void:
    var want := _desired()
    for action: String in _applied.keys():
        if not want.has(action):
            _send(action, false, 0.0)
            _applied.erase(action)
    for action: String in want:
        if not _applied.has(action):
            _send(action, true, 1.0)
            _applied[action] = true
    # O veículo lê estes valores direto (não dependem do InputMap, que o "joystick fantasma" zera).
    VirtualInput.accel = 1.0 if want.has("move_forward") else 0.0
    VirtualInput.reverse = 1.0 if want.has("move_back") else 0.0
    VirtualInput.steer_left = 1.0 if want.has("move_left") else 0.0
    VirtualInput.steer_right = 1.0 if want.has("move_right") else 0.0
    VirtualInput.handbrake = want.has("jump") and _driving
    VirtualInput.horn = want.has("horn")


func _process(_delta: float) -> void:
    if DEBUG_TOUCH and _driving:
        queue_redraw()


func _update_stick(v: Vector2) -> void:
    move_changed.emit(v)
    _send("move_right", v.x > 0.0, maxf(v.x, 0.0))
    _send("move_left", v.x < 0.0, maxf(-v.x, 0.0))
    _send("move_back", v.y > 0.0, maxf(v.y, 0.0))
    _send("move_forward", v.y < 0.0, maxf(-v.y, 0.0))


func _send(action: String, pressed: bool, strength: float) -> void:
    if not InputMap.has_action(action):
        return
    var ev := InputEventAction.new()
    ev.action = action
    ev.pressed = pressed
    ev.strength = strength if pressed else 0.0
    Input.parse_input_event(ev)


func _draw() -> void:
    var font := ThemeDB.fallback_font
    var layout := _buttons()
    var active := _held.values()
    for name: String in layout:
        var b: Dictionary = layout[name]
        if b.get("hidden", false):
            continue
        var pos: Vector2 = b["pos"]
        var r: float = b["r"]
        var lit: bool = active.has(name) or (name == "auto" and _auto_gas)
        draw_circle(pos, r, Color(1, 1, 1, 0.35 if lit else 0.15))
        draw_arc(pos, r, 0.0, TAU, 32, Color(1, 1, 1, 0.6), 2.0)
        if b.has("icon"):
            var dir := -1.0 if b["icon"] == "left" else 1.0
            var a := Vector2(dir * r * 0.4, 0.0)
            var c1 := Vector2(-dir * r * 0.3, -r * 0.4)
            var c2 := Vector2(-dir * r * 0.3, r * 0.4)
            draw_colored_polygon(PackedVector2Array([pos + a, pos + c1, pos + c2]), Color(1, 1, 1, 0.8))
        else:
            draw_string(font, pos + Vector2(-r, 6.0), b["label"], HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 16)
    if DEBUG_TOUCH and _driving:
        var info := "toques:%d  tela[a:%.0f e:%.0f d:%.0f]  jogo[a:%.1f e:%.1f d:%.1f]  canc:%d%s" % [
            _fingers.size(), VirtualInput.accel, VirtualInput.steer_left, VirtualInput.steer_right,
            Input.get_action_strength("move_forward"), Input.get_action_strength("move_left"),
            Input.get_action_strength("move_right"), _cancels, "  AUTO" if _auto_gas else ""]
        draw_string(font, Vector2(260.0, 24.0), info, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 16, Color(1, 1, 0.4, 0.9))
    if _stick_id != -1:
        draw_circle(_stick_origin, STICK_RADIUS, Color(1, 1, 1, 0.12))
        draw_arc(_stick_origin, STICK_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 2.0)
        var offset := (_stick_pos - _stick_origin).limit_length(STICK_RADIUS)
        draw_circle(_stick_origin + offset, 35.0, Color(1, 1, 1, 0.45))
