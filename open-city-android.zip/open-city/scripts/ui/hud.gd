extends CanvasLayer
## HUD: vida, resistência, minimapa (toque abre o mapa), GPS, velocímetro, dica de entrar
## no veículo e FPS. Tamanho, minimapa e dicas seguem as configurações (GameSettings).

const MapViewScript := preload("res://scripts/ui/map_view.gd")

var touch_mode := false

var _player: Node3D
var _panel: Control
var _health_bar: ProgressBar
var _stamina_bar: ProgressBar
var _info: Label
var _gps_label: Label
var _speed_label: Label
var _prompt_label: Label
var _minimap: Control
var _route_timer := 0.0
var _driving := false
var _prompt_name := ""
var _stick := Vector2.ZERO


func _ready() -> void:
    layer = 5
    _panel = Control.new()
    _panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_panel)

    var box := VBoxContainer.new()
    box.position = Vector2(16.0, 16.0)
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _panel.add_child(box)
    _health_bar = _make_row(box, "Vida", Color(0.85, 0.2, 0.2))
    _stamina_bar = _make_row(box, "Fôlego", Color(0.2, 0.7, 0.9))

    _minimap = MapViewScript.new()
    _minimap.position = Vector2(16.0, 84.0)
    _minimap.size = Vector2(170.0, 170.0)
    _panel.add_child(_minimap)

    _gps_label = _make_label(Vector2(16.0, 258.0))
    _info = _make_label(Vector2(16.0, 284.0))

    _speed_label = _make_bottom_label(-24.0)
    _prompt_label = _make_bottom_label(-110.0)
    _speed_label.visible = false
    GameSettings.changed.connect(_apply_settings)
    _apply_settings()


func _apply_settings() -> void:
    var s: float = GameSettings.hud_scale
    _panel.scale = Vector2(s, s)
    _minimap.visible = GameSettings.show_minimap
    _speed_label.add_theme_font_size_override("font_size", int(34.0 * s))
    _prompt_label.add_theme_font_size_override("font_size", int(22.0 * s))


func bind(player: Node3D, world_data: Dictionary) -> void:
    _player = player
    _minimap.mini = true
    _minimap.setup(world_data, player)


func _process(delta: float) -> void:
    var text := ""
    if GameSettings.show_fps:
        text = "FPS: %d" % Engine.get_frames_per_second()
    if touch_mode:
        text += "\nAnalógico: x=%.2f y=%.2f" % [_stick.x, _stick.y]
    elif GameSettings.show_hints:
        text += "\nWASD mover | Shift correr | Espaço pular/freio de mão | C agachar\nE entrar/sair/conversar | H buzina | M mapa | Esc menu | K dano (teste)"
    _info.text = text

    _route_timer -= delta
    if _route_timer <= 0.0:
        _route_timer = 1.0
        _update_gps()


func _update_gps() -> void:
    if not GameState.has_waypoint or _player == null:
        _gps_label.text = ""
        return
    var here := Vector2(_player.global_position.x, _player.global_position.z)
    GameState.update_route(here)
    var dist := here.distance_to(GameState.waypoint)
    if dist < 8.0:
        GameState.clear_waypoint()
        _gps_label.text = "Você chegou!"
        return
    _gps_label.text = "Destino: %d m" % int(dist)


func on_stick_changed(value: Vector2) -> void:
    _stick = value


func set_health(current: float, maximum: float) -> void:
    _set_bar(_health_bar, current, maximum)


func set_stamina(current: float, maximum: float) -> void:
    _set_bar(_stamina_bar, current, maximum)


func on_driving_changed(driving: bool, _vehicle_name: String) -> void:
    _driving = driving
    _speed_label.visible = driving
    _refresh_prompt()


func on_speed_changed(kmh: float) -> void:
    _speed_label.text = "%d km/h" % int(kmh)


func on_prompt_changed(vehicle_name: String) -> void:
    _prompt_name = vehicle_name
    _refresh_prompt()


func _refresh_prompt() -> void:
    var use_hint := "Toque em Usar" if touch_mode else "Aperte E"
    if _driving:
        _prompt_label.text = use_hint + " para sair do veículo"
    elif _prompt_name != "":
        _prompt_label.text = use_hint + " para entrar: " + _prompt_name
    else:
        _prompt_label.text = ""


func _set_bar(bar: ProgressBar, current: float, maximum: float) -> void:
    if bar == null:
        return
    bar.max_value = maxf(maximum, 1.0)
    bar.value = clampf(current, 0.0, bar.max_value)


func _make_label(pos: Vector2) -> Label:
    var label := Label.new()
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.position = pos
    _panel.add_child(label)
    return label


func _make_bottom_label(y_offset: float) -> Label:
    var label := Label.new()
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.add_theme_color_override("font_outline_color", Color.BLACK)
    label.add_theme_constant_override("outline_size", 6)
    add_child(label)
    label.anchor_left = 0.5
    label.anchor_right = 0.5
    label.anchor_top = 1.0
    label.anchor_bottom = 1.0
    label.offset_left = -360.0
    label.offset_right = 360.0
    label.offset_top = y_offset - 44.0
    label.offset_bottom = y_offset
    return label


func _make_row(parent: Control, title: String, color: Color) -> ProgressBar:
    var row := HBoxContainer.new()
    row.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(row)

    var label := Label.new()
    label.text = title
    label.custom_minimum_size = Vector2(70.0, 0.0)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    row.add_child(label)

    var bar := ProgressBar.new()
    bar.custom_minimum_size = Vector2(220.0, 18.0)
    bar.show_percentage = false
    bar.max_value = 100.0
    bar.value = 100.0
    bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var fill := StyleBoxFlat.new()
    fill.bg_color = color
    bar.add_theme_stylebox_override("fill", fill)
    row.add_child(bar)
    return bar
