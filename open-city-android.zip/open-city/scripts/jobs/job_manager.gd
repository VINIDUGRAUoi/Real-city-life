extends Node
## Trabalhos: entregador, motorista de aplicativo, motorista de ônibus e caminhoneiro. (O comerciante é o negócio
## de scripts/jobs/business.gd, que se gerencia pelo celular.)
## Cada trabalho é uma sequência de "etapas" (pontos no mapa). O objetivo atual vira o destino do GPS, ganha um feixe
## de luz no mundo e, ao chegar (e parar, quando a etapa pede), a etapa é concluída e o pagamento cai na carteira.

const GraphScript := preload("res://scripts/ai/city_graph.gd")
const JobMarkerScript := preload("res://scripts/jobs/job_marker.gd")
const HumanoidScript := preload("res://scripts/ai/humanoid.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const ShopScript := preload("res://scripts/core/shop.gd")

signal job_changed

const ARRIVE_RADIUS := 7.0
const STOP_SPEED := 1.6

## Nome, veículo exigido (texto) e veículo da empresa (id) de cada trabalho.
const JOBS := {
    "delivery": {"name": "Entregador", "need": "qualquer carro ou moto", "company": "moto_urbana"},
    "uber": {"name": "Motorista de aplicativo", "need": "um carro de passeio", "company": "sedan"},
    "bus": {"name": "Motorista de ônibus", "need": "um ônibus", "company": "bus"},
    "freight": {"name": "Caminhoneiro", "need": "um caminhão ou van", "company": "truck"},
}
const ORDER := ["delivery", "uber", "bus", "freight"]
const BUS_TYPES := ["bus", "microbus"]
const FREIGHT_TYPES := ["truck", "van", "classic_van"]
const HEAVY_TYPES := ["bus", "microbus", "truck", "van", "classic_van"]

## Linhas de ônibus (cruzamentos da grade, índices ix, iz). Passa por todos em ordem.
const BUS_ROUTES := {
    "centro": {
        "name": "Linha 1 - Centro (circular)", "fare": 4.5,
        "nodes": [Vector2i(-6, -6), Vector2i(0, -6), Vector2i(6, -6), Vector2i(6, 0), Vector2i(6, 6), Vector2i(0, 6), Vector2i(-6, 6), Vector2i(-6, 0), Vector2i(-6, -6)],
    },
    "interurbana": {
        "name": "Linha 2 - Real City / Porto Azul", "fare": 9.0,
        "nodes": [Vector2i(0, 0), Vector2i(8, 0), Vector2i(24, 0), Vector2i(28, 0), Vector2i(24, 0), Vector2i(8, 0), Vector2i(0, 0)],
    },
}
const BUS_ROUTE_ORDER := ["centro", "interurbana"]

var player: Node3D
var active := ""
var route_id := ""
var steps: Array = []
var step_index := 0
var earned := 0 # neste turno

var _marker: Node3D
var _crowd: Node3D
var _time_left := 0.0
var _budget := 0.0 # tempo previsto da corrida (nota do passageiro)
var _elapsed := 0.0
var _hold := 0.0
var _pending_next := -1.0
var _penalties := 0
var _penalty_cooldown := 0.0
var _prev_speed := 0.0
var _spawned := {}

var _ui: CanvasLayer
var _panel: PanelContainer
var _title: Label
var _body: Label
var _toast: Label
var _toast_time := 0.0


func _ready() -> void:
    _build_ui()


# ------------------------------------------------------------------ interface

func _build_ui() -> void:
    _ui = CanvasLayer.new()
    _ui.layer = 3
    add_child(_ui)
    var theme := Theme.new()
    theme.default_font_size = 20
    _panel = PanelContainer.new()
    _panel.theme = theme
    _panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _ui.add_child(_panel)
    _panel.custom_minimum_size = Vector2(420.0, 0.0)
    _panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 8)
    var box := VBoxContainer.new()
    _panel.add_child(box)
    _title = Label.new()
    _title.add_theme_color_override("font_color", Color(1.0, 0.85, 0.3))
    box.add_child(_title)
    _body = Label.new()
    _body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(_body)
    _panel.visible = false

    _toast = Label.new()
    _toast.theme = theme
    _toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _toast.add_theme_font_size_override("font_size", 26)
    _toast.add_theme_color_override("font_outline_color", Color.BLACK)
    _toast.add_theme_constant_override("outline_size", 8)
    _ui.add_child(_toast)
    _toast.custom_minimum_size = Vector2(700.0, 0.0)
    _toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP, Control.PRESET_MODE_MINSIZE, 150)
    _toast.visible = false


func toast(text: String, seconds: float = 4.0) -> void:
    _toast.text = text
    _toast.visible = true
    _toast_time = seconds


func _update_ui() -> void:
    if active == "":
        _panel.visible = false
        return
    _panel.visible = true
    var job: Dictionary = JOBS[active]
    _title.text = "%s  |  Turno: %s" % [job["name"], ShopScript.fmt_money(earned)]
    var s := _step()
    var lines: Array[String] = []
    if not s.is_empty():
        lines.append(str(s["label"]))
        var d := _pos2().distance_to(s["pos"])
        lines.append("Distância: %d m" % int(d))
    if _time_left > 0.0 and (active == "delivery" or active == "freight"):
        lines.append("Tempo: %d:%02d" % [int(_time_left) / 60, int(_time_left) % 60])
    elif active == "delivery" or active == "freight":
        lines.append("Atrasado: pagamento reduzido")
    if not _vehicle_ok(active):
        lines.append("Volte para o veículo: precisa de %s." % job["need"])
    _body.text = "\n".join(lines)


# ----------------------------------------------------------------- utilidades

func _pos2() -> Vector2:
    return Vector2(player.global_position.x, player.global_position.z)


func _vehicle() -> Node:
    if player == null:
        return null
    var v: Variant = player.get("_vehicle")
    if v != null and is_instance_valid(v):
        return v
    return null


func _vehicle_type() -> String:
    var v := _vehicle()
    return str(v.get("type_id")) if v != null else ""


func _is_bike(v: Node) -> bool:
    var d: Variant = v.get("data")
    return d is Dictionary and bool((d as Dictionary).get("bike", false))


func _vehicle_ok(kind: String) -> bool:
    var v := _vehicle()
    if v == null:
        return false
    var t := _vehicle_type()
    match kind:
        "delivery":
            return true
        "uber":
            return not _is_bike(v) and not HEAVY_TYPES.has(t)
        "bus":
            return BUS_TYPES.has(t)
        "freight":
            return FREIGHT_TYPES.has(t)
    return false


func _step() -> Dictionary:
    if step_index < steps.size():
        return steps[step_index]
    return {}


func _city_here() -> int:
    var c := GraphScript.city_at(_pos2())
    return c if c >= 0 else GraphScript.nearest_city(_pos2())


## Ponto aleatório numa rua da cidade, a uma distância [dmin, dmax] de `around`.
func _random_road_point(city: int, around: Vector2, dmin: float, dmax: float) -> Vector2:
    var rmin := GraphScript.road_min(city)
    var rmax := GraphScript.road_max(city)
    var best := Vector2.ZERO
    for i in 60:
        var ix := randi_range(rmin.x, rmax.x)
        var iz := randi_range(rmin.y, rmax.y)
        var p := Vector2(float(ix), float(iz)) * GraphScript.PITCH
        if randf() < 0.5:
            p.x += randf_range(-18.0, 18.0)
        else:
            p.y += randf_range(-18.0, 18.0)
        p = GraphScript.snap_to_road(p)
        best = p
        var d := p.distance_to(around)
        if d >= dmin and d <= dmax:
            return p
    return best


# -------------------------------------------------------------- início e fim

## Começa um trabalho. Retorna "" se deu certo ou a mensagem do motivo.
func start(kind: String, route: String = "") -> String:
    if player == null or not JOBS.has(kind):
        return "Trabalho indisponível."
    if not _vehicle_ok(kind):
        return "Para este trabalho você precisa estar dentro de %s." % JOBS[kind]["need"]
    stop(false)
    active = kind
    route_id = route
    earned = 0
    _penalties = 0
    if kind == "bus":
        _build_bus_steps()
    else:
        _build_order()
    _show_step()
    job_changed.emit()
    toast("%s: turno iniciado!" % JOBS[kind]["name"])
    return ""


func stop(announce: bool = true) -> void:
    if active == "":
        return
    var total := earned
    active = ""
    steps = []
    step_index = 0
    _clear_visuals()
    var gs := get_node_or_null("/root/GameState")
    if gs != null:
        gs.clear_waypoint()
    _update_ui()
    job_changed.emit()
    if announce:
        toast("Turno encerrado. Você ganhou %s." % ShopScript.fmt_money(total), 5.0)


func _clear_visuals() -> void:
    if _marker != null and is_instance_valid(_marker):
        _marker.queue_free()
    _marker = null
    if _crowd != null and is_instance_valid(_crowd):
        _crowd.queue_free()
    _crowd = null


# --------------------------------------------------------------- criar etapas

func _build_order() -> void:
    steps = []
    step_index = 0
    var city := _city_here()
    var here := _pos2()
    match active:
        "delivery":
            var pick := _random_road_point(city, here, 100.0, 420.0)
            var drop := _random_road_point(city, pick, 250.0, 800.0)
            var dist := here.distance_to(pick) + pick.distance_to(drop)
            _time_left = dist / 8.0 + 50.0
            var pay := int(30.0 + 0.05 * pick.distance_to(drop))
            steps.append({"pos": pick, "kind": "pickup", "label": "Retire o pedido no restaurante", "stop": false, "pay": 0, "crowd": 0})
            steps.append({"pos": drop, "kind": "drop", "label": "Entregue o pedido ao cliente", "stop": false, "pay": pay, "crowd": 0})
        "uber":
            var pick2 := _random_road_point(city, here, 80.0, 450.0)
            var dest_city := city
            if randf() < 0.25:
                dest_city = randi() % GraphScript.city_count() # corrida entre cidades, às vezes
            var drop2 := _random_road_point(dest_city, pick2, 300.0, 1400.0)
            if dest_city != city:
                drop2 = GraphScript.snap_to_road(GraphScript.city_center(dest_city))
            var fare := int(10.0 + 0.018 * pick2.distance_to(drop2))
            _time_left = pick2.distance_to(drop2) / 9.0 + 60.0
            steps.append({"pos": pick2, "kind": "board", "label": "Busque o passageiro (pare no ponto)", "stop": true, "hold": 2.0, "pay": 0, "crowd": 1})
            steps.append({"pos": drop2, "kind": "alight", "label": "Leve o passageiro ao destino (pare no ponto)", "stop": true, "hold": 2.0, "pay": fare, "crowd": 0})
        "freight":
            var depot := _random_road_point(city, here, 80.0, 400.0)
            var other := city
            for i in 10:
                other = randi() % GraphScript.city_count()
                if other != city:
                    break
            var dest := _random_road_point(other, GraphScript.city_center(other), 0.0, 200.0)
            var dist2 := here.distance_to(depot) + depot.distance_to(dest)
            _time_left = dist2 / 13.0 + 120.0
            var pay2 := int(350.0 + 0.12 * depot.distance_to(dest))
            steps.append({"pos": depot, "kind": "depot", "label": "Carregue a carga no depósito (pare no ponto)", "stop": true, "hold": 3.0, "pay": 0, "crowd": 0})
            steps.append({"pos": dest, "kind": "unload", "label": "Entregue a carga em %s (pare no ponto)" % GraphScript.city_name(other), "stop": true, "hold": 3.0, "pay": pay2, "crowd": 0})
    _budget = _time_left
    _elapsed = 0.0
    _penalties = 0


func _build_bus_steps() -> void:
    steps = []
    step_index = 0
    var route: Dictionary = BUS_ROUTES.get(route_id, BUS_ROUTES["centro"])
    var nodes: Array = route["nodes"]
    for i in nodes.size():
        var n: Vector2i = nodes[i]
        var last := i == nodes.size() - 1
        steps.append({
            "pos": Vector2(float(n.x), float(n.y)) * GraphScript.PITCH,
            "kind": "stop",
            "label": ("Ponto final: pare para desembarcar" if last else "Ponto %d de %d: pare para embarcar" % [i + 1, nodes.size()]),
            "stop": true, "hold": 3.0, "pay": 0, "crowd": randi_range(2, 4), "last": last, "fare": float(route["fare"]),
        })
    _time_left = 0.0


# ------------------------------------------------------------- etapa atual

func _show_step() -> void:
    _clear_visuals()
    var s := _step()
    if s.is_empty():
        return
    var pos: Vector2 = s["pos"]
    var color := Color(0.2, 0.8, 1.0)
    match str(s["kind"]):
        "pickup", "depot":
            color = Color(1.0, 0.7, 0.1)
        "drop", "alight", "unload":
            color = Color(0.2, 1.0, 0.4)
        "stop":
            color = Color(0.4, 0.6, 1.0)
    _marker = JobMarkerScript.new()
    get_parent().add_child(_marker)
    _marker.position = Vector3(pos.x, 0.1, pos.y)
    _marker.setup(color, str(s["label"]).split(" (")[0], ARRIVE_RADIUS - 1.0)
    var crowd_n := int(s.get("crowd", 0))
    if crowd_n > 0:
        _crowd = Node3D.new()
        get_parent().add_child(_crowd)
        _crowd.position = Vector3(pos.x + 4.0, 0.0, pos.y + 4.0)
        for i in crowd_n:
            var slot := Node3D.new()
            slot.position = Vector3(float(i) * 0.9, 0.0, float(i % 2) * 0.6)
            slot.rotation.y = randf() * TAU
            _crowd.add_child(slot)
            HumanoidScript.build(slot, _random_outfit())
    var gs := get_node_or_null("/root/GameState")
    if gs != null:
        gs.set_waypoint(pos)
        gs.update_route(_pos2())


func _random_outfit() -> Dictionary:
    return HumanoidScript.random_outfit()


func _pay(amount: int) -> void:
    if amount <= 0:
        return
    var gs := get_node_or_null("/root/GameState")
    if gs != null:
        gs.add_money(amount)
        gs.add_job_earning(active, amount)
    earned += amount


func _complete_step() -> void:
    var s := _step()
    var kind := str(s["kind"])
    var late := _time_left < 0.0 and (active == "delivery" or active == "freight")
    match kind:
        "pickup":
            toast("Pedido retirado! Leve ao cliente.")
        "depot":
            toast("Carga carregada! Siga para o destino.")
        "board":
            toast("Passageiro a bordo! Leve-o ao destino.")
            _penalties = 0
            _elapsed = 0.0
        "drop", "unload":
            var pay := int(s["pay"])
            if late:
                pay = pay / 2
            _pay(pay)
            toast("%s: +%s%s" % ["Entrega concluída" if kind == "drop" else "Carga entregue", ShopScript.fmt_money(pay), " (atraso)" if late else ""])
        "alight":
            var rating := clampf(5.0 - float(_penalties) * 0.6 - maxf(0.0, (_elapsed - _budget) / 40.0), 1.0, 5.0)
            var fare := int(s["pay"])
            var tip := int(float(fare) * maxf(rating - 3.0, 0.0) * 0.1)
            _pay(fare + tip)
            toast("Corrida concluída: +%s (gorjeta %s)  Nota %.1f ★" % [ShopScript.fmt_money(fare + tip), ShopScript.fmt_money(tip), rating])
        "stop":
            var passengers := randi_range(2, 14)
            var money := int(float(passengers) * float(s["fare"]))
            _pay(money)
            toast("%d passageiros: +%s" % [passengers, ShopScript.fmt_money(money)], 3.0)
            if bool(s.get("last", false)):
                _pay(150)
                toast("Linha concluída! Bônus de R$ 150.", 5.0)
    step_index += 1
    _hold = 0.0
    if step_index >= steps.size():
        _finish_run()
    else:
        _show_step()


func _finish_run() -> void:
    _clear_visuals()
    if active == "delivery" or active == "uber":
        _pending_next = 2.0 # chama o próximo pedido
        steps = []
    else:
        var gs := get_node_or_null("/root/GameState")
        if gs != null:
            gs.clear_waypoint()
        var total := earned
        active = ""
        steps = []
        job_changed.emit()
        toast("Trabalho concluído! Total do turno: %s" % ShopScript.fmt_money(total), 6.0)


# ----------------------------------------------------------------- laço

func _process(delta: float) -> void:
    if _toast_time > 0.0:
        _toast_time -= delta
        if _toast_time <= 0.0:
            _toast.visible = false
    if active == "" or player == null:
        _update_ui()
        return
    _elapsed += delta
    if active == "delivery" or active == "freight":
        _time_left -= delta
    if _pending_next >= 0.0:
        _pending_next -= delta
        if _pending_next < 0.0:
            _build_order()
            _show_step()
            toast("Novo pedido recebido!")
        _update_ui()
        return
    if _vehicle_ok(active):
        _check_arrival(delta)
        _watch_driving(delta)
    _update_ui()


func _check_arrival(delta: float) -> void:
    var s := _step()
    if s.is_empty():
        return
    var d := _pos2().distance_to(s["pos"])
    if d > ARRIVE_RADIUS:
        _hold = 0.0
        return
    if not bool(s.get("stop", false)):
        _complete_step()
        return
    var v := _vehicle()
    var speed: float = v.linear_velocity.length() if v != null and "linear_velocity" in v else 0.0
    if speed < STOP_SPEED:
        _hold += delta
        if _hold >= float(s.get("hold", 2.0)):
            _complete_step()
    else:
        _hold = 0.0


## Batidas fortes derrubam a nota do passageiro.
func _watch_driving(delta: float) -> void:
    var v := _vehicle()
    if v == null or not ("linear_velocity" in v) or delta <= 0.0:
        return
    var speed: float = v.linear_velocity.length()
    _penalty_cooldown = maxf(_penalty_cooldown - delta, 0.0)
    if (_prev_speed - speed) / delta > 28.0 and _penalty_cooldown <= 0.0:
        _penalties += 1
        _penalty_cooldown = 1.5
    _prev_speed = speed


# ------------------------------------------------------- veículo da empresa

## Faz aparecer ao lado do jogador o veículo exigido pelo trabalho (de graça). Retorna "" ou o erro.
func spawn_company_vehicle(kind: String) -> String:
    if player == null or not JOBS.has(kind):
        return "Indisponível."
    var id: String = str(JOBS[kind]["company"])
    var old: Variant = _spawned.get(id)
    if old != null and is_instance_valid(old):
        if old.driver != null:
            return "Você já está nesse veículo."
        old.queue_free()
    var car = FactoryScript.create(id)
    var fwd: Vector2 = player.get_forward_xz()
    var right := Vector2(-fwd.y, fwd.x)
    var ahead := 10.0 if player.is_driving() else (7.0 if id == "bus" or id == "truck" else 4.0)
    var xz := Vector2(player.global_position.x, player.global_position.z) + fwd * ahead + right * 3.5
    car.position = Vector3(xz.x, player.global_position.y + 1.6, xz.y)
    car.rotation.y = atan2(-fwd.x, -fwd.y)
    player.get_parent().add_child(car)
    _spawned[id] = car
    return ""
