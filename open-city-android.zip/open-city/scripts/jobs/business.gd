extends RefCounted
## Negócio do jogador (comerciante): lanchonete, mercadinho ou loja de roupas. Você compra o estoque e a loja vende
## sozinha com o tempo (também com o jogo fechado, até 8 horas). O dinheiro vai para o caixa e você recolhe pelo celular.
## Toda a lógica fica aqui (sem nós), para poder ser testada.

const TYPES := {
    "lanchonete": {"name": "Lanchonete", "price": 25000, "item": "lanches", "sell_price": 14, "unit_cost": 6, "rate": 5.0, "capacity": 300},
    "mercadinho": {"name": "Mercadinho", "price": 60000, "item": "produtos", "sell_price": 22, "unit_cost": 12, "rate": 4.0, "capacity": 500},
    "loja_roupas": {"name": "Loja de roupas", "price": 45000, "item": "peças", "sell_price": 60, "unit_cost": 32, "rate": 1.6, "capacity": 150},
}
const ORDER := ["lanchonete", "mercadinho", "loja_roupas"]
const MAX_OFFLINE_MIN := 480.0
const MAX_LEVEL := 5


static func exists(b: Dictionary) -> bool:
    return b.has("type") and TYPES.has(str(b["type"]))


static func create(type: String, now: float) -> Dictionary:
    return {"type": type, "level": 1, "stock": 0, "cash": 0, "frac": 0.0, "last": now}


static func info(b: Dictionary) -> Dictionary:
    return TYPES[str(b["type"])]


static func level(b: Dictionary) -> int:
    return clampi(int(b.get("level", 1)), 1, MAX_LEVEL)


## Vendas por minuto (cresce com o nível da loja).
static func rate(b: Dictionary) -> float:
    return float(info(b)["rate"]) * float(level(b))


static func capacity(b: Dictionary) -> int:
    return int(info(b)["capacity"]) * level(b)


static func stock_cost(b: Dictionary, units: int) -> int:
    return int(info(b)["unit_cost"]) * units


static func upgrade_cost(b: Dictionary) -> int:
    return int(info(b)["price"]) * level(b) / 2


## Espaço livre no estoque.
static func free_space(b: Dictionary) -> int:
    return maxi(capacity(b) - int(b.get("stock", 0)), 0)


## Avança o tempo até `now` (segundos Unix) e vende o que o estoque permitir. Retorna as unidades vendidas.
static func simulate(b: Dictionary, now: float) -> int:
    var last := float(b.get("last", now))
    var minutes := clampf((now - last) / 60.0, 0.0, MAX_OFFLINE_MIN)
    b["last"] = now
    var want := rate(b) * minutes + float(b.get("frac", 0.0))
    var units := int(floorf(want))
    var stock := int(b.get("stock", 0))
    if units > stock:
        units = stock
        b["frac"] = 0.0 # sem estoque, as vendas que faltaram se perdem
    else:
        b["frac"] = want - float(units)
    b["stock"] = stock - units
    b["cash"] = int(b.get("cash", 0)) + units * int(info(b)["sell_price"])
    return units
