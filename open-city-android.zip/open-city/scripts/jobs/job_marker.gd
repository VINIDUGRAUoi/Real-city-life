extends Node3D
## Marcador de um objetivo de trabalho: feixe de luz alto (visto de longe), anel no chão e um texto.

var _ring: MeshInstance3D
var _label: Label3D


func setup(color: Color, text: String, radius: float) -> void:
    var beam := MeshInstance3D.new()
    var cyl := CylinderMesh.new()
    cyl.top_radius = 1.0
    cyl.bottom_radius = 1.0
    cyl.height = 70.0
    cyl.radial_segments = 16
    beam.mesh = cyl
    beam.material_override = _material(Color(color.r, color.g, color.b, 0.28))
    beam.position.y = 35.0
    add_child(beam)

    _ring = MeshInstance3D.new()
    var disc := CylinderMesh.new()
    disc.top_radius = radius
    disc.bottom_radius = radius
    disc.height = 0.06
    disc.radial_segments = 32
    _ring.mesh = disc
    _ring.material_override = _material(Color(color.r, color.g, color.b, 0.35))
    _ring.position.y = 0.05
    add_child(_ring)

    _label = Label3D.new()
    _label.text = text
    _label.font_size = 72
    _label.pixel_size = 0.012
    _label.outline_size = 14
    _label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    _label.no_depth_test = true
    _label.position.y = 9.0
    add_child(_label)


func set_text(text: String) -> void:
    if _label != null:
        _label.text = text


func _material(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    return m
