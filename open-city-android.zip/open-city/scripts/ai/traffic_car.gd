extends AnimatableBody3D
## Carro do trânsito: segue as avenidas na faixa da direita, vira aleatoriamente nos
## cruzamentos (e rodovias entre cidades) e freia quando há algo à frente (raio). O jogador pode "entrar" nele:
## get_drivable() troca este carro por um veículo dirigível na mesma posição.
## Ainda NÃO obedece a semáforos (não existem).

const BuilderScript := preload("res://scripts/vehicles/vehicle_builder.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const SkinScript := preload("res://scripts/vehicles/vehicle_skin.gd")

const LANE_OFFSET := 3.0
const REST_HEIGHT := 0.84

var type_id := "sedan"
var body_color := Color(0.5, 0.5, 0.5)
var data: Dictionary = {}
var speed := 0.0
var cruise_speed := 9.0

var _dir := Vector2i(1, 0)
var _node := Vector2i.ZERO
var _target := Vector3.ZERO
var _blocked_time := 0.0
var _ignore_until_ms := 0

# animação das rodas (giram com a velocidade e as da frente esterçam nas curvas)
var _wheel_nodes: Array = []
var _spin := 0.0
var _steer := 0.0
var _last_yaw := 0.0


func setup(id: String, color: Color) -> void:
    type_id = id if DataScript.TYPES.has(id) else "sedan"
    body_color = color
    data = DataScript.TYPES[type_id]
    cruise_speed = minf(randf_range(7.0, 13.0), float(data["max_speed"]) * 0.5)


## Altura do centro do carro: o fundo da roda (raio variável) encosta no chão.
func _rest_height() -> float:
    return 0.5 + SkinScript.ride_radius(type_id, data)


func _ready() -> void:
    if data.is_empty():
        setup(type_id, body_color)
    BuilderScript.build(self, data, body_color, true)
    _collect_wheels()
    _last_yaw = rotation.y
    add_to_group("traffic")
    add_to_group("enterable")


## Posiciona o carro num trecho: sai do cruzamento (ix, iz) na direção dir.
func start(ix: int, iz: int, dir: Vector2i) -> void:
    _dir = dir
    _node = Vector2i(ix + dir.x, iz + dir.y)
    var origin := Vector3(ix * GraphScript.PITCH, _rest_height(), iz * GraphScript.PITCH)
    var along := Vector3(dir.x, 0.0, dir.y) * GraphScript.PITCH * randf_range(0.15, 0.85)
    position = origin + along + _lane(dir)
    rotation.y = atan2(-dir.x, -dir.y)
    speed = 0.0
    _blocked_time = 0.0
    _update_target()


func _lane(dir: Vector2i) -> Vector3:
    return Vector3(-dir.y, 0.0, dir.x) * LANE_OFFSET


func _update_target() -> void:
    _target = Vector3(_node.x * GraphScript.PITCH, _rest_height(), _node.y * GraphScript.PITCH) + _lane(_dir)


func _choose_next() -> void:
    var options: Array = []
    for d: Vector2i in GraphScript.DIRS:
        if d == -_dir:
            continue
        var n := _node + d
        if not GraphScript.road_node_exists(n.x, n.y):
            continue
        options.append(d)
    if options.is_empty():
        options.append(-_dir)
    var next: Vector2i = _dir
    if not (options.has(_dir) and randf() < 0.55):
        next = options.pick_random()
    _dir = next
    _node += next
    _update_target()


func _physics_process(delta: float) -> void:
    var to_target := _target - global_position
    to_target.y = 0.0
    var dist := to_target.length()
    if dist < 2.5:
        _choose_next()
        to_target = _target - global_position
        to_target.y = 0.0
        dist = maxf(to_target.length(), 0.01)

    var desired := to_target / dist
    rotation.y = lerp_angle(rotation.y, atan2(-desired.x, -desired.z), minf(1.0, 4.0 * delta))

    var target_speed := cruise_speed * _obstacle_factor(delta)
    var rate := 6.0 if target_speed > speed else 14.0
    speed = move_toward(speed, target_speed, rate * delta)
    var fwd := -global_transform.basis.z
    global_position += fwd * speed * delta
    _animate_wheels(delta)


## Acha as 4 rodas (do modelo 3D ou geradas) e guarda como cada uma está montada.
func _collect_wheels() -> void:
    for n in find_children("wheel_*", "Node3D", true, false):
        var node := n as Node3D
        var radius := 0.35
        if node is MeshInstance3D and (node as MeshInstance3D).mesh != null:
            var sz: Vector3 = (node as MeshInstance3D).mesh.get_aabb().size
            radius = maxf(sz.y, sz.z) * 0.5 * node.global_transform.basis.get_scale().x
        var aligned := node.global_transform.basis.x.normalized().dot(global_transform.basis.x.normalized()) > 0.0
        _wheel_nodes.append({
            "node": node,
            "base": node.transform.basis,
            "front": to_local(node.global_position).z < 0.0,
            "radius": maxf(radius, 0.15),
            "sign": -1.0 if aligned else 1.0,
        })


func _animate_wheels(delta: float) -> void:
    if _wheel_nodes.is_empty() or delta <= 0.0:
        return
    var yaw_rate := angle_difference(_last_yaw, rotation.y) / delta
    _last_yaw = rotation.y
    var wheelbase := maxf(float((data["size"] as Vector3).z) - 1.4, 1.5)
    var target := 0.0
    if speed > 0.5:
        target = clampf(atan(wheelbase * yaw_rate / speed), -0.55, 0.55)
    _steer = move_toward(_steer, target, 3.0 * delta)
    for w: Dictionary in _wheel_nodes:
        var node: Node3D = w["node"]
        if not is_instance_valid(node):
            continue
        var angle := _spin * float(w["sign"]) / float(w["radius"])
        var basis: Basis = w["base"] * Basis(Vector3.RIGHT, angle)
        if w["front"]:
            basis = Basis(Vector3.UP, _steer) * basis
        node.basis = basis
    _spin += speed * delta


func _obstacle_factor(delta: float) -> float:
    var fwd := -global_transform.basis.z
    var length := 4.0 + speed * 1.2
    var from := global_position + fwd * (float(data["size"].z) * 0.5 + 0.1) + Vector3(0.0, 0.2, 0.0)
    var query := PhysicsRayQueryParameters3D.create(from, from + fwd * length)
    query.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        _blocked_time = 0.0
        return 1.0
    if Time.get_ticks_msec() < _ignore_until_ms:
        return 0.4
    _blocked_time += delta
    if _blocked_time > 5.0: # destrava: segue devagar por 2 s
        _blocked_time = 0.0
        _ignore_until_ms = Time.get_ticks_msec() + 2000
    var d := from.distance_to(hit["position"])
    return clampf((d - 1.5) / maxf(length - 1.5, 0.1), 0.0, 1.0)


# ------------------------------------------------------------ interface comum

func can_enter() -> bool:
    return true


func get_display_name() -> String:
    return str(data["name"])


func get_speed() -> float:
    return speed


func get_forward_xz() -> Vector2:
    var f := -global_transform.basis.z
    return Vector2(f.x, f.z).normalized()


## Troca este carro por um veículo dirigível na mesma posição e velocidade.
func get_drivable():
    var vehicle = FactoryScript.create(type_id, body_color)
    var xform := global_transform
    var vel := -xform.basis.z * speed
    get_parent().add_child(vehicle)
    vehicle.global_transform = xform
    vehicle.linear_velocity = vel
    vehicle.recyclable = true
    remove_from_group("enterable")
    queue_free()
    return vehicle
