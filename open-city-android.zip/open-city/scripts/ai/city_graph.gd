extends RefCounted
## Grafo do mundo: várias cidades em grade, ligadas por rodovias com pontes sobre os rios.
## Cada cidade é uma "janela" de uma grade global de quarteirões (índices i, j). As ruas ficam
## nos índices de cruzamento (ix, iz) e a posição no mundo é sempre índice * PITCH.
## Serve a pedestres (calçadas), trânsito (vias), GPS (rotas) e mapa.
## As constantes BLOCK_SIZE / ROAD_WIDTH / PITCH devem coincidir com as do world_builder.gd.

const BLOCK_SIZE := 40.0
const ROAD_WIDTH := 12.0
const PITCH := 52.0
const RING := 18.8 # distância do centro do quarteirão até o caminho dos pedestres (calçada: 17 a 20 m)

## Cidade principal (índice 0). Mantidos por compatibilidade: devem coincidir com CITIES[0].
const BLOCK_MIN := -8
const BLOCK_MAX := 7
const ROAD_MIN := -8
const ROAD_MAX := 8

const WORLD_MARGIN := 260.0
const HIGHWAY_WIDTH := 14.0

## Rios (em metros). O rio leste corta o mundo de norte a sul (x). Os rios sul e norte ficam
## a oeste dele (z). As rodovias atravessam cada rio por uma ponte.
const RIVER_EAST := Vector2(760.0, 960.0)
const RIVER_SOUTH := Vector2(700.0, 800.0)
const RIVER_NORTH := Vector2(-800.0, -700.0)

## bmin/bmax = primeiro e último quarteirão (inclusive). As ruas vão de bmin até bmax + 1.
## downtown/midrise = raios (m, a partir do centro da cidade) de prédios altos e médios.
const CITIES := [
    {"id": "real_city", "name": "Real City", "bmin": Vector2i(-8, -8), "bmax": Vector2i(7, 7), "downtown": 150.0, "midrise": 280.0, "park_chance": 0.12},
    {"id": "porto_azul", "name": "Porto Azul", "bmin": Vector2i(24, -4), "bmax": Vector2i(31, 3), "downtown": 60.0, "midrise": 150.0, "park_chance": 0.15},
    {"id": "vila_serrana", "name": "Vila Serrana", "bmin": Vector2i(-3, 24), "bmax": Vector2i(2, 29), "downtown": 0.0, "midrise": 70.0, "park_chance": 0.2},
    {"id": "monte_alto", "name": "Monte Alto", "bmin": Vector2i(-3, -30), "bmax": Vector2i(2, -25), "downtown": 0.0, "midrise": 60.0, "park_chance": 0.2},
]

## from = cruzamento na cidade principal; to = cruzamento na outra cidade (índice "city").
## river = trecho (m, ao longo da rodovia) coberto pela ponte.
const HIGHWAYS := [
    {"name": "Rodovia Leste", "from": Vector2i(8, 0), "to": Vector2i(24, 0), "city": 1, "river": Vector2(760.0, 960.0)},
    {"name": "Rodovia Sul", "from": Vector2i(0, 8), "to": Vector2i(0, 24), "city": 2, "river": Vector2(700.0, 800.0)},
    {"name": "Rodovia Norte", "from": Vector2i(0, -8), "to": Vector2i(0, -24), "city": 3, "river": Vector2(-800.0, -700.0)},
]

const CORNER_SIGNS := [Vector2i(-1, -1), Vector2i(1, -1), Vector2i(1, 1), Vector2i(-1, 1)]
const DIRS := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]

static var _ped_cache: Array = []
static var _edge_cache: Array = []


# ------------------------------------------------------------------ cidades

static func city_count() -> int:
    return CITIES.size()


static func city_name(ci: int) -> String:
    return str(CITIES[ci]["name"])


static func road_min(ci: int) -> Vector2i:
    return CITIES[ci]["bmin"]


static func road_max(ci: int) -> Vector2i:
    var b: Vector2i = CITIES[ci]["bmax"]
    return b + Vector2i(1, 1)


## Centro da cidade no mundo (x, z).
static func city_center(ci: int) -> Vector2:
    var a: Vector2i = CITIES[ci]["bmin"]
    var b: Vector2i = CITIES[ci]["bmax"]
    return Vector2(float(a.x + b.x + 1), float(a.y + b.y + 1)) * 0.5 * PITCH


## Meia dimensão (x, z) da área de ruas, de centro de rua a centro de rua.
static func city_half_size(ci: int) -> Vector2:
    var a := road_min(ci)
    var b := road_max(ci)
    return Vector2(float(b.x - a.x), float(b.y - a.y)) * 0.5 * PITCH


## Compatibilidade: meia extensão da cidade principal.
static func city_half_extent() -> float:
    return (float(ROAD_MAX) + 0.5) * PITCH


static func total_blocks() -> int:
    var n := 0
    for ci in CITIES.size():
        var a: Vector2i = CITIES[ci]["bmin"]
        var b: Vector2i = CITIES[ci]["bmax"]
        n += (b.x - a.x + 1) * (b.y - a.y + 1)
    return n


## Índice da cidade que contém o ponto (x, z), ou -1 se estiver fora de qualquer cidade.
static func city_at(p: Vector2) -> int:
    for ci in CITIES.size():
        var c := city_center(ci)
        var h := city_half_size(ci) + Vector2(PITCH, PITCH) * 0.5
        if absf(p.x - c.x) <= h.x and absf(p.y - c.y) <= h.y:
            return ci
    return -1


static func nearest_city(p: Vector2) -> int:
    var best := 0
    var best_d := INF
    for ci in CITIES.size():
        var d := p.distance_to(city_center(ci))
        if d < best_d:
            best_d = d
            best = ci
    return best


## Retângulo (x, z, largura, profundidade) que contém todas as cidades e uma margem.
static func world_rect() -> Rect2:
    var lo := Vector2(INF, INF)
    var hi := Vector2(-INF, -INF)
    for ci in CITIES.size():
        var c := city_center(ci)
        var h := city_half_size(ci)
        lo = Vector2(minf(lo.x, c.x - h.x), minf(lo.y, c.y - h.y))
        hi = Vector2(maxf(hi.x, c.x + h.x), maxf(hi.y, c.y + h.y))
    lo -= Vector2(WORLD_MARGIN, WORLD_MARGIN)
    hi += Vector2(WORLD_MARGIN, WORLD_MARGIN)
    return Rect2(lo, hi - lo)


## Pedaços de terra (o resto do mundo é rio). Rect2(x, z, largura, profundidade).
static func ground_rects() -> Array[Rect2]:
    var w := world_rect()
    var x_min := w.position.x
    var x_max := w.end.x
    var z_min := w.position.y
    var z_max := w.end.y
    var out: Array[Rect2] = []
    out.append(Rect2(x_min, z_min, RIVER_EAST.x - x_min, RIVER_NORTH.x - z_min))
    out.append(Rect2(x_min, RIVER_NORTH.y, RIVER_EAST.x - x_min, RIVER_SOUTH.x - RIVER_NORTH.y))
    out.append(Rect2(x_min, RIVER_SOUTH.y, RIVER_EAST.x - x_min, z_max - RIVER_SOUTH.y))
    out.append(Rect2(RIVER_EAST.y, z_min, x_max - RIVER_EAST.y, z_max - z_min))
    return out


## Faixas de rio (para o mapa). Rect2(x, z, largura, profundidade).
static func river_rects() -> Array[Rect2]:
    var w := world_rect()
    var out: Array[Rect2] = []
    out.append(Rect2(RIVER_EAST.x, w.position.y, RIVER_EAST.y - RIVER_EAST.x, w.size.y))
    out.append(Rect2(w.position.x, RIVER_SOUTH.x, RIVER_EAST.x - w.position.x, RIVER_SOUTH.y - RIVER_SOUTH.x))
    out.append(Rect2(w.position.x, RIVER_NORTH.x, RIVER_EAST.x - w.position.x, RIVER_NORTH.y - RIVER_NORTH.x))
    return out


# ------------------------------------------------------------------ rodovias

static func highway_world_points(hw: Dictionary) -> Array:
    var f: Vector2i = hw["from"]
    var t: Vector2i = hw["to"]
    return [Vector2(float(f.x), float(f.y)) * PITCH, Vector2(float(t.x), float(t.y)) * PITCH]


static func highway_for_city(ci: int) -> Dictionary:
    for hw: Dictionary in HIGHWAYS:
        if int(hw["city"]) == ci:
            return hw
    return {}


## Ponto (x, z) do cruzamento da outra cidade onde a rodovia chega.
static func gate_pos(ci: int) -> Vector2:
    var hw := highway_for_city(ci)
    if hw.is_empty():
        return city_center(ci)
    return highway_world_points(hw)[1]


## Ponto (x, z) do cruzamento da cidade principal de onde a rodovia sai.
static func hub_gate_pos(ci: int) -> Vector2:
    var hw := highway_for_city(ci)
    if hw.is_empty():
        return city_center(0)
    return highway_world_points(hw)[0]


## Rodovia em que o ponto está (até 20 m do eixo), ou {} se não estiver em nenhuma.
static func highway_at(p: Vector2) -> Dictionary:
    for hw: Dictionary in HIGHWAYS:
        var pts := highway_world_points(hw)
        var a: Vector2 = pts[0]
        var b: Vector2 = pts[1]
        if absf(a.y - b.y) < 0.01:
            if absf(p.y - a.y) <= 20.0 and p.x >= minf(a.x, b.x) and p.x <= maxf(a.x, b.x):
                return hw
        else:
            if absf(p.x - a.x) <= 20.0 and p.y >= minf(a.y, b.y) and p.y <= maxf(a.y, b.y):
                return hw
    return {}


## Nome do lugar onde o ponto está (cidade, rodovia ou região rural).
static func place_name(p: Vector2) -> String:
    var ci := city_at(p)
    if ci >= 0:
        return city_name(ci)
    var hw := highway_at(p)
    if not hw.is_empty():
        return str(hw["name"])
    return "Região rural"


# ------------------------------------------------------------- nós e quarteirões

static func block_in_range(i: int, j: int) -> bool:
    for ci in CITIES.size():
        var a: Vector2i = CITIES[ci]["bmin"]
        var b: Vector2i = CITIES[ci]["bmax"]
        if i >= a.x and i <= b.x and j >= a.y and j <= b.y:
            return true
    return false


## Existe um cruzamento (ou trecho de rodovia) no índice (ix, iz)?
static func road_node_exists(ix: int, iz: int) -> bool:
    for ci in CITIES.size():
        var a := road_min(ci)
        var b := road_max(ci)
        if ix >= a.x and ix <= b.x and iz >= a.y and iz <= b.y:
            return true
    for hw: Dictionary in HIGHWAYS:
        var f: Vector2i = hw["from"]
        var t: Vector2i = hw["to"]
        if f.y == t.y and iz == f.y and ix >= mini(f.x, t.x) and ix <= maxi(f.x, t.x):
            return true
        if f.x == t.x and ix == f.x and iz >= mini(f.y, t.y) and iz <= maxi(f.y, t.y):
            return true
    return false


static func corner_index(sx: int, sz: int) -> int:
    if sx < 0:
        return 0 if sz < 0 else 3
    return 1 if sz < 0 else 2


static func ped_corner_pos(i: int, j: int, c: int) -> Vector3:
    var s: Vector2i = CORNER_SIGNS[c]
    return Vector3((i + 0.5) * PITCH + s.x * RING, 0.0, (j + 0.5) * PITCH + s.y * RING)


## Vizinhos de um canto de calçada: os dois cantos adjacentes do mesmo quarteirão
## e as travessias da rua até os quarteirões vizinhos.
static func ped_neighbors(i: int, j: int, c: int) -> Array:
    var result: Array = []
    result.append(Vector3i(i, j, (c + 1) % 4))
    result.append(Vector3i(i, j, (c + 3) % 4))
    var s: Vector2i = CORNER_SIGNS[c]
    if block_in_range(i + s.x, j):
        result.append(Vector3i(i + s.x, j, corner_index(-s.x, s.y)))
    if block_in_range(i, j + s.y):
        result.append(Vector3i(i, j + s.y, corner_index(s.x, -s.y)))
    return result


static func _ped_nodes() -> Array:
    if _ped_cache.is_empty():
        for ci in CITIES.size():
            var a: Vector2i = CITIES[ci]["bmin"]
            var b: Vector2i = CITIES[ci]["bmax"]
            for i in range(a.x, b.x + 1):
                for j in range(a.y, b.y + 1):
                    for c in 4:
                        _ped_cache.append(Vector3i(i, j, c))
    return _ped_cache


static func ped_nodes_in_range(center: Vector3, rmin: float, rmax: float) -> Array:
    var out: Array = []
    for n: Vector3i in _ped_nodes():
        var p := ped_corner_pos(n.x, n.y, n.z)
        var d := Vector2(p.x - center.x, p.z - center.z).length()
        if d >= rmin and d <= rmax:
            out.append(n)
    return out


## Todos os trechos de via (de um cruzamento até o seguinte, em cada sentido).
static func traffic_edges() -> Array:
    if _edge_cache.is_empty():
        var seen := {}
        var nodes: Array = []
        for ci in CITIES.size():
            var a := road_min(ci)
            var b := road_max(ci)
            for ix in range(a.x, b.x + 1):
                for iz in range(a.y, b.y + 1):
                    var key := Vector2i(ix, iz)
                    if not seen.has(key):
                        seen[key] = true
                        nodes.append(key)
        for hw: Dictionary in HIGHWAYS:
            var f: Vector2i = hw["from"]
            var t: Vector2i = hw["to"]
            var steps := maxi(absi(t.x - f.x), absi(t.y - f.y))
            var step := Vector2i(signi(t.x - f.x), signi(t.y - f.y))
            for k in range(0, steps + 1):
                var key2 := f + step * k
                if not seen.has(key2):
                    seen[key2] = true
                    nodes.append(key2)
        for n: Vector2i in nodes:
            for d: Vector2i in DIRS:
                var m := n + d
                if road_node_exists(m.x, m.y):
                    _edge_cache.append({"ix": n.x, "iz": n.y, "dir": d})
    return _edge_cache


## Trechos de via cujo ponto médio está no anel [rmin, rmax] ao redor de center.
static func traffic_starts_in_range(center: Vector3, rmin: float, rmax: float) -> Array:
    var out: Array = []
    for e: Dictionary in traffic_edges():
        var d: Vector2i = e["dir"]
        var mid := Vector2((float(e["ix"]) + d.x * 0.5) * PITCH, (float(e["iz"]) + d.y * 0.5) * PITCH)
        var dist := Vector2(mid.x - center.x, mid.y - center.z).length()
        if dist >= rmin and dist <= rmax:
            out.append(e)
    return out


# ------------------------------------------------------------------ GPS

## Compatibilidade: índice de rua mais próximo na cidade principal.
static func nearest_road_index(v: float) -> int:
    return clampi(roundi(v / PITCH), ROAD_MIN, ROAD_MAX)


static func _snap_city(p: Vector2, ci: int) -> Vector2:
    var rmin := road_min(ci)
    var rmax := road_max(ci)
    var kx := clampi(roundi(p.x / PITCH), rmin.x, rmax.x)
    var kz := clampi(roundi(p.y / PITCH), rmin.y, rmax.y)
    var x0 := float(rmin.x) * PITCH
    var x1 := float(rmax.x) * PITCH
    var z0 := float(rmin.y) * PITCH
    var z1 := float(rmax.y) * PITCH
    var dx := absf(p.x - float(kx) * PITCH)
    var dz := absf(p.y - float(kz) * PITCH)
    if dx <= dz:
        return Vector2(float(kx) * PITCH, clampf(p.y, z0, z1))
    return Vector2(clampf(p.x, x0, x1), float(kz) * PITCH)


## Ponto da rua mais próximo (na cidade que contém o ponto ou na mais próxima).
static func snap_to_road(p: Vector2) -> Vector2:
    var ci := city_at(p)
    if ci < 0:
        ci = nearest_city(p)
    return _snap_city(p, ci)


## Rota em L pelas avenidas de uma cidade. Retorna 7 pontos x,z.
static func _route_city(from: Vector2, to: Vector2, ci: int) -> PackedVector2Array:
    var rmin := road_min(ci)
    var rmax := road_max(ci)
    var a := _snap_city(from, ci)
    var b := _snap_city(to, ci)
    var ia := Vector2(float(clampi(roundi(a.x / PITCH), rmin.x, rmax.x)), float(clampi(roundi(a.y / PITCH), rmin.y, rmax.y))) * PITCH
    var ib := Vector2(float(clampi(roundi(b.x / PITCH), rmin.x, rmax.x)), float(clampi(roundi(b.y / PITCH), rmin.y, rmax.y))) * PITCH
    var corner := Vector2(ib.x, ia.y)
    return PackedVector2Array([from, a, ia, corner, ib, b, to])


## Rota do GPS. Na mesma cidade: 7 pontos. Entre cidades: sai pela rodovia até a cidade
## principal (que é o centro de todas as rodovias), atravessa a rodovia seguinte e chega ao destino.
static func route(from: Vector2, to: Vector2) -> PackedVector2Array:
    var cf := city_at(from)
    if cf < 0:
        cf = nearest_city(from)
    var ct := city_at(to)
    if ct < 0:
        ct = nearest_city(to)
    if cf == ct:
        return _route_city(from, to, cf)
    var pts := PackedVector2Array()
    var cur := from
    if cf != 0:
        pts.append_array(_route_city(cur, gate_pos(cf), cf))
        cur = hub_gate_pos(cf)
        pts.append(cur)
    if ct != 0:
        pts.append_array(_route_city(cur, hub_gate_pos(ct), 0))
        pts.append(gate_pos(ct))
        pts.append_array(_route_city(gate_pos(ct), to, ct))
    else:
        pts.append_array(_route_city(cur, to, 0))
    return pts
