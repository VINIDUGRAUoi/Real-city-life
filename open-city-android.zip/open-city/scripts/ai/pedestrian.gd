extends CharacterBody3D
## Pedestre com esqueleto e animação. Anda pelas "calçadas" do grafo da cidade, para às
## vezes, foge de veículos rápidos vindo na sua direção e cai se for atingido. Tem papéis
## (caminhante, corredor, parado) e responde com um balão de fala quando o jogador usa
## "interact" perto dele.
## Estados: WALK, IDLE, FLEE, HIT (atropelado), STAGGER (levou um golpe), FIGHT (revida), DEAD.
## Pode ser atingido pelo jogador (golpes e tiros): veja hit_by().

const GraphScript := preload("res://scripts/ai/city_graph.gd")
const HumanoidScript := preload("res://scripts/ai/humanoid.gd")

enum State { WALK, IDLE, FLEE, HIT, STAGGER, FIGHT, DEAD }

const PHRASES := [
    "Bom dia!", "Cuidado com o trânsito por aqui.", "Você viu aquele carro esportivo?", "Nossa, que calor hoje...",
    "Estou atrasado para o trabalho!", "Essa cidade não para nunca.", "Se quiser um mapa, aperte M.",
    "Os motoristas daqui são loucos.", "Boa sorte na estrada!", "Tem uma praça bonita pertinho daqui.",
    "Não corra na calçada, amigo!", "Hoje está um dia perfeito.",
]

var state := State.WALK
var role := "walker"
var walk_speed := 1.5
var run_speed := 5.5
var node := Vector3i.ZERO
var target := Vector3.ZERO

var _prev := Vector3i.ZERO
var _visual: Node3D
var _rig: Dictionary = {}
var _phase := 0.0
var _scan := 0.0
var _timer := 0.0
var _flee_dir := Vector3.ZERO
var _stuck := 0.0
var _last_pos := Vector3.ZERO
var health := 40.0
var aggressive := false # revida quando apanha
var _attacker: Node3D
var _fight_cd := 0.0
var _punch_anim := 0.0
var _bubble: Label3D
var _bubble_timer := 0.0
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")


func _ready() -> void:
    collision_layer = 2 # pedestres não colidem entre si nem empurram veículos
    collision_mask = 1
    var roll := randf()
    if roll < 0.2:
        role = "jogger"
    elif roll < 0.35:
        role = "idler"
    walk_speed = randf_range(2.8, 3.6) if role == "jogger" else randf_range(1.2, 1.9)
    health = randf_range(30.0, 55.0)
    aggressive = randf() < 0.3
    _build()
    add_to_group("pedestrians")
    _scan = randf() * 0.25
    _last_pos = global_position
    if role == "idler":
        state = State.IDLE
        _timer = randf_range(2.0, 8.0)


## Coloca o pedestre no canto de calçada n e escolhe o próximo destino.
func place(n: Vector3i) -> void:
    node = n
    _prev = n
    position = GraphScript.ped_corner_pos(n.x, n.y, n.z) + Vector3(0.0, 0.1, 0.0)
    velocity = Vector3.ZERO
    state = State.WALK
    health = randf_range(30.0, 55.0)
    _attacker = null
    if _visual != null:
        _visual.rotation.x = 0.0
    _pick_next()


func _build() -> void:
    var shape := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.3
    cap.height = 1.7
    shape.shape = cap
    shape.position.y = 0.85
    add_child(shape)
    _rig = HumanoidScript.build(self, HumanoidScript.random_outfit(), 110.0)
    _visual = _rig["root"]


func _pick_next() -> void:
    var options := GraphScript.ped_neighbors(node.x, node.y, node.z)
    if options.is_empty():
        return
    var filtered := options.filter(func(n: Vector3i) -> bool: return n != _prev)
    if not filtered.is_empty():
        options = filtered
    var next: Vector3i = options.pick_random()
    _prev = node
    node = next
    target = GraphScript.ped_corner_pos(node.x, node.y, node.z)


## Conversa: para, vira para o jogador e mostra um balão de fala.
func talk(player: Node3D) -> void:
    if state == State.HIT or state == State.DEAD or state == State.STAGGER or state == State.FIGHT:
        return
    state = State.IDLE
    _timer = 4.0
    var off := player.global_position - global_position
    rotation.y = atan2(-off.x, -off.z)
    if _bubble == null:
        _bubble = Label3D.new()
        _bubble.billboard = BaseMaterial3D.BILLBOARD_ENABLED
        _bubble.no_depth_test = true
        _bubble.pixel_size = 0.006
        _bubble.font_size = 40
        _bubble.outline_size = 12
        _bubble.position = Vector3(0.0, 2.25, 0.0)
        _bubble.width = 520.0
        _bubble.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        add_child(_bubble)
    _bubble.text = PHRASES.pick_random()
    _bubble.visible = true
    _bubble_timer = 3.5


## Chamado pelo jogador (soco, taco, tiro). dir = direção horizontal do golpe.
func hit_by(attacker: Node3D, damage: float, dir: Vector3, knock: float = 3.0) -> void:
    if state == State.DEAD:
        return
    health -= damage
    _attacker = attacker
    var flat := Vector3(dir.x, 0.0, dir.z)
    if flat.length() > 0.01:
        flat = flat.normalized()
    velocity.x = flat.x * knock
    velocity.z = flat.z * knock
    if health <= 0.0:
        _die()
        return
    state = State.STAGGER
    _timer = 0.7
    _visual.rotation.x = deg_to_rad(-22.0)
    if _bubble != null:
        _bubble.visible = false


func is_dead() -> bool:
    return state == State.DEAD


func _die() -> void:
    state = State.DEAD
    _timer = 8.0
    _visual.rotation.x = deg_to_rad(-90.0)
    velocity.x = 0.0
    velocity.z = 0.0
    var gs := get_node_or_null("/root/GameState")
    if gs != null:
        gs.add_money(randi_range(10, 60)) # carteira caída


func _after_stagger() -> void:
    _visual.rotation.x = 0.0
    var player_ok := _attacker != null and is_instance_valid(_attacker)
    if player_ok and _attacker.has_method("is_driving") and _attacker.is_driving():
        player_ok = false
    if player_ok and aggressive:
        state = State.FIGHT
        _timer = 12.0
        _fight_cd = 0.6
    elif player_ok:
        var away := global_position - _attacker.global_position
        away.y = 0.0
        _flee_dir = away.normalized() if away.length() > 0.01 else Vector3.FORWARD
        state = State.FLEE
        _timer = 4.0
    else:
        state = State.WALK


func _fight(delta: float) -> bool:
    if _attacker == null or not is_instance_valid(_attacker):
        state = State.WALK
        return false
    var to := _attacker.global_position - global_position
    to.y = 0.0
    var dist := to.length()
    if dist > 30.0 or (_attacker.has_method("is_driving") and _attacker.is_driving()):
        state = State.WALK
        return false
    _fight_cd -= delta
    if _punch_anim > 0.0:
        _punch_anim -= delta
    if dist > 1.2:
        _move(to / dist, run_speed * 0.85, delta)
        return true
    _stop(delta)
    rotation.y = lerp_angle(rotation.y, atan2(-to.x, -to.z), minf(1.0, 10.0 * delta))
    if _fight_cd <= 0.0:
        _fight_cd = 1.0
        _punch_anim = 0.3
        if _attacker.has_method("take_damage"):
            _attacker.take_damage(5.0)
    return false


func _physics_process(delta: float) -> void:
    _scan -= delta
    if _scan <= 0.0:
        _scan = 0.25
        _scan_threats()
    if _bubble != null and _bubble.visible:
        _bubble_timer -= delta
        if _bubble_timer <= 0.0:
            _bubble.visible = false

    var moving := false
    match state:
        State.WALK:
            moving = _walk(delta)
        State.IDLE:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                if role == "idler" and randf() < 0.6:
                    _timer = randf_range(3.0, 9.0)
                else:
                    state = State.WALK
        State.FLEE:
            _move(_flee_dir, run_speed, delta)
            moving = true
            _timer -= delta
            if _timer <= 0.0:
                state = State.WALK
        State.HIT:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                _visual.rotation.x = 0.0
                state = State.WALK
        State.STAGGER:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                _after_stagger()
        State.FIGHT:
            moving = _fight(delta)
            _timer -= delta
            if _timer <= 0.0 and state == State.FIGHT:
                state = State.WALK
        State.DEAD:
            _stop(delta)
            _timer -= delta
            if _timer <= 0.0:
                var nodes := GraphScript.ped_nodes_in_range(global_position, 0.0, 400.0)
                if nodes.is_empty():
                    place(node)
                else:
                    place(nodes.pick_random())

    var hspeed := Vector2(velocity.x, velocity.z).length()
    _phase += hspeed * delta * 3.2
    HumanoidScript.animate(_rig, _phase, clampf(hspeed / 2.0, 0.0, 1.4) if moving else 0.0)
    if state == State.FIGHT and _punch_anim > 0.0:
        HumanoidScript.pose_attack(_rig, 1.0 - _punch_anim / 0.3, "punch")

    if not is_on_floor():
        velocity.y -= _gravity * delta
    else:
        velocity.y = -0.1
    move_and_slide()

    if state == State.WALK:
        _stuck += delta
        if _stuck > 2.0:
            if (global_position - _last_pos).length() < 0.4:
                _pick_next()
            _last_pos = global_position
            _stuck = 0.0
    if global_position.y < -20.0:
        place(node)


func _walk(delta: float) -> bool:
    var to := target - global_position
    to.y = 0.0
    if to.length() < 0.7:
        if randf() < 0.2:
            state = State.IDLE
            _timer = randf_range(1.5, 4.0)
        else:
            _pick_next()
        return false
    _move(to.normalized(), walk_speed, delta)
    return true


func _move(dir: Vector3, speed: float, delta: float) -> void:
    velocity.x = move_toward(velocity.x, dir.x * speed, 12.0 * delta)
    velocity.z = move_toward(velocity.z, dir.z * speed, 12.0 * delta)
    rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, 8.0 * delta))


func _stop(delta: float) -> void:
    velocity.x = move_toward(velocity.x, 0.0, 12.0 * delta)
    velocity.z = move_toward(velocity.z, 0.0, 12.0 * delta)


func _scan_threats() -> void:
    if state == State.HIT or state == State.DEAD or state == State.STAGGER or state == State.FIGHT:
        return
    var pos := global_position
    for group in ["vehicles", "traffic"]:
        for v in get_tree().get_nodes_in_group(group):
            if not v.has_method("get_speed"):
                continue
            var spd: float = v.get_speed()
            if spd < 3.0:
                continue
            var off: Vector3 = pos - v.global_position
            off.y = 0.0
            var dist := off.length()
            if dist > 14.0:
                continue
            if spd > 6.0 and dist < 2.0:
                state = State.HIT
                _timer = 4.0
                _visual.rotation.x = deg_to_rad(-90.0)
                return
            var fwd: Vector2 = v.get_forward_xz()
            var away := Vector2(off.x, off.z).normalized()
            if dist < 12.0 and away.dot(fwd) > 0.5 and state != State.FLEE:
                var side := Vector2(-fwd.y, fwd.x)
                if away.dot(side) < 0.0:
                    side = -side
                _flee_dir = Vector3(side.x, 0.0, side.y)
                state = State.FLEE
                _timer = 2.5
                return
