extends RefCounted
## Armas do jogo: dados (dano, alcance, intervalo, preço) e modelos simples feitos em código.
## kind: "melee" (corpo a corpo: soco, taco...) ou "gun" (tiro instantâneo na direção da câmera).
## Munição infinita por enquanto. anim: "punch", "swing" (taco/pé de cabra) ou "aim" (arma de fogo).

const ORDER := ["fists", "bat", "crowbar", "pistol", "smg", "shotgun"]

const DATA := {
    "fists": {"name": "Punhos", "price": 0, "kind": "melee", "anim": "punch", "damage": 9.0, "range": 1.9, "cooldown": 0.42, "knock": 3.5,
        "desc": "Soco rápido. Sempre disponível."},
    "bat": {"name": "Taco de beisebol", "price": 350, "kind": "melee", "anim": "swing", "damage": 24.0, "range": 2.4, "cooldown": 0.65, "knock": 6.5,
        "desc": "Pancada forte de perto."},
    "crowbar": {"name": "Pé de cabra", "price": 450, "kind": "melee", "anim": "swing", "damage": 28.0, "range": 2.2, "cooldown": 0.6, "knock": 6.0,
        "desc": "Pesado e resistente."},
    "pistol": {"name": "Pistola", "price": 1800, "kind": "gun", "anim": "aim", "damage": 28.0, "range": 70.0, "cooldown": 0.35, "auto": false, "spread": 0.012, "pellets": 1, "knock": 3.0,
        "desc": "Tiro único, boa precisão."},
    "smg": {"name": "Submetralhadora", "price": 6500, "kind": "gun", "anim": "aim", "damage": 13.0, "range": 55.0, "cooldown": 0.09, "auto": true, "spread": 0.05, "pellets": 1, "knock": 1.5,
        "desc": "Rajada automática (segure o botão)."},
    "shotgun": {"name": "Espingarda", "price": 4200, "kind": "gun", "anim": "aim", "damage": 11.0, "range": 28.0, "cooldown": 0.9, "auto": false, "spread": 0.11, "pellets": 8, "knock": 5.0,
        "desc": "Vários projéteis, forte de perto."},
}


static func exists(id: String) -> bool:
    return DATA.has(id)


static func weapon_name(id: String) -> String:
    return str(DATA[id]["name"]) if DATA.has(id) else "?"


static func price(id: String) -> int:
    return int(DATA[id]["price"]) if DATA.has(id) else 0


static func is_gun(id: String) -> bool:
    return DATA.has(id) and DATA[id]["kind"] == "gun"


static func _part(parent: Node3D, mesh: Mesh, pos: Vector3, color: Color, rot_deg: Vector3 = Vector3.ZERO) -> void:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.6
    mi.material_override = mat
    mi.position = pos
    mi.rotation_degrees = rot_deg
    parent.add_child(mi)


static func _box(size: Vector3) -> BoxMesh:
    var b := BoxMesh.new()
    b.size = size
    return b


static func _cyl(r_top: float, r_bottom: float, h: float) -> CylinderMesh:
    var c := CylinderMesh.new()
    c.top_radius = r_top
    c.bottom_radius = r_bottom
    c.height = h
    c.radial_segments = 8
    return c


## Modelo para a mão direita. Origem = mão; o objeto se estende para -Y (direção do antebraço).
## Devolve null para "fists".
static func build_model(id: String) -> Node3D:
    if id == "fists" or not DATA.has(id):
        return null
    var root := Node3D.new()
    root.name = "WeaponModel"
    match id:
        "bat":
            _part(root, _cyl(0.05, 0.027, 0.78), Vector3(0.0, -0.3, 0.0), Color(0.72, 0.5, 0.25))
        "crowbar":
            _part(root, _cyl(0.022, 0.022, 0.7), Vector3(0.0, -0.28, 0.0), Color(0.25, 0.25, 0.3))
            _part(root, _box(Vector3(0.03, 0.12, 0.03)), Vector3(0.0, -0.64, 0.045), Color(0.25, 0.25, 0.3), Vector3(-35.0, 0.0, 0.0))
        "pistol":
            _part(root, _box(Vector3(0.04, 0.2, 0.05)), Vector3(0.0, -0.1, 0.0), Color(0.12, 0.12, 0.14))
            _part(root, _box(Vector3(0.035, 0.04, 0.09)), Vector3(0.0, -0.03, 0.05), Color(0.1, 0.1, 0.12))
        "smg":
            _part(root, _box(Vector3(0.05, 0.36, 0.06)), Vector3(0.0, -0.16, 0.0), Color(0.15, 0.15, 0.17))
            _part(root, _box(Vector3(0.035, 0.05, 0.12)), Vector3(0.0, -0.04, 0.06), Color(0.1, 0.1, 0.12))
            _part(root, _box(Vector3(0.035, 0.05, 0.14)), Vector3(0.0, -0.18, 0.09), Color(0.2, 0.2, 0.22))
        "shotgun":
            _part(root, _cyl(0.02, 0.02, 0.62), Vector3(0.0, -0.28, 0.0), Color(0.2, 0.2, 0.22))
            _part(root, _box(Vector3(0.05, 0.22, 0.07)), Vector3(0.0, -0.05, 0.03), Color(0.45, 0.3, 0.18))
    root.position = Vector3(0.0, -0.24, 0.0)
    return root
