extends Node3D
## Gera a cidade: centro com prédios altos e lojas, bairro intermediário com prédios baixos,
## subúrbio com casas (telhado, porta, janelas), praças com árvores, avenidas com faixas
## de pedestre e postes. Toda a geometria e as texturas são criadas em código (procedurais).
## Cada quarteirão vira UMA malha com vários materiais (poucos draw calls) + colisões simples.
## Há várias cidades (veja CITIES em scripts/ai/city_graph.gd) ligadas por rodovias, com pontes
## sobre os rios. A geração é determinística (SEED fixa).

const GeoScript := preload("res://scripts/core/geo.gd")
const TexScript := preload("res://scripts/world/textures.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")

const BLOCK_SIZE := 40.0
const ROAD_WIDTH := 12.0
const PITCH := BLOCK_SIZE + ROAD_WIDTH
## O tamanho e a posição de cada cidade ficam em CITIES (scripts/ai/city_graph.gd).
## A calçada fica entre 17 e 20 m do centro do quarteirão (a rua começa em 20 m).
## Os postes ficam na calçada, perto do meio-fio, com o braço da luminária sobre a rua.
const LAMP_OFFSET := 19.5
## Quarteirões distantes são construídos aos poucos (tempo máximo por quadro, em microssegundos).
const BUILD_BUDGET_USEC := 8000
const FIRST_BLOCKS := 12
const SEED := 1337
## Rios e pontes
const BANK_DEPTH := 4.0 # espessura do chão (a margem do rio tem essa altura)
const WATER_Y := -3.0
const BANK_COLOR := Color(0.36, 0.3, 0.22)
const BRIDGE_APPROACH := 8.0 # a laje da ponte avança sobre a margem
const BRIDGE_THICKNESS := 1.4
const PILLAR_SPACING := 36.0

const FLOOR_H := 3.5
const GROUND_FLOOR_H := 4.0
const FACADE_TILE := Vector2(8.0, 7.0)
const GROUND_TOP := 0.06 # topo da colisão do chão
const GRASS_Y := 0.05
const FLAT_Y := 0.06 # ruas e calçadas
const MARK_Y := 0.085 # faixas pintadas

const MATS := ["facade_glass", "facade_brick", "facade_concrete", "storefront", "house_wall",
    "roof_gravel", "roof_tile", "concrete", "grass", "asphalt", "plain"]
const AWNINGS := [Color(0.8, 0.2, 0.2), Color(0.2, 0.5, 0.3), Color(0.2, 0.3, 0.6), Color(0.9, 0.7, 0.2)]
const PLASTERS := [Color(1.0, 1.0, 0.95), Color(0.98, 0.9, 0.75), Color(0.85, 0.92, 0.98), Color(0.98, 0.85, 0.8), Color(0.9, 0.96, 0.88)]
const ROOFS := [Color(0.75, 0.32, 0.22), Color(0.32, 0.34, 0.4), Color(0.45, 0.3, 0.22)]

var building_count := 0
var park_count := 0
var building_rects: Array[Rect2] = []
var park_rects: Array[Rect2] = []

var _pending: Array[Vector3i] = [] # x = i, y = j, z = índice da cidade
var _sun: DirectionalLight3D
var _rng := RandomNumberGenerator.new()
var _materials := {}


## progressive = true: constrói já só os quarteirões mais próximos do centro e o resto aos poucos
## (evita travar o celular ao abrir o jogo). false: constrói tudo de uma vez (testes).
func build(progressive: bool = false) -> void:
    set_process(false)
    _pending.clear()
    building_count = 0
    park_count = 0
    building_rects.clear()
    park_rects.clear()
    _add_environment()
    _add_ground()
    _add_roads()
    _queue_blocks()
    var now := mini(FIRST_BLOCKS, _pending.size()) if progressive else _pending.size()
    for n in now:
        var first: Vector3i = _pending.pop_front()
        _build_block(first)
    if not _pending.is_empty():
        set_process(true)
    _add_test_props()


func _process(_delta: float) -> void:
    var t0 := Time.get_ticks_usec()
    while not _pending.is_empty():
        var b: Vector3i = _pending.pop_front()
        _build_block(b)
        if Time.get_ticks_usec() - t0 > BUILD_BUDGET_USEC:
            break
    if _pending.is_empty():
        set_process(false)


# ------------------------------------------------------------------ ambiente

func _add_environment() -> void:
    var sky_material := ProceduralSkyMaterial.new()
    var sky := Sky.new()
    sky.sky_material = sky_material
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    var world_env := WorldEnvironment.new()
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50.0, -30.0, 0.0)
    sun.shadow_enabled = _shadows_enabled()
    sun.directional_shadow_max_distance = 120.0
    add_child(sun)
    _sun = sun
    var gs := get_node_or_null("/root/GameSettings")
    if gs != null:
        gs.changed.connect(_on_settings_changed)


func _shadows_enabled() -> bool:
    var gs := get_node_or_null("/root/GameSettings")
    if gs != null:
        return gs.shadows
    return not OS.has_feature("mobile") # sombras pesam em celular


func _on_settings_changed() -> void:
    if _sun != null:
        _sun.shadow_enabled = _shadows_enabled()


## Dados para o mapa: retângulos (x, z, largura, profundidade) de prédios e parques.
func get_map_data() -> Dictionary:
    return {"buildings": building_rects, "parks": park_rects}


# --------------------------------------------------------------------- malhas

func _new_sts() -> Dictionary:
    var d := {}
    for m in MATS:
        d[m] = GeoScript.new_st()
    return d


func _commit(sts: Dictionary, node_name: String) -> void:
    var mesh := ArrayMesh.new()
    for key: String in sts:
        var st: SurfaceTool = sts[key]
        if not GeoScript.has_data(st):
            continue
        st.commit(mesh)
        mesh.surface_set_material(mesh.get_surface_count() - 1, TexScript.material(key))
    if mesh.get_surface_count() == 0:
        return
    var mi := MeshInstance3D.new()
    mi.name = node_name
    mi.mesh = mesh
    add_child(mi)


func _collider(body: StaticBody3D, pos: Vector3, size: Vector3) -> void:
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = size
    shape.shape = box
    shape.position = pos
    body.add_child(shape)


func _water_material() -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.1, 0.32, 0.5)
    mat.roughness = 0.25
    mat.metallic = 0.1
    return mat


func _add_ground() -> void:
    var body := StaticBody3D.new()
    body.name = "GroundBody"
    var sts := _new_sts()
    for r: Rect2 in GraphScript.ground_rects():
        var c := r.get_center()
        _collider(body, Vector3(c.x, GROUND_TOP - BANK_DEPTH * 0.5, c.y), Vector3(r.size.x, BANK_DEPTH, r.size.y))
        GeoScript.flat_quad(sts["grass"], r.position.x, r.position.y, r.end.x, r.end.y, GRASS_Y, 6.0, Color.WHITE)
        # paredes da margem (terra) visíveis para quem olha o rio
        GeoScript.box(sts["plain"], Vector3(c.x, GROUND_TOP - BANK_DEPTH, c.y), Vector3(r.size.x, BANK_DEPTH - 0.01, r.size.y), Vector2.ONE, 0.0, BANK_COLOR, true, false, false)
    add_child(body)
    _commit(sts, "GroundMesh")
    # água: um plano enorme abaixo do chão; aparece nos rios e em volta do mundo
    var w := GraphScript.world_rect()
    var water := MeshInstance3D.new()
    water.name = "Water"
    var plane := PlaneMesh.new()
    plane.size = Vector2(14000.0, 14000.0)
    water.mesh = plane
    water.material_override = _water_material()
    water.position = Vector3(w.get_center().x, WATER_Y, w.get_center().y)
    add_child(water)


func _add_roads() -> void:
    for ci in GraphScript.city_count():
        _add_city_roads(ci)
    _add_highways()


func _add_city_roads(ci: int) -> void:
    var rmin := GraphScript.road_min(ci)
    var rmax := GraphScript.road_max(ci)
    var x0 := float(rmin.x) * PITCH - ROAD_WIDTH * 0.5
    var x1 := float(rmax.x) * PITCH + ROAD_WIDTH * 0.5
    var z0 := float(rmin.y) * PITCH - ROAD_WIDTH * 0.5
    var z1 := float(rmax.y) * PITCH + ROAD_WIDTH * 0.5
    var sts := _new_sts()
    var asphalt: SurfaceTool = sts["asphalt"]
    var plain: SurfaceTool = sts["plain"]
    var yellow := Color(0.95, 0.8, 0.2)
    var white := Color(0.93, 0.93, 0.93)
    for kx in range(rmin.x, rmax.x + 1):
        var c := float(kx) * PITCH
        GeoScript.flat_quad(asphalt, c - ROAD_WIDTH * 0.5, z0, c + ROAD_WIDTH * 0.5, z1, FLAT_Y, 6.0, Color.WHITE)
        var s := z0 + 3.0
        while s < z1 - 3.0:
            var mid := s + 1.5
            var near := roundf(mid / PITCH) * PITCH
            if absf(mid - near) > 11.0:
                GeoScript.flat_quad(plain, c - 0.1, s, c + 0.1, s + 3.0, MARK_Y, 1.0, yellow)
            s += 6.0
    for kz in range(rmin.y, rmax.y + 1):
        var c := float(kz) * PITCH
        GeoScript.flat_quad(asphalt, x0, c - ROAD_WIDTH * 0.5, x1, c + ROAD_WIDTH * 0.5, FLAT_Y, 6.0, Color.WHITE)
        var s := x0 + 3.0
        while s < x1 - 3.0:
            var mid := s + 1.5
            var near := roundf(mid / PITCH) * PITCH
            if absf(mid - near) > 11.0:
                GeoScript.flat_quad(plain, s, c - 0.1, s + 3.0, c + 0.1, MARK_Y, 1.0, yellow)
            s += 6.0
    # faixas de pedestre nos lados de cada cruzamento que têm rua do outro lado
    for ix in range(rmin.x, rmax.x + 1):
        for iz in range(rmin.y, rmax.y + 1):
            var cx := float(ix) * PITCH
            var cz := float(iz) * PITCH
            var east := GraphScript.road_node_exists(ix + 1, iz)
            var west := GraphScript.road_node_exists(ix - 1, iz)
            var south := GraphScript.road_node_exists(ix, iz + 1)
            var north := GraphScript.road_node_exists(ix, iz - 1)
            for n in 11:
                var o := -5.0 + float(n)
                if east:
                    GeoScript.flat_quad(plain, cx + 7.0, cz + o - 0.25, cx + 10.0, cz + o + 0.25, MARK_Y, 1.0, white)
                if west:
                    GeoScript.flat_quad(plain, cx - 10.0, cz + o - 0.25, cx - 7.0, cz + o + 0.25, MARK_Y, 1.0, white)
                if south:
                    GeoScript.flat_quad(plain, cx + o - 0.25, cz + 7.0, cx + o + 0.25, cz + 10.0, MARK_Y, 1.0, white)
                if north:
                    GeoScript.flat_quad(plain, cx + o - 0.25, cz - 10.0, cx + o + 0.25, cz - 7.0, MARK_Y, 1.0, white)
    _commit(sts, "Roads_%d" % ci)


# ------------------------------------------------------------ rodovias e pontes

## Quadrilátero da rodovia: u = ao longo do eixo (u0..u1), v = através (v0..v1, relativo ao eixo c).
func _hq(st: SurfaceTool, along_x: bool, c: float, u0: float, u1: float, v0: float, v1: float, y: float, tile: float, color: Color) -> void:
    if along_x:
        GeoScript.flat_quad(st, u0, c + v0, u1, c + v1, y, tile, color)
    else:
        GeoScript.flat_quad(st, c + v0, u0, c + v1, u1, y, tile, color)


## Caixa com centro (u, c + v) e tamanho (len ao longo do eixo, h, wid através).
func _hbox(st: SurfaceTool, along_x: bool, c: float, u: float, v: float, base_y: float, length: float, height: float, wid: float, color: Color, top: bool = true) -> Vector3:
    var pos: Vector3
    var size: Vector3
    if along_x:
        pos = Vector3(u, base_y, c + v)
        size = Vector3(length, height, wid)
    else:
        pos = Vector3(c + v, base_y, u)
        size = Vector3(wid, height, length)
    GeoScript.box(st, pos, size, Vector2.ONE, 0.0, color, true, top, true)
    return pos


func _add_highways() -> void:
    var sts := _new_sts()
    var body := StaticBody3D.new()
    body.name = "HighwayBody"
    for hw: Dictionary in GraphScript.HIGHWAYS:
        _build_highway(hw, sts, body)
    add_child(body)
    _commit(sts, "Highways")


func _build_highway(hw: Dictionary, sts: Dictionary, body: StaticBody3D) -> void:
    var pts := GraphScript.highway_world_points(hw)
    var a: Vector2 = pts[0]
    var b: Vector2 = pts[1]
    var dir := (b - a).normalized()
    var along_x := absf(dir.x) > 0.5
    var c := a.y if along_x else a.x # coordenada do eixo da rodovia
    var ua := a.x if along_x else a.y
    var ub := b.x if along_x else b.y
    var sign_u := signf(ub - ua)
    # a rodovia começa na borda do cruzamento de uma cidade e termina na borda do outro
    var p0 := ua + sign_u * ROAD_WIDTH * 0.5
    var p1 := ub - sign_u * ROAD_WIDTH * 0.5
    var u0 := minf(p0, p1)
    var u1 := maxf(p0, p1)
    var half_w := GraphScript.HIGHWAY_WIDTH * 0.5
    var asphalt: SurfaceTool = sts["asphalt"]
    var plain: SurfaceTool = sts["plain"]
    var yellow := Color(0.95, 0.8, 0.2)
    var white := Color(0.93, 0.93, 0.93)
    _hq(asphalt, along_x, c, u0, u1, -half_w, half_w, FLAT_Y, 6.0, Color.WHITE)
    _hq(plain, along_x, c, u0, u1, -0.3, -0.15, MARK_Y, 1.0, yellow)
    _hq(plain, along_x, c, u0, u1, 0.15, 0.3, MARK_Y, 1.0, yellow)
    _hq(plain, along_x, c, u0, u1, -half_w + 0.4, -half_w + 0.55, MARK_Y, 1.0, white)
    _hq(plain, along_x, c, u0, u1, half_w - 0.55, half_w - 0.4, MARK_Y, 1.0, white)

    # ponte sobre o rio
    var river: Vector2 = hw["river"]
    var b0 := river.x - BRIDGE_APPROACH
    var b1 := river.y + BRIDGE_APPROACH
    var length := b1 - b0
    var mid := (b0 + b1) * 0.5
    var slab_pos := _hbox(plain, along_x, c, mid, 0.0, FLAT_Y - BRIDGE_THICKNESS, length, BRIDGE_THICKNESS, GraphScript.HIGHWAY_WIDTH + 1.0, Color(0.55, 0.55, 0.58), false)
    var slab_size := Vector3(length, BRIDGE_THICKNESS, GraphScript.HIGHWAY_WIDTH + 1.0) if along_x else Vector3(GraphScript.HIGHWAY_WIDTH + 1.0, BRIDGE_THICKNESS, length)
    _collider(body, slab_pos + Vector3(0.0, BRIDGE_THICKNESS * 0.5, 0.0), slab_size)
    for side: float in [-1.0, 1.0]:
        var rail_v := side * (half_w + 0.3)
        var rail_pos := _hbox(plain, along_x, c, mid, rail_v, FLAT_Y, length, 1.0, 0.5, Color(0.8, 0.8, 0.82))
        var rail_size := Vector3(length, 1.0, 0.5) if along_x else Vector3(0.5, 1.0, length)
        _collider(body, rail_pos + Vector3(0.0, 0.5, 0.0), rail_size)
    var pu := river.x + PILLAR_SPACING * 0.5
    while pu < river.y:
        for side: float in [-1.0, 1.0]:
            _hbox(plain, along_x, c, pu, side * 4.0, -5.0, 1.8, 5.0 + FLAT_Y - BRIDGE_THICKNESS, 1.8, Color(0.62, 0.62, 0.65), false)
        pu += PILLAR_SPACING

    # postes de luz ao longo da rodovia (fora da ponte)
    var lu := u0 + 26.0
    while lu < u1 - 10.0:
        if lu < b0 - 4.0 or lu > b1 + 4.0:
            for side: float in [-1.0, 1.0]:
                var base := _hbox(plain, along_x, c, lu, side * (half_w + 1.4), FLAT_Y, 0.14, 5.5, 0.14, Color(0.2, 0.2, 0.22))
                _hbox(plain, along_x, c, lu, side * (half_w + 0.4), FLAT_Y + 5.4, 0.4, 0.1, 0.4, Color(1.0, 0.95, 0.8))
                _collider(body, base + Vector3(0.0, 2.75, 0.0), Vector3(0.25, 5.5, 0.25))
        lu += PITCH

    # pórticos com o nome da cidade, perto de cada ponta
    var city_a := str(GraphScript.CITIES[0]["name"])
    var city_b := str(GraphScript.CITIES[int(hw["city"])]["name"])
    _add_gantry(plain, body, along_x, c, p0 + sign_u * 45.0, city_a)
    _add_gantry(plain, body, along_x, c, p1 - sign_u * 45.0, city_b)


func _add_gantry(st: SurfaceTool, body: StaticBody3D, along_x: bool, c: float, u: float, text: String) -> void:
    var half_w := GraphScript.HIGHWAY_WIDTH * 0.5
    for side: float in [-1.0, 1.0]:
        var base := _hbox(st, along_x, c, u, side * (half_w + 1.0), FLAT_Y, 0.5, 8.0, 0.5, Color(0.25, 0.28, 0.32))
        _collider(body, base + Vector3(0.0, 4.0, 0.0), Vector3(0.5, 8.0, 0.5))
    _hbox(st, along_x, c, u, 0.0, FLAT_Y + 6.2, 0.5, 1.8, GraphScript.HIGHWAY_WIDTH + 3.0, Color(0.1, 0.45, 0.25))
    var label := Label3D.new()
    label.text = text
    label.font_size = 96
    label.pixel_size = 0.016
    label.outline_size = 14
    label.modulate = Color(1, 1, 1)
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.double_sided = true
    if along_x:
        label.position = Vector3(u, FLAT_Y + 9.8, c)
    else:
        label.position = Vector3(c, FLAT_Y + 9.8, u)
    add_child(label)


# ------------------------------------------------------------------ quarteirões

func _block_center(i: int, j: int) -> Vector3:
    return Vector3((float(i) + 0.5) * PITCH, 0.0, (float(j) + 0.5) * PITCH)


## Lista todos os quarteirões de todas as cidades, do mais próximo do ponto de partida ao mais distante.
func _queue_blocks() -> void:
    for ci in GraphScript.city_count():
        var a: Vector2i = GraphScript.CITIES[ci]["bmin"]
        var z: Vector2i = GraphScript.CITIES[ci]["bmax"]
        for i in range(a.x, z.x + 1):
            for j in range(a.y, z.y + 1):
                _pending.append(Vector3i(i, j, ci))
    _pending.sort_custom(func(a: Vector3i, b: Vector3i) -> bool:
        return _block_center(a.x, a.y).length() < _block_center(b.x, b.y).length())


func _build_block(b: Vector3i) -> void:
    var i := b.x
    var j := b.y
    var city: Dictionary = GraphScript.CITIES[b.z]
    # semente própria por quarteirão: o resultado não depende da ordem de construção
    _rng.seed = SEED + ((i + 64) * 200 + (j + 64)) * 7919
    var center := _block_center(i, j)
    var cc := GraphScript.city_center(b.z)
    var dist := Vector2(center.x - cc.x, center.z - cc.y).length()
    var sts := _new_sts()
    var body := StaticBody3D.new()
    body.name = "BlockBody_%d_%d" % [i, j]
    if dist > 60.0 and _rng.randf() < float(city["park_chance"]):
        _build_park(sts, body, center)
    elif dist < float(city["downtown"]):
        _slab(sts, center)
        _build_towers(sts, body, center, 8, 20, ["facade_glass", "facade_glass", "facade_concrete"], true)
    elif dist < float(city["midrise"]):
        _slab(sts, center)
        _build_towers(sts, body, center, 3, 8, ["facade_brick", "facade_concrete", "facade_glass"], true)
    else:
        _build_suburb(sts, body, center)
    _add_lamps(sts, body, center)
    add_child(body)
    _commit(sts, "Block_%d_%d" % [i, j])


func _slab(sts: Dictionary, c: Vector3) -> void:
    GeoScript.flat_quad(sts["concrete"], c.x - 20.0, c.z - 20.0, c.x + 20.0, c.z + 20.0, FLAT_Y, 3.0, Color.WHITE)


func _sidewalk_ring(sts: Dictionary, c: Vector3) -> void:
    var st: SurfaceTool = sts["concrete"]
    GeoScript.flat_quad(st, c.x - 20.0, c.z - 20.0, c.x + 20.0, c.z - 17.0, FLAT_Y, 3.0, Color.WHITE)
    GeoScript.flat_quad(st, c.x - 20.0, c.z + 17.0, c.x + 20.0, c.z + 20.0, FLAT_Y, 3.0, Color.WHITE)
    GeoScript.flat_quad(st, c.x - 20.0, c.z - 17.0, c.x - 17.0, c.z + 17.0, FLAT_Y, 3.0, Color.WHITE)
    GeoScript.flat_quad(st, c.x + 17.0, c.z - 17.0, c.x + 20.0, c.z + 17.0, FLAT_Y, 3.0, Color.WHITE)


func _snap4(v: float) -> float:
    return maxf(8.0, roundf(v / 4.0) * 4.0)


func _build_towers(sts: Dictionary, body: StaticBody3D, center: Vector3, floors_lo: int, floors_hi: int, styles: Array, shops: bool) -> void:
    for qx: float in [-1.0, 1.0]:
        for qz: float in [-1.0, 1.0]:
            var w := _snap4(_rng.randf_range(12.0, 17.0))
            var d := _snap4(_rng.randf_range(12.0, 17.0))
            var floors := _rng.randi_range(floors_lo, floors_hi)
            var style: String = styles[_rng.randi() % styles.size()]
            var pos := center + Vector3(qx * 10.0, 0.0, qz * 10.0)
            _add_tower(sts, body, pos, w, d, floors, style, shops, qz)


func _add_tower(sts: Dictionary, body: StaticBody3D, pos: Vector3, w: float, d: float, floors: int, style: String, shops: bool, qz: float) -> void:
    var tint: Color
    if style == "facade_glass":
        tint = Color.from_hsv(_rng.randf_range(0.5, 0.62), _rng.randf_range(0.0, 0.2), _rng.randf_range(0.85, 1.0))
    else:
        tint = Color.from_hsv(_rng.randf_range(0.0, 0.12), _rng.randf_range(0.0, 0.15), _rng.randf_range(0.8, 1.0))
    var y := 0.0
    if shops:
        GeoScript.box(sts["storefront"], Vector3(pos.x, FLAT_Y, pos.z), Vector3(w, GROUND_FLOOR_H, d), Vector2(8.0, 4.0), FLAT_Y, Color(0.92, 0.92, 0.96), true, false, false)
        y = FLAT_Y + GROUND_FLOOR_H
    var fac: SurfaceTool = sts[style]
    var h1 := float(floors) * FLOOR_H
    GeoScript.box(fac, Vector3(pos.x, y, pos.z), Vector3(w, h1, d), FACADE_TILE, y, tint, true, false, false)
    var top := y + h1
    var rw := w
    var rd := d
    if floors > 12:
        rw = w - 4.0
        rd = d - 4.0
        var f2 := 3 + _rng.randi() % 3
        GeoScript.top_quad(sts["roof_gravel"], pos.x, pos.z, w, d, top, 4.0, Color.WHITE)
        GeoScript.box(fac, Vector3(pos.x, top, pos.z), Vector3(rw, float(f2) * FLOOR_H, rd), FACADE_TILE, top, tint, true, false, false)
        top += float(f2) * FLOOR_H
    GeoScript.top_quad(sts["roof_gravel"], pos.x, pos.z, rw, rd, top, 4.0, Color.WHITE)
    for n in 1 + _rng.randi() % 3:
        var bw := _rng.randf_range(1.5, 3.0)
        var bh := _rng.randf_range(1.0, 2.0)
        var bx := pos.x + _rng.randf_range(-rw * 0.5 + 2.0, rw * 0.5 - 2.0)
        var bz := pos.z + _rng.randf_range(-rd * 0.5 + 2.0, rd * 0.5 - 2.0)
        GeoScript.box(sts["plain"], Vector3(bx, top, bz), Vector3(bw, bh, bw), Vector2.ONE, 0.0, Color(0.6, 0.6, 0.62), true, true, false)
    if shops:
        var awn: Color = AWNINGS[_rng.randi() % AWNINGS.size()]
        GeoScript.box(sts["plain"], Vector3(pos.x, FLAT_Y + 3.2, pos.z + qz * (d * 0.5 + 0.6)), Vector3(w * 0.6, 0.12, 1.2), Vector2.ONE, 0.0, awn, true, true, true)
    _collider(body, Vector3(pos.x, top * 0.5, pos.z), Vector3(w, top, d))
    building_count += 1
    building_rects.append(Rect2(pos.x - w * 0.5, pos.z - d * 0.5, w, d))


func _build_suburb(sts: Dictionary, body: StaticBody3D, center: Vector3) -> void:
    _sidewalk_ring(sts, center)
    for qx: float in [-1.0, 1.0]:
        for qz: float in [-1.0, 1.0]:
            var w := 12.0 if _rng.randf() < 0.6 else 8.0
            var d := 8.0
            var pos := center + Vector3(qx * 10.0, 0.0, qz * 10.0)
            _add_house(sts, body, pos, w, d)
            var z_a := center.z + qz * 14.0
            var z_b := center.z + qz * 17.0
            GeoScript.flat_quad(sts["concrete"], pos.x - 1.5, minf(z_a, z_b), pos.x + 1.5, maxf(z_a, z_b), FLAT_Y + 0.01, 3.0, Color.WHITE)
            _add_tree(sts, body, Vector3(center.x + qx * _rng.randf_range(3.0, 17.0), FLAT_Y, center.z + qz * _rng.randf_range(1.5, 4.5)), _rng.randf_range(0.8, 1.2))
            _add_tree(sts, body, Vector3(center.x + qx * 17.5, FLAT_Y, center.z + qz * _rng.randf_range(9.0, 15.0)), _rng.randf_range(0.8, 1.1))


func _add_house(sts: Dictionary, body: StaticBody3D, pos: Vector3, w: float, d: float) -> void:
    var wall_h := 6.0
    var rh := 2.6
    var ov := 0.5
    var plaster: Color = PLASTERS[_rng.randi() % PLASTERS.size()]
    var roof_color: Color = ROOFS[_rng.randi() % ROOFS.size()]
    GeoScript.box(sts["house_wall"], Vector3(pos.x, FLAT_Y, pos.z), Vector3(w, wall_h, d), Vector2(8.0, 6.0), FLAT_Y, plaster, true, false, false)
    var x0 := pos.x - w * 0.5 - ov
    var x1 := pos.x + w * 0.5 + ov
    var zf := pos.z + d * 0.5 + ov
    var zb := pos.z - d * 0.5 - ov
    var eave := FLAT_Y + wall_h - 0.15
    var ridge := FLAT_Y + wall_h + rh
    var roof: SurfaceTool = sts["roof_tile"]
    GeoScript.quad(roof, Vector3(x0, eave, zf), Vector3(x1, eave, zf), Vector3(x1, ridge, pos.z), Vector3(x0, ridge, pos.z), Vector3(0, 1, 0.8), roof_color,
        Vector2(x0, zf) / 3.0, Vector2(x1, zf) / 3.0, Vector2(x1, pos.z) / 3.0, Vector2(x0, pos.z) / 3.0)
    GeoScript.quad(roof, Vector3(x1, eave, zb), Vector3(x0, eave, zb), Vector3(x0, ridge, pos.z), Vector3(x1, ridge, pos.z), Vector3(0, 1, -0.8), roof_color,
        Vector2(x1, zb) / 3.0, Vector2(x0, zb) / 3.0, Vector2(x0, pos.z) / 3.0, Vector2(x1, pos.z) / 3.0)
    for sx: float in [-1.0, 1.0]:
        var xr := pos.x + sx * w * 0.5
        GeoScript.tri(sts["plain"], Vector3(xr, FLAT_Y + wall_h, pos.z - d * 0.5), Vector3(xr, FLAT_Y + wall_h, pos.z + d * 0.5), Vector3(xr, ridge, pos.z), Vector3(sx, 0, 0), plaster)
    GeoScript.box(sts["plain"], Vector3(pos.x + w * 0.25, FLAT_Y + wall_h + 0.4, pos.z + 0.6), Vector3(0.9, 2.6, 0.9), Vector2.ONE, 0.0, Color(0.55, 0.3, 0.25), true, true, false)
    _collider(body, Vector3(pos.x, FLAT_Y + (wall_h + rh * 0.7) * 0.5, pos.z), Vector3(w, wall_h + rh * 0.7, d))
    building_count += 1
    building_rects.append(Rect2(pos.x - w * 0.5, pos.z - d * 0.5, w, d))


func _add_tree(sts: Dictionary, body: StaticBody3D, p: Vector3, s: float) -> void:
    var g := _rng.randf()
    var leaf := Color(0.15 + 0.1 * g, 0.4 + 0.2 * g, 0.15)
    var plain: SurfaceTool = sts["plain"]
    GeoScript.box(plain, p, Vector3(0.35 * s, 2.2 * s, 0.35 * s), Vector2.ONE, 0.0, Color(0.35, 0.22, 0.12), true, true, false)
    GeoScript.cone(plain, p + Vector3(0.0, 1.5 * s, 0.0), 1.8 * s, 3.2 * s, 8, leaf)
    GeoScript.cone(plain, p + Vector3(0.0, 3.2 * s, 0.0), 1.3 * s, 2.6 * s, 8, leaf.lightened(0.08))
    _collider(body, p + Vector3(0.0, 1.5 * s, 0.0), Vector3(0.6 * s, 3.0 * s, 0.6 * s))


func _build_park(sts: Dictionary, body: StaticBody3D, center: Vector3) -> void:
    park_count += 1
    park_rects.append(Rect2(center.x - BLOCK_SIZE * 0.5, center.z - BLOCK_SIZE * 0.5, BLOCK_SIZE, BLOCK_SIZE))
    _sidewalk_ring(sts, center)
    GeoScript.flat_quad(sts["grass"], center.x - 17.0, center.z - 17.0, center.x + 17.0, center.z + 17.0, 0.055, 6.0, Color.WHITE)
    GeoScript.flat_quad(sts["concrete"], center.x - 1.5, center.z - 17.0, center.x + 1.5, center.z + 17.0, 0.08, 3.0, Color.WHITE)
    GeoScript.flat_quad(sts["concrete"], center.x - 17.0, center.z - 1.5, center.x + 17.0, center.z + 1.5, 0.08, 3.0, Color.WHITE)
    for n in 9:
        var tx := _rng.randf_range(-15.0, 15.0)
        var tz := _rng.randf_range(-15.0, 15.0)
        if absf(tx) < 3.0 or absf(tz) < 3.0:
            continue
        _add_tree(sts, body, Vector3(center.x + tx, FLAT_Y, center.z + tz), _rng.randf_range(0.9, 1.4))


func _add_lamps(sts: Dictionary, body: StaticBody3D, c: Vector3) -> void:
    var plain: SurfaceTool = sts["plain"]
    for p: Vector2 in [Vector2(0.0, -LAMP_OFFSET), Vector2(0.0, LAMP_OFFSET), Vector2(-LAMP_OFFSET, 0.0), Vector2(LAMP_OFFSET, 0.0)]:
        var base := Vector3(c.x + p.x, FLAT_Y, c.z + p.y)
        var dir := p.normalized()
        GeoScript.box(plain, base, Vector3(0.14, 5.5, 0.14), Vector2.ONE, 0.0, Color(0.2, 0.2, 0.22), true, true, false)
        GeoScript.box(plain, base + Vector3(dir.x * 0.5, 5.4, dir.y * 0.5), Vector3(absf(dir.x) + 0.1, 0.1, absf(dir.y) + 0.1), Vector2.ONE, 0.0, Color(0.2, 0.2, 0.22), true, true, true)
        GeoScript.box(plain, base + Vector3(dir.x * 1.0, 5.3, dir.y * 1.0), Vector3(0.4, 0.1, 0.4), Vector2.ONE, 0.0, Color(1.0, 0.95, 0.8), true, true, true)
        _collider(body, base + Vector3(0.0, 2.75, 0.0), Vector3(0.25, 5.5, 0.25))


# ------------------------------------------------------------- objetos de teste

func _add_test_props() -> void:
    # Rampa na avenida à frente do ponto de partida (o jogador começa olhando para -Z).
    var ramp := _add_box(Vector3(6.0, 0.4, 10.0), Vector3(0.0, 1.45, -22.0), Color(0.7, 0.5, 0.2), true)
    ramp.rotation_degrees.x = 15.0
    # Caixas para testar pulo e colisão.
    _add_box(Vector3(1.0, 1.0, 1.0), Vector3(4.0, 0.5, -8.0), Color(0.6, 0.4, 0.2), true)
    _add_box(Vector3(1.0, 1.0, 1.0), Vector3(-4.0, 0.5, -8.0), Color(0.6, 0.4, 0.2), true)
    _add_box(Vector3(2.0, 2.0, 2.0), Vector3(-4.0, 1.0, -12.0), Color(0.5, 0.35, 0.2), true)
    _add_box(Vector3(0.5, 1.2, 6.0), Vector3(3.0, 0.6, 8.0), Color(0.5, 0.5, 0.55), true)


func _material(color: Color) -> StandardMaterial3D:
    var key := color.to_html()
    if not _materials.has(key):
        var mat := StandardMaterial3D.new()
        mat.albedo_color = color
        mat.roughness = 0.9
        _materials[key] = mat
    return _materials[key]


func _add_box(size: Vector3, pos: Vector3, color: Color, collide: bool) -> Node3D:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.material_override = _material(color)
    if not collide:
        mesh.position = pos
        add_child(mesh)
        return mesh

    var body := StaticBody3D.new()
    body.position = pos
    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    shape.shape = box_shape
    body.add_child(shape)
    body.add_child(mesh)
    add_child(body)
    return body
