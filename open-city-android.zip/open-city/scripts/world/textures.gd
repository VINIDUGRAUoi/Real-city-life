extends RefCounted
## Texturas e materiais gerados em código (sem arquivos de imagem). Os materiais usam a cor
## do vértice como tom (multiplicando a textura), então um material serve para vários prédios.

static var _tex := {}
static var _mats := {}


static func material(mat_name: String) -> StandardMaterial3D:
    if _mats.has(mat_name):
        return _mats[mat_name]
    var m := StandardMaterial3D.new()
    m.vertex_color_use_as_albedo = true
    m.cull_mode = BaseMaterial3D.CULL_DISABLED
    m.roughness = 0.9
    m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    if mat_name != "plain":
        m.albedo_texture = texture(mat_name)
    if mat_name == "facade_glass" or mat_name == "storefront":
        m.roughness = 0.4
        m.metallic = 0.2
    _mats[mat_name] = m
    return m


static func texture(tex_name: String) -> ImageTexture:
    if _tex.has(tex_name):
        return _tex[tex_name]
    var img: Image
    match tex_name:
        "facade_glass":
            img = _facade_glass()
        "facade_brick":
            img = _facade_brick()
        "facade_concrete":
            img = _facade_concrete()
        "storefront":
            img = _storefront()
        "house_wall":
            img = _house_wall()
        "roof_tile":
            img = _roof_tile()
        "roof_gravel":
            img = _noise(64, 64, Color(0.4, 0.4, 0.4), 0.08, 5)
        "asphalt":
            img = _asphalt()
        "grass":
            img = _noise(128, 128, Color(0.27, 0.45, 0.2), 0.07, 7)
        "concrete":
            img = _concrete()
        _:
            img = _noise(32, 32, Color(0.5, 0.5, 0.5), 0.0, 1)
    img.generate_mipmaps()
    var t := ImageTexture.create_from_image(img)
    _tex[tex_name] = t
    return t


static func _img(w: int, h: int, c: Color) -> Image:
    var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
    img.fill(c)
    return img


static func _rect(img: Image, x: int, y: int, w: int, h: int, c: Color) -> void:
    img.fill_rect(Rect2i(x, y, w, h), c)


static func _gradient(img: Image, x: int, y: int, w: int, h: int, top: Color, bottom: Color) -> void:
    for row in h:
        img.fill_rect(Rect2i(x, y + row, w, 1), top.lerp(bottom, float(row) / float(h)))


static func _noise(w: int, h: int, base: Color, amount: float, seed_value: int) -> Image:
    var img := _img(w, h, base)
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    for y in h:
        for x in w:
            var v := rng.randf_range(-amount, amount)
            img.set_pixel(x, y, Color(clampf(base.r + v, 0.0, 1.0), clampf(base.g + v, 0.0, 1.0), clampf(base.b + v, 0.0, 1.0), 1.0))
    return img


# 2x2 células de 128x112 px = 8 m x 7 m (cada janela 4 m x 3,5 m)
static func _facade_glass() -> Image:
    var img := _img(256, 224, Color(0.5, 0.53, 0.56))
    var rng := RandomNumberGenerator.new()
    rng.seed = 11
    for cy in 2:
        for cx in 2:
            var ox := cx * 128
            var oy := cy * 112
            _rect(img, ox, oy + 98, 128, 14, Color(0.38, 0.4, 0.43))
            _rect(img, ox + 9, oy + 5, 110, 94, Color(0.25, 0.27, 0.3))
            if rng.randf() < 0.18:
                _gradient(img, ox + 12, oy + 8, 104, 88, Color(0.95, 0.82, 0.5), Color(0.7, 0.55, 0.3))
            else:
                _gradient(img, ox + 12, oy + 8, 104, 88, Color(0.5, 0.66, 0.8), Color(0.1, 0.18, 0.28))
            _rect(img, ox + 62, oy + 8, 4, 88, Color(0.28, 0.3, 0.33))
    return img


static func _facade_brick() -> Image:
    var img := _img(256, 224, Color(0.72, 0.7, 0.65))
    var rng := RandomNumberGenerator.new()
    rng.seed = 21
    for row in 32:
        var off := 0 if row % 2 == 0 else 8
        for bx in range(-1, 17):
            var c := Color(0.55, 0.25, 0.18).lerp(Color(0.64, 0.34, 0.23), rng.randf())
            _rect(img, bx * 16 + off + 1, row * 7 + 1, 14, 5, c)
    for cy in 2:
        for cx in 2:
            var ox := cx * 128
            var oy := cy * 112
            _rect(img, ox + 20, oy + 14, 88, 80, Color(0.94, 0.94, 0.92))
            _rect(img, ox + 26, oy + 20, 76, 34, Color(0.28, 0.36, 0.46))
            _rect(img, ox + 26, oy + 54, 76, 34, Color(0.1, 0.13, 0.18))
            _rect(img, ox + 62, oy + 20, 4, 68, Color(0.94, 0.94, 0.92))
            _rect(img, ox + 26, oy + 52, 76, 4, Color(0.94, 0.94, 0.92))
            _rect(img, ox + 16, oy + 94, 96, 6, Color(0.6, 0.6, 0.58))
    return img


static func _facade_concrete() -> Image:
    var img := _noise(256, 224, Color(0.62, 0.62, 0.6), 0.03, 31)
    for cy in 2:
        for cx in 2:
            var ox := cx * 128
            var oy := cy * 112
            _rect(img, 0, oy + 109, 256, 3, Color(0.45, 0.45, 0.44))
            _rect(img, ox + 125, 0, 3, 224, Color(0.5, 0.5, 0.49))
            _rect(img, ox + 6, oy + 30, 116, 44, Color(0.22, 0.22, 0.25))
            _gradient(img, ox + 9, oy + 33, 110, 38, Color(0.55, 0.68, 0.78), Color(0.15, 0.22, 0.3))
            for k in 4:
                _rect(img, ox + 9 + k * 27, oy + 33, 3, 38, Color(0.22, 0.22, 0.25))
    return img


# 8 m x 4 m
static func _storefront() -> Image:
    var img := _img(256, 128, Color(0.22, 0.22, 0.25))
    for k in 16:
        _rect(img, k * 16, 0, 16, 22, Color(0.8, 0.2, 0.2) if k % 2 == 0 else Color(0.95, 0.95, 0.95))
    _rect(img, 0, 22, 256, 4, Color(0.12, 0.12, 0.14))
    for k in 4:
        _gradient(img, 8 + k * 60, 30, 56, 84, Color(0.45, 0.58, 0.7), Color(0.12, 0.18, 0.25))
    _rect(img, 128, 30, 56, 98, Color(0.3, 0.2, 0.14))
    _gradient(img, 136, 38, 40, 56, Color(0.5, 0.62, 0.72), Color(0.15, 0.2, 0.28))
    _rect(img, 170, 84, 4, 14, Color(0.85, 0.75, 0.3))
    _rect(img, 0, 118, 256, 10, Color(0.4, 0.4, 0.42))
    return img


static func _house_window(img: Image, x: int, y: int) -> void:
    _rect(img, x + 10, y + 14, 12, 60, Color(0.2, 0.42, 0.3))
    _rect(img, x + 106, y + 14, 12, 60, Color(0.2, 0.42, 0.3))
    _rect(img, x + 25, y + 9, 78, 70, Color(0.98, 0.98, 0.96))
    _gradient(img, x + 30, y + 14, 68, 60, Color(0.5, 0.65, 0.78), Color(0.15, 0.22, 0.3))
    _rect(img, x + 62, y + 14, 4, 60, Color(0.98, 0.98, 0.96))
    _rect(img, x + 30, y + 42, 68, 4, Color(0.98, 0.98, 0.96))
    _rect(img, x + 22, y + 79, 84, 5, Color(0.7, 0.68, 0.64))


# 8 m x 6 m (linha de baixo = térreo, com porta à direita)
static func _house_wall() -> Image:
    var img := _img(256, 192, Color(0.96, 0.94, 0.9))
    _house_window(img, 0, 0)
    _house_window(img, 128, 0)
    _house_window(img, 0, 96)
    _rect(img, 128 + 34, 96 + 6, 60, 90, Color(0.35, 0.22, 0.14))
    _rect(img, 128 + 40, 96 + 12, 48, 38, Color(0.28, 0.17, 0.1))
    _rect(img, 128 + 40, 96 + 56, 48, 34, Color(0.28, 0.17, 0.1))
    _rect(img, 128 + 82, 96 + 52, 5, 5, Color(0.9, 0.8, 0.3))
    _rect(img, 128 + 30, 96 + 90, 68, 6, Color(0.6, 0.6, 0.6))
    _rect(img, 0, 186, 256, 6, Color(0.55, 0.5, 0.45))
    return img


static func _roof_tile() -> Image:
    var img := _img(64, 64, Color(0.92, 0.92, 0.92))
    for r in 8:
        _rect(img, 0, r * 8, 64, 2, Color(0.6, 0.6, 0.6))
        var off := 0 if r % 2 == 0 else 8
        for k in 4:
            _rect(img, k * 16 + off, r * 8, 2, 8, Color(0.72, 0.72, 0.72))
    return img


static func _asphalt() -> Image:
    var img := _noise(128, 128, Color(0.17, 0.17, 0.19), 0.04, 41)
    var rng := RandomNumberGenerator.new()
    rng.seed = 42
    for n in 160:
        img.set_pixel(rng.randi() % 128, rng.randi() % 128, Color(0.38, 0.38, 0.4))
    return img


static func _concrete() -> Image:
    var img := _noise(64, 64, Color(0.62, 0.62, 0.6), 0.03, 51)
    _rect(img, 0, 0, 64, 1, Color(0.45, 0.45, 0.44))
    _rect(img, 0, 0, 1, 64, Color(0.45, 0.45, 0.44))
    _rect(img, 0, 32, 64, 1, Color(0.5, 0.5, 0.49))
    _rect(img, 32, 0, 1, 64, Color(0.5, 0.5, 0.49))
    return img
