extends Node
## Autoload "GameState": estado compartilhado (destino do GPS, pausa, dinheiro, armas e carros comprados).

const GraphScript := preload("res://scripts/ai/city_graph.gd")
const WeaponsScript := preload("res://scripts/combat/weapons.gd")
const ShopScript := preload("res://scripts/core/shop.gd")
const BusinessScript := preload("res://scripts/jobs/business.gd")

const START_MONEY := 25000

signal waypoint_changed
signal money_changed
signal weapon_changed(id: String)
signal inventory_changed

var has_waypoint := false
var waypoint := Vector2.ZERO # x, z no mundo
var route := PackedVector2Array()

var money := START_MONEY
var owned_weapons: Array = ["fists"]
var weapon_id := "fists"
var owned_cars := {} # id do carro -> cor (texto HTML)
var business := {} # negócio do comerciante (veja scripts/jobs/business.gd)
var job_totals := {} # trabalho -> total ganho


func set_waypoint(position_xz: Vector2) -> void:
    has_waypoint = true
    waypoint = position_xz
    route = PackedVector2Array()
    waypoint_changed.emit()


func clear_waypoint() -> void:
    has_waypoint = false
    route = PackedVector2Array()
    waypoint_changed.emit()


func update_route(from_xz: Vector2) -> void:
    if has_waypoint:
        route = GraphScript.route(from_xz, waypoint)


func set_paused(value: bool) -> void:
    get_tree().paused = value
    if not OS.has_feature("mobile"):
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if value else Input.MOUSE_MODE_CAPTURED


# ------------------------------------------------------------------ dinheiro

func add_money(amount: int) -> void:
    if amount <= 0:
        return
    money += amount
    money_changed.emit()


func spend(amount: int) -> bool:
    if amount < 0 or amount > money:
        return false
    money -= amount
    money_changed.emit()
    return true


# -------------------------------------------------------------------- armas

func has_weapon(id: String) -> bool:
    return owned_weapons.has(id)


func buy_weapon(id: String) -> bool:
    if not WeaponsScript.exists(id) or has_weapon(id):
        return false
    if not spend(WeaponsScript.price(id)):
        return false
    owned_weapons.append(id)
    inventory_changed.emit()
    return true


func equip_weapon(id: String) -> bool:
    if not has_weapon(id):
        return false
    weapon_id = id
    weapon_changed.emit(id)
    return true


## Troca para a próxima arma que você tem (botão "Arma" / tecla Q).
func cycle_weapon() -> void:
    var list: Array = []
    for id: String in WeaponsScript.ORDER:
        if has_weapon(id):
            list.append(id)
    if list.is_empty():
        return
    var next := (list.find(weapon_id) + 1) % list.size()
    equip_weapon(list[next])


# -------------------------------------------------------------------- carros

func has_car(id: String) -> bool:
    return owned_cars.has(id)


func buy_car(id: String, color_html: String) -> bool:
    if has_car(id) or ShopScript.car_price(id) <= 0:
        return false
    if not spend(ShopScript.car_price(id)):
        return false
    owned_cars[id] = color_html
    inventory_changed.emit()
    return true


# ------------------------------------------------------------------ trabalhos e negócio

func add_job_earning(kind: String, amount: int) -> void:
    job_totals[kind] = int(job_totals.get(kind, 0)) + amount


func open_business(type: String) -> bool:
    if BusinessScript.exists(business) or not BusinessScript.TYPES.has(type):
        return false
    if not spend(int(BusinessScript.TYPES[type]["price"])):
        return false
    business = BusinessScript.create(type, Time.get_unix_time_from_system())
    inventory_changed.emit()
    return true


## Atualiza as vendas até agora (use antes de mostrar ou mexer no negócio).
func tick_business() -> int:
    if not BusinessScript.exists(business):
        return 0
    return BusinessScript.simulate(business, Time.get_unix_time_from_system())


func buy_stock(units: int) -> bool:
    if not BusinessScript.exists(business):
        return false
    units = mini(units, BusinessScript.free_space(business))
    if units <= 0 or not spend(BusinessScript.stock_cost(business, units)):
        return false
    business["stock"] = int(business["stock"]) + units
    return true


func collect_business_cash() -> int:
    if not BusinessScript.exists(business):
        return 0
    var cash := int(business.get("cash", 0))
    business["cash"] = 0
    add_money(cash)
    return cash


func upgrade_business() -> bool:
    if not BusinessScript.exists(business) or BusinessScript.level(business) >= BusinessScript.MAX_LEVEL:
        return false
    if not spend(BusinessScript.upgrade_cost(business)):
        return false
    business["level"] = BusinessScript.level(business) + 1
    return true


# ------------------------------------------------------------------ salvamento

func to_dict() -> Dictionary:
    return {"money": money, "weapons": owned_weapons, "weapon": weapon_id, "cars": owned_cars, "business": business, "job_totals": job_totals}


func from_dict(data: Dictionary) -> void:
    money = int(data.get("money", START_MONEY))
    owned_weapons = ["fists"]
    var weapons: Variant = data.get("weapons")
    if weapons is Array:
        for id: Variant in weapons:
            if WeaponsScript.exists(str(id)) and not owned_weapons.has(str(id)):
                owned_weapons.append(str(id))
    owned_cars = {}
    var cars: Variant = data.get("cars")
    if cars is Dictionary:
        for id: Variant in cars:
            if ShopScript.car_price(str(id)) > 0:
                owned_cars[str(id)] = str(cars[id])
    business = {}
    var biz: Variant = data.get("business")
    if biz is Dictionary and BusinessScript.exists(biz):
        business = biz
    job_totals = {}
    var totals: Variant = data.get("job_totals")
    if totals is Dictionary:
        for k: Variant in totals:
            job_totals[str(k)] = int(totals[k])
    var w := str(data.get("weapon", "fists"))
    weapon_id = w if has_weapon(w) else "fists"
    money_changed.emit()
    inventory_changed.emit()
    weapon_changed.emit(weapon_id)
