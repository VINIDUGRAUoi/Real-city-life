extends RefCounted
## Loja de carros: quais veículos podem ser comprados e quanto custam. O preço sai da
## potência e da velocidade máxima de cada modelo (vehicle_data.gd), arredondado a 500.

const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")

## Veículos de serviço não são vendidos.
const NOT_FOR_SALE := ["police", "ambulance"]


static func car_price(id: String) -> int:
    if not DataScript.TYPES.has(id):
        return 0
    var d: Dictionary = DataScript.TYPES[id]
    var raw := float(d["power"]) / 1000.0 * float(d["max_speed"]) * 150.0
    return maxi(int(roundf(raw / 500.0)) * 500, 3000)


static func car_name(id: String) -> String:
    return str(DataScript.TYPES[id]["name"]) if DataScript.TYPES.has(id) else id


## Ids à venda, do mais barato ao mais caro.
static func car_ids() -> Array:
    var ids: Array = []
    for id: String in DataScript.IDS:
        if DataScript.TYPES.has(id) and not NOT_FOR_SALE.has(id):
            ids.append(id)
    ids.sort_custom(func(a: String, b: String) -> bool:
        var pa := car_price(a)
        var pb := car_price(b)
        if pa == pb:
            return car_name(a) < car_name(b)
        return pa < pb)
    return ids


## 25000 -> "R$ 25.000"
static func fmt_money(amount: int) -> String:
    var s := str(absi(amount))
    var out := ""
    var count := 0
    for i in range(s.length() - 1, -1, -1):
        out = s[i] + out
        count += 1
        if count % 3 == 0 and i > 0:
            out = "." + out
    return ("-" if amount < 0 else "") + "R$ " + out
