extends RefCounted
## Pasta de skins do jogo instalado (a pasta "data" do app). Dá para trocar o visual dos carros e do
## jogador SEM gerar o APK de novo: é só colocar arquivos nesta pasta e tocar em "Recarregar skins"
## no celular do jogo (aplicativo Skins).
##
##   <pasta de dados>/skins/carros/<id do carro>/model.glb | model_far.glb | skin.png
##   <pasta de dados>/skins/jogador/outfit.json | skin.png | model.glb
##
## O caminho real aparece no aplicativo Skins do celular do jogo.

const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")

const README := """REAL CITY LIFE - SKINS

CARROS
Em carros/ há uma pasta para cada carro (o nome da pasta é o id do carro). Coloque dentro:
  model.glb      modelo 3D que troca a carroceria (o jogo ajusta o tamanho sozinho)
  model_far.glb  versão leve opcional, usada quando o carro está longe
  skin.png       imagem de pintura (também .jpg ou .webp), repete a cada 4 metros
Rodas que giram: o modelo precisa ter 4 peças chamadas wheel_fl, wheel_fr, wheel_rl, wheel_rr.

JOGADOR
Em jogador/ coloque o que quiser (todos opcionais):
  outfit.json    cores e roupa. Veja outfit.exemplo.json (renomeie para outfit.json)
  skin.png       imagem aplicada sobre o corpo (padrão), também .jpg ou .webp
  model.glb      modelo 3D que substitui o personagem (altura ajustada para 1,78 m).
                 Se tiver animações com "idle", "walk" e "run" no nome, elas tocam sozinhas.

Depois abra o celular do jogo (botão Cel ou tecla P), toque em Skins e em "Recarregar skins".
Use só modelos e imagens que sejam seus ou de licença livre.
"""

const SAMPLE_OUTFIT := """{
  "skin": "#d9a678",
  "shirt": "#1e90ff",
  "pants": "#222233",
  "hair": "#1a120c",
  "shoe": "#ffffff",
  "hat": "#cc2222",
  "long_hair": false,
  "short_sleeves": true,
  "shorts": false,
  "backpack": false,
  "scale": 1.0
}
"""


static func root_dir() -> String:
    return OS.get_user_data_dir().path_join("skins")


static func cars_dir() -> String:
    return root_dir().path_join("carros")


static func player_dir() -> String:
    return root_dir().path_join("jogador")


## Cria as pastas (uma por carro) e os arquivos de ajuda, se ainda não existirem.
static func setup() -> void:
    DirAccess.make_dir_recursive_absolute(player_dir())
    for id: String in DataScript.IDS:
        DirAccess.make_dir_recursive_absolute(cars_dir().path_join(id))
    _write_if_missing(root_dir().path_join("LEIA-ME.txt"), README)
    _write_if_missing(player_dir().path_join("outfit.exemplo.json"), SAMPLE_OUTFIT)


static func _write_if_missing(path: String, text: String) -> void:
    if FileAccess.file_exists(path):
        return
    var f := FileAccess.open(path, FileAccess.WRITE)
    if f != null:
        f.store_string(text)
        f.close()


## Texto para o aplicativo Skins: quais arquivos de skin o jogo encontrou.
static func report() -> String:
    var lines: Array[String] = []
    var cars: Array[String] = []
    for id: String in DataScript.IDS:
        var found: Array[String] = []
        for n: String in ["model.glb", "model.gltf", "model_far.glb", "skin.png", "skin.jpg", "skin.jpeg", "skin.webp"]:
            if FileAccess.file_exists(cars_dir().path_join(id).path_join(n)):
                found.append(n)
        if not found.is_empty():
            cars.append("%s (%s)" % [id, ", ".join(found)])
    lines.append("Carros com skin: " + (", ".join(cars) if not cars.is_empty() else "nenhum"))
    var mine: Array[String] = []
    for n: String in ["outfit.json", "skin.png", "skin.jpg", "skin.jpeg", "skin.webp", "model.glb", "model.gltf"]:
        if FileAccess.file_exists(player_dir().path_join(n)):
            mine.append(n)
    lines.append("Jogador: " + (", ".join(mine) if not mine.is_empty() else "nenhum arquivo"))
    return "\n".join(lines)
