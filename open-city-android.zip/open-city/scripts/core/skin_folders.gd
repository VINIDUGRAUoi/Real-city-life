extends RefCounted
## Pasta de skins do jogo instalado. Dá para trocar o visual dos carros e do jogador SEM gerar o APK de
## novo: é só colocar arquivos nela e tocar em "Recarregar skins" no celular do jogo (aplicativo Skins).
##
##   <pasta de skins>/carros/<id do carro>/model.glb | model_far.glb | skin.png
##   <pasta de skins>/jogador/outfit.json | skin.png | model.glb
##
## No Android o jogo tenta, nesta ordem: /storage/emulated/0/RealCityLife/skins (pública, precisa da permissão
## "acesso a todos os arquivos"), a pasta do app em Android/data e a pasta interna do app. Os caminhos
## aparecem no aplicativo Skins do celular do jogo.

const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")

const README := """REAL CITY LIFE - SKINS

CARROS
Em carros/ há uma pasta para cada carro (o nome da pasta é o id do carro). Coloque dentro:
  model.glb      modelo 3D que troca a carroceria (o jogo ajusta o tamanho sozinho)
  model_far.glb  versão leve opcional, usada quando o carro está longe
  skin.png       imagem de pintura (também .jpg ou .webp), repete a cada 4 metros
Rodas que giram: o modelo precisa ter 4 peças chamadas wheel_fl, wheel_fr, wheel_rl, wheel_rr.

JOGADOR
Em jogador/ coloque o que quiser (todos opcionais):
  outfit.json    cores e roupa. Veja outfit.exemplo.json (renomeie para outfit.json)
  skin.png       imagem aplicada sobre o corpo (padrão), também .jpg ou .webp
  model.glb      modelo 3D que substitui o personagem (altura ajustada para 1,78 m).
                 Se tiver animações com "idle", "walk" e "run" no nome, elas tocam sozinhas.

Depois abra o celular do jogo (botão Cel ou tecla P), toque em Skins e em "Recarregar skins".
Use só modelos e imagens que sejam seus ou de licença livre.
"""

const SAMPLE_OUTFIT := """{
  "skin": "#d9a678",
  "shirt": "#1e90ff",
  "pants": "#222233",
  "hair": "#1a120c",
  "shoe": "#ffffff",
  "hat": "#cc2222",
  "long_hair": false,
  "short_sleeves": true,
  "shorts": false,
  "backpack": false,
  "scale": 1.0
}
"""


## Nome do pacote do app (igual a package/unique_name em export_presets.cfg).
const PACKAGE := "com.opencity.game"
## Pasta pública no celular: aparece no armazenamento interno com qualquer gerenciador de arquivos.
## Só pode ser criada/lida depois de permitir "acesso a todos os arquivos" (aplicativo Skins).
const PUBLIC_ANDROID := "/storage/emulated/0/RealCityLife/skins"


## Todas as pastas de skins possíveis, da mais fácil de abrir para a menos. O jogo procura
## arquivos em todas as que existirem (a primeira da lista vence).
static func roots() -> Array[String]:
    var out: Array[String] = []
    if OS.get_name() == "Android":
        out.append(PUBLIC_ANDROID)
        out.append("/storage/emulated/0/Android/data/%s/files/skins" % PACKAGE)
    out.append(OS.get_user_data_dir().path_join("skins"))
    return out


## Pastas que existem de verdade neste momento.
static func usable_roots() -> Array[String]:
    var out: Array[String] = []
    for r in roots():
        if DirAccess.dir_exists_absolute(r):
            out.append(r)
    return out


## Procura um arquivo de skin do jogador em todas as pastas. Retorna "" se não achar.
static func find_player_file(file_name: String) -> String:
    for r in usable_roots():
        var p := r.path_join("jogador").path_join(file_name)
        if FileAccess.file_exists(p):
            return p
    return ""


## Procura um arquivo de skin de carro em todas as pastas. Retorna "" se não achar.
static func find_car_file(id: String, file_name: String) -> String:
    for r in usable_roots():
        var p := r.path_join("carros").path_join(id).path_join(file_name)
        if FileAccess.file_exists(p):
            return p
    return ""


const IMAGE_EXT := ["png", "jpg", "jpeg", "webp"]
const MODEL_EXT := ["glb", "gltf"]
const MAX_IMAGE_SIZE := 2048


## Escolhe um arquivo dentro de uma pasta. O NOME NÃO PRECISA SER EXATO: vale qualquer arquivo com a
## extensão certa (ex.: "skin (1).png", "pintura.JPG", "meu_carro.glb").
## kind: "skin" (imagem), "model" (.glb/.gltf), "far" (.glb/.gltf com "far" no nome) ou "outfit" (.json).
## Se houver vários, prefere o que começa com "skin", "model" ou "outfit".
static func pick_file(dir: String, kind: String) -> String:
    if not DirAccess.dir_exists_absolute(dir):
        return ""
    var names: Array = Array(DirAccess.get_files_at(dir))
    names.sort()
    var best := ""
    var best_score := 0
    for f: String in names:
        var lower := f.to_lower()
        var ext := lower.get_extension()
        var score := 0
        match kind:
            "skin":
                if IMAGE_EXT.has(ext):
                    score = 2 if lower.begins_with("skin") else 1
            "model":
                if MODEL_EXT.has(ext) and not lower.contains("far"):
                    score = 2 if lower.begins_with("model") else 1
            "far":
                if MODEL_EXT.has(ext) and lower.contains("far"):
                    score = 1
            "outfit":
                if ext == "json" and not lower.contains("exemplo") and not lower.contains("example"):
                    score = 2 if lower.begins_with("outfit") else 1
        if score > best_score:
            best_score = score
            best = dir.path_join(f)
    return best


static func car_file(id: String, kind: String) -> String:
    for r in usable_roots():
        var p := pick_file(r.path_join("carros").path_join(id), kind)
        if p != "":
            return p
    return ""


static func player_file(kind: String) -> String:
    for r in usable_roots():
        var p := pick_file(r.path_join("jogador"), kind)
        if p != "":
            return p
    return ""


## Lê uma imagem pelo CONTEÚDO (png, jpg ou webp), mesmo que a extensão esteja errada
## (muito comum em downloads no celular). Reduz imagens enormes. Retorna null se não conseguir.
static func load_image(path: String) -> Image:
    var bytes := FileAccess.get_file_as_bytes(path)
    if bytes.size() < 12:
        return null
    var img := Image.new()
    var err := ERR_FILE_UNRECOGNIZED
    if bytes[0] == 0x89 and bytes[1] == 0x50:
        err = img.load_png_from_buffer(bytes)
    elif bytes[0] == 0xFF and bytes[1] == 0xD8:
        err = img.load_jpg_from_buffer(bytes)
    elif bytes[0] == 0x52 and bytes[1] == 0x49:
        err = img.load_webp_from_buffer(bytes)
    else:
        err = img.load_png_from_buffer(bytes)
        if err != OK:
            err = img.load_jpg_from_buffer(bytes)
        if err != OK:
            err = img.load_webp_from_buffer(bytes)
    if err != OK or img.is_empty():
        push_warning("Skin: não consegui abrir a imagem %s" % path)
        return null
    var biggest := maxi(img.get_width(), img.get_height())
    if biggest > MAX_IMAGE_SIZE:
        var k := float(MAX_IMAGE_SIZE) / float(biggest)
        img.resize(maxi(1, int(img.get_width() * k)), maxi(1, int(img.get_height() * k)), Image.INTERPOLATE_BILINEAR)
    return img


## Primeira pasta que existe (a que o jogo mostra e usa para criar arquivos de ajuda), ou "".
static func main_root() -> String:
    var list := usable_roots()
    return list[0] if not list.is_empty() else ""


## Cria as pastas (uma por carro) e os arquivos de ajuda em todas as pastas que o sistema deixar.
static func setup() -> void:
    for r in roots():
        DirAccess.make_dir_recursive_absolute(r.path_join("jogador"))
        if not DirAccess.dir_exists_absolute(r):
            continue # sem permissão ou sem espaço: tenta a próxima
        for id: String in DataScript.IDS:
            DirAccess.make_dir_recursive_absolute(r.path_join("carros").path_join(id))
        _write_if_missing(r.path_join("LEIA-ME.txt"), README)
        _write_if_missing(r.path_join("jogador").path_join("outfit.exemplo.json"), SAMPLE_OUTFIT)


static func _write_if_missing(path: String, text: String) -> void:
    if FileAccess.file_exists(path):
        return
    var f := FileAccess.open(path, FileAccess.WRITE)
    if f != null:
        f.store_string(text)
        f.close()


## Texto para o aplicativo Skins: onde ficam as pastas e quais arquivos de skin o jogo encontrou.
static func report() -> String:
    var lines: Array[String] = []
    for r in roots():
        lines.append("%s  [%s]" % [r, "existe" if DirAccess.dir_exists_absolute(r) else "não foi possível criar"])
    var cars: Array[String] = []
    for id: String in DataScript.IDS:
        var found: Array[String] = []
        for kind: String in ["model", "far", "skin"]:
            var f := car_file(id, kind)
            if f != "":
                found.append(f.get_file())
        if not found.is_empty():
            cars.append("%s (%s)" % [id, ", ".join(found)])
    lines.append("")
    lines.append("Carros com skin: " + (", ".join(cars) if not cars.is_empty() else "nenhum"))
    var mine: Array[String] = []
    for kind: String in ["outfit", "skin", "model"]:
        var f := player_file(kind)
        if f != "":
            mine.append(f.get_file())
    lines.append("Jogador: " + (", ".join(mine) if not mine.is_empty() else "nenhum arquivo"))
    return "\n".join(lines)
