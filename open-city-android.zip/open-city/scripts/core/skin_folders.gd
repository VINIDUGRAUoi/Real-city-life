extends RefCounted
## Pasta de skins do jogo instalado. Dá para trocar o visual dos carros e do jogador SEM gerar o APK de
## novo: é só colocar arquivos nela e tocar em "Recarregar skins" no celular do jogo (aplicativo Skins).
##
##   <pasta de skins>/carros/<id do carro>/model.glb | model_far.glb | skin.png
##   <pasta de skins>/jogador/outfit.json | skin.png | model.glb
##
## No Android o jogo tenta, nesta ordem: /storage/emulated/0/RealCityLife/skins (pública, precisa da permissão
## "acesso a todos os arquivos"), a pasta do app em Android/data e a pasta interna do app. Os caminhos
## aparecem no aplicativo Skins do celular do jogo.

const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")

const README := """REAL CITY LIFE - SKINS

CARROS
Em carros/ há uma pasta para cada carro (o nome da pasta é o id do carro). Coloque dentro:
  model.glb      modelo 3D que troca a carroceria (o jogo ajusta o tamanho sozinho)
  model_far.glb  versão leve opcional, usada quando o carro está longe
  skin.png       imagem de pintura (também .jpg ou .webp), repete a cada 4 metros
Rodas que giram: o modelo precisa ter 4 peças chamadas wheel_fl, wheel_fr, wheel_rl, wheel_rr.

JOGADOR
Em jogador/ coloque o que quiser (todos opcionais):
  outfit.json    cores e roupa. Veja outfit.exemplo.json (renomeie para outfit.json)
  skin.png       imagem aplicada sobre o corpo (padrão), também .jpg ou .webp
  model.glb      modelo 3D que substitui o personagem (altura ajustada para 1,78 m).
                 Se tiver animações com "idle", "walk" e "run" no nome, elas tocam sozinhas.

Depois abra o celular do jogo (botão Cel ou tecla P), toque em Skins e em "Recarregar skins".
Use só modelos e imagens que sejam seus ou de licença livre.
"""

const SAMPLE_OUTFIT := """{
  "skin": "#d9a678",
  "shirt": "#1e90ff",
  "pants": "#222233",
  "hair": "#1a120c",
  "shoe": "#ffffff",
  "hat": "#cc2222",
  "long_hair": false,
  "short_sleeves": true,
  "shorts": false,
  "backpack": false,
  "scale": 1.0
}
"""


## Nome do pacote do app (igual a package/unique_name em export_presets.cfg).
const PACKAGE := "com.opencity.game"
## Pasta pública no celular: aparece no armazenamento interno com qualquer gerenciador de arquivos.
## Só pode ser criada/lida depois de permitir "acesso a todos os arquivos" (aplicativo Skins).
const PUBLIC_ANDROID := "/storage/emulated/0/RealCityLife/skins"


## Todas as pastas de skins possíveis, da mais fácil de abrir para a menos. O jogo procura
## arquivos em todas as que existirem (a primeira da lista vence).
static func roots() -> Array[String]:
    var out: Array[String] = []
    if OS.get_name() == "Android":
        out.append(PUBLIC_ANDROID)
        out.append("/storage/emulated/0/Android/data/%s/files/skins" % PACKAGE)
    out.append(OS.get_user_data_dir().path_join("skins"))
    return out


## Pastas que existem de verdade neste momento.
static func usable_roots() -> Array[String]:
    var out: Array[String] = []
    for r in roots():
        if DirAccess.dir_exists_absolute(r):
            out.append(r)
    return out


## Procura um arquivo de skin do jogador em todas as pastas. Retorna "" se não achar.
static func find_player_file(file_name: String) -> String:
    for r in usable_roots():
        var p := r.path_join("jogador").path_join(file_name)
        if FileAccess.file_exists(p):
            return p
    return ""


## Procura um arquivo de skin de carro em todas as pastas. Retorna "" se não achar.
static func find_car_file(id: String, file_name: String) -> String:
    for r in usable_roots():
        var p := r.path_join("carros").path_join(id).path_join(file_name)
        if FileAccess.file_exists(p):
            return p
    return ""


## Primeira pasta que existe (a que o jogo mostra e usa para criar arquivos de ajuda), ou "".
static func main_root() -> String:
    var list := usable_roots()
    return list[0] if not list.is_empty() else ""


## Cria as pastas (uma por carro) e os arquivos de ajuda em todas as pastas que o sistema deixar.
static func setup() -> void:
    for r in roots():
        DirAccess.make_dir_recursive_absolute(r.path_join("jogador"))
        if not DirAccess.dir_exists_absolute(r):
            continue # sem permissão ou sem espaço: tenta a próxima
        for id: String in DataScript.IDS:
            DirAccess.make_dir_recursive_absolute(r.path_join("carros").path_join(id))
        _write_if_missing(r.path_join("LEIA-ME.txt"), README)
        _write_if_missing(r.path_join("jogador").path_join("outfit.exemplo.json"), SAMPLE_OUTFIT)


static func _write_if_missing(path: String, text: String) -> void:
    if FileAccess.file_exists(path):
        return
    var f := FileAccess.open(path, FileAccess.WRITE)
    if f != null:
        f.store_string(text)
        f.close()


## Texto para o aplicativo Skins: onde ficam as pastas e quais arquivos de skin o jogo encontrou.
static func report() -> String:
    var lines: Array[String] = []
    for r in roots():
        lines.append("%s  [%s]" % [r, "existe" if DirAccess.dir_exists_absolute(r) else "não foi possível criar"])
    var cars: Array[String] = []
    for id: String in DataScript.IDS:
        var found: Array[String] = []
        for n: String in ["model.glb", "model.gltf", "model_far.glb", "skin.png", "skin.jpg", "skin.jpeg", "skin.webp"]:
            if find_car_file(id, n) != "":
                found.append(n)
        if not found.is_empty():
            cars.append("%s (%s)" % [id, ", ".join(found)])
    lines.append("")
    lines.append("Carros com skin: " + (", ".join(cars) if not cars.is_empty() else "nenhum"))
    var mine: Array[String] = []
    for n: String in ["outfit.json", "skin.png", "skin.jpg", "skin.jpeg", "skin.webp", "model.glb", "model.gltf"]:
        if find_player_file(n) != "":
            mine.append(n)
    lines.append("Jogador: " + (", ".join(mine) if not mine.is_empty() else "nenhum arquivo"))
    return "\n".join(lines)
