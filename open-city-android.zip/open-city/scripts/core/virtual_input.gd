extends RefCounted
## Comandos de direção vindos dos botões da tela, lidos direto pelo veículo.
## Eles NÃO passam pelo InputMap: alguns celulares mandam sinais de "joystick" vazios o tempo todo
## (os comandos de dirigir também estão ligados a eixos de controle), e cada sinal desses
## zerava o acelerador e a direção mesmo com o dedo na tela. Teclado e controle continuam
## funcionando, porque o veículo usa o maior valor entre as duas fontes.

static var accel := 0.0
static var reverse := 0.0
static var steer_left := 0.0
static var steer_right := 0.0
static var handbrake := false
static var horn := false


static func clear() -> void:
    accel = 0.0
    reverse = 0.0
    steer_left = 0.0
    steer_right = 0.0
    handbrake = false
    horn = false
