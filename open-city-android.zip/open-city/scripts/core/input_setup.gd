extends Node
## Autoload "InputSetup". Registra as ações de entrada em código para que todos
## os controles fiquem num só lugar e possam ser trocados por um menu de
## configurações (Etapa 8) sem editar o project.godot.

const KEY_BINDINGS := {
    "move_forward": [KEY_W, KEY_UP],
    "move_back": [KEY_S, KEY_DOWN],
    "move_left": [KEY_A, KEY_LEFT],
    "move_right": [KEY_D, KEY_RIGHT],
    "jump": [KEY_SPACE],
    "sprint": [KEY_SHIFT],
    "crouch": [KEY_C, KEY_CTRL],
    "interact": [KEY_E],
    "pause": [KEY_ESCAPE],
    "map": [KEY_M],
    "horn": [KEY_H],
    "debug_damage": [KEY_K],
    "attack": [KEY_F],
    "phone": [KEY_P],
    "weapon_next": [KEY_Q],
}

const PAD_BUTTONS := {
    "jump": [JOY_BUTTON_A],
    "sprint": [JOY_BUTTON_LEFT_STICK],
    "crouch": [JOY_BUTTON_B],
    "interact": [JOY_BUTTON_X],
    "pause": [JOY_BUTTON_START],
    "map": [JOY_BUTTON_BACK],
    "horn": [JOY_BUTTON_Y],
    "attack": [JOY_BUTTON_RIGHT_SHOULDER],
    "phone": [JOY_BUTTON_DPAD_UP],
    "weapon_next": [JOY_BUTTON_LEFT_SHOULDER],
}

# Cada entrada: [eixo, sinal]
const PAD_AXES := {
    "move_left": [[JOY_AXIS_LEFT_X, -1.0]],
    "move_right": [[JOY_AXIS_LEFT_X, 1.0]],
    "move_forward": [[JOY_AXIS_LEFT_Y, -1.0]],
    "move_back": [[JOY_AXIS_LEFT_Y, 1.0]],
    "look_left": [[JOY_AXIS_RIGHT_X, -1.0]],
    "look_right": [[JOY_AXIS_RIGHT_X, 1.0]],
    "look_up": [[JOY_AXIS_RIGHT_Y, -1.0]],
    "look_down": [[JOY_AXIS_RIGHT_Y, 1.0]],
}


func _ready() -> void:
    register()


## Idempotente: pode ser chamada várias vezes sem duplicar eventos.
static func register() -> void:
    for action: String in KEY_BINDINGS:
        _ensure_action(action)
        for keycode: int in KEY_BINDINGS[action]:
            var ev := InputEventKey.new()
            ev.physical_keycode = keycode as Key
            _add_event(action, ev)

    for action: String in PAD_BUTTONS:
        _ensure_action(action)
        for button: int in PAD_BUTTONS[action]:
            var ev := InputEventJoypadButton.new()
            ev.button_index = button as JoyButton
            _add_event(action, ev)

    # Clique esquerdo do mouse também ataca. No celular o toque gera "mouse", então fica de fora.
    if not OS.has_feature("mobile"):
        var click := InputEventMouseButton.new()
        click.button_index = MOUSE_BUTTON_LEFT
        _add_event("attack", click)

    for action: String in PAD_AXES:
        _ensure_action(action)
        for pair: Array in PAD_AXES[action]:
            var ev := InputEventJoypadMotion.new()
            ev.axis = pair[0] as JoyAxis
            ev.axis_value = pair[1]
            _add_event(action, ev)


static func _ensure_action(action: String) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action, 0.2)


static func _add_event(action: String, ev: InputEvent) -> void:
    if not InputMap.action_has_event(action, ev):
        InputMap.action_add_event(action, ev)
