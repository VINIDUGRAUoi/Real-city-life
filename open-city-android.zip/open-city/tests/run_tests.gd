extends SceneTree
## Testes headless simples (sem dependências externas).
## Execute:  godot --headless --path . -s tests/run_tests.gd
## Código de saída 0 = tudo certo, 1 = alguma falha.

const InputScript := preload("res://scripts/core/input_setup.gd")
const PlayerScript := preload("res://scripts/player/player.gd")
const WorldScript := preload("res://scripts/world/world_builder.gd")
const GraphScript := preload("res://scripts/ai/city_graph.gd")
const DataScript := preload("res://scripts/vehicles/vehicle_data.gd")
const FactoryScript := preload("res://scripts/vehicles/vehicle_factory.gd")
const PedScript := preload("res://scripts/ai/pedestrian.gd")
const TrafficScript := preload("res://scripts/ai/traffic_car.gd")
const HumanoidScript := preload("res://scripts/ai/humanoid.gd")
const BuilderScript := preload("res://scripts/vehicles/vehicle_builder.gd")
const TexScript := preload("res://scripts/world/textures.gd")
const GeoScript := preload("res://scripts/core/geo.gd")
const SkinScript := preload("res://scripts/vehicles/vehicle_skin.gd")
const VirtualInput := preload("res://scripts/core/virtual_input.gd")
const WeaponsScript := preload("res://scripts/combat/weapons.gd")
const ShopScript := preload("res://scripts/core/shop.gd")
const FoldersScript := preload("res://scripts/core/skin_folders.gd")
const PlayerSkinScript := preload("res://scripts/player/player_skin.gd")

var _failures := 0


func _initialize() -> void:
    _test_input_actions()
    _test_player_health()
    _test_world_builder()
    _test_city_graph()
    _test_world_layout()
    _test_weapons_and_shop()
    _test_skin_folders()
    _test_vehicle_data()
    _test_vehicle_skins()
    _test_model_wheels()
    _test_virtual_input()
    _test_vehicle()
    _test_npcs()
    _test_visuals()
    print("Resultado: ", "TUDO OK" if _failures == 0 else "%d falha(s)" % _failures)
    quit(1 if _failures > 0 else 0)


func _check(condition: bool, label: String) -> void:
    if condition:
        print("  [ok]    ", label)
    else:
        print("  [FALHA] ", label)
        _failures += 1


func _test_input_actions() -> void:
    print("Entrada")
    InputScript.register()
    InputScript.register() # idempotência
    for action in ["move_forward", "move_back", "move_left", "move_right", "jump", "sprint", "crouch", "interact", "pause", "map", "look_left"]:
        _check(InputMap.has_action(action), "ação registrada: " + action)
    _check(InputMap.action_get_events("jump").size() == 2, "jump tem teclado + gamepad sem duplicar")


func _test_player_health() -> void:
    print("Jogador")
    var player := PlayerScript.new()
    player.spawn_position = Vector3(0.0, 0.1, 0.0)
    root.add_child(player)
    var deaths := [0]
    player.died.connect(func() -> void: deaths[0] += 1)

    player.take_damage(30.0)
    _check(is_equal_approx(player.health, 70.0), "dano reduz a vida")
    player.take_damage(-5.0)
    _check(is_equal_approx(player.health, 70.0), "dano negativo é ignorado")
    player.heal(1000.0)
    _check(is_equal_approx(player.health, player.max_health), "cura respeita o máximo")
    player.take_damage(1000.0)
    _check(deaths[0] == 1, "morte emite sinal uma vez")
    _check(is_equal_approx(player.health, player.max_health), "respawn restaura a vida")
    player.queue_free()


func _test_world_builder() -> void:
    print("Mundo")
    var world := WorldScript.new()
    root.add_child(world)
    world.build()
    var blocks := GraphScript.total_blocks()
    _check(world.building_count >= (blocks - world.park_count) * 4, "pelo menos 4 construções por quarteirão não-praça")
    _check(world.get_child_count() > 40, "cria malhas de quarteirões, ruas e chão")
    _check(world.building_rects.size() == world.building_count, "dados do mapa: um retângulo por prédio")
    _check(world.park_rects.size() == world.park_count, "dados do mapa: um retângulo por praça")
    _check(WorldScript.LAMP_OFFSET > 17.0 and WorldScript.LAMP_OFFSET < 20.0, "postes ficam na calçada (17 a 20 m), não na rua")
    _check(GraphScript.RING > 17.0 and GraphScript.RING < 20.0, "pedestres andam na calçada (17 a 20 m)")
    var again := WorldScript.new()
    root.add_child(again)
    again.build()
    _check(again.building_count == world.building_count, "geração é determinística")
    world.queue_free()
    again.queue_free()


func _test_city_graph() -> void:
    print("Grafo da cidade")
    _check(WorldScript.BLOCK_SIZE + WorldScript.ROAD_WIDTH == GraphScript.PITCH, "constantes batem com o world_builder")
    var ok := true
    for i in range(GraphScript.BLOCK_MIN, GraphScript.BLOCK_MAX + 1):
        for j in range(GraphScript.BLOCK_MIN, GraphScript.BLOCK_MAX + 1):
            for c in 4:
                var neighbors := GraphScript.ped_neighbors(i, j, c)
                if neighbors.size() < 2:
                    ok = false
                for n: Vector3i in neighbors:
                    if not GraphScript.block_in_range(n.x, n.y):
                        ok = false
    _check(ok, "todo canto de calçada tem vizinhos válidos")
    var a := GraphScript.ped_corner_pos(0, 0, 1)
    var cross := GraphScript.ped_neighbors(0, 0, 1)
    var crossing_ok := false
    for n: Vector3i in cross:
        if n.x != 0 or n.y != 0:
            var b := GraphScript.ped_corner_pos(n.x, n.y, n.z)
            crossing_ok = absf(a.distance_to(b) - (GraphScript.PITCH - 2.0 * GraphScript.RING)) < 0.01
    _check(crossing_ok, "travessia de rua liga calçada a calçada (14,4 m)")
    var route := GraphScript.route(Vector2(5.0, 5.0), Vector2(-100.0, 90.0))
    _check(route.size() == 7, "rota do GPS tem 7 pontos")
    _check(route[0] == Vector2(5.0, 5.0) and route[6] == Vector2(-100.0, 90.0), "rota começa e termina nos pontos pedidos")
    var expected := 0
    for ci in GraphScript.city_count():
        var rmin := GraphScript.road_min(ci)
        var rmax := GraphScript.road_max(ci)
        var nx := rmax.x - rmin.x + 1
        var nz := rmax.y - rmin.y + 1
        expected += 2 * (nx * (nz - 1) + nz * (nx - 1))
    for hw: Dictionary in GraphScript.HIGHWAYS:
        var f: Vector2i = hw["from"]
        var t: Vector2i = hw["to"]
        expected += 2 * maxi(absi(t.x - f.x), absi(t.y - f.y))
    var starts := GraphScript.traffic_starts_in_range(Vector3.ZERO, 0.0, 50000.0)
    _check(starts.size() == expected, "trechos de via: cidades + rodovias, 2 sentidos (%d)" % expected)


func _test_world_layout() -> void:
    print("Cidades e rodovias")
    _check(GraphScript.city_count() >= 4, "há pelo menos 4 cidades")
    _check(GraphScript.BLOCK_MIN == GraphScript.CITIES[0]["bmin"].x and GraphScript.BLOCK_MAX == GraphScript.CITIES[0]["bmax"].x, "constantes da cidade principal batem com CITIES[0]")
    var ok := true
    for hw: Dictionary in GraphScript.HIGHWAYS:
        var f: Vector2i = hw["from"]
        var t: Vector2i = hw["to"]
        if not GraphScript.road_node_exists(f.x, f.y) or not GraphScript.road_node_exists(t.x, t.y):
            ok = false
        var mid := (f + t) / 2
        if not GraphScript.road_node_exists(mid.x, mid.y):
            ok = false
        var pts := GraphScript.highway_world_points(hw)
        if GraphScript.city_at(pts[0]) != 0 or GraphScript.city_at(pts[1]) != int(hw["city"]):
            ok = false
    _check(ok, "toda rodovia liga um cruzamento da cidade principal a um da outra cidade")
    # rota entre cidades começa e termina nos pontos pedidos
    var a := GraphScript.city_center(0)
    var b := GraphScript.city_center(1)
    var route := GraphScript.route(a, b)
    _check(route[0] == a and route[route.size() - 1] == b and route.size() > 7, "rota entre cidades passa pela rodovia")
    var between := GraphScript.route(GraphScript.city_center(2), GraphScript.city_center(3))
    _check(between.size() > 14, "rota entre duas cidades menores passa pela cidade principal")
    _check(GraphScript.place_name(GraphScript.city_center(1)) == "Porto Azul", "nome do lugar: cidade")
    var grounds := GraphScript.ground_rects()
    _check(grounds.size() == 4, "o chão tem 4 pedaços separados pelos rios")
    var river_ok := true
    for hw: Dictionary in GraphScript.HIGHWAYS:
        var pts2 := GraphScript.highway_world_points(hw)
        var mid2: Vector2 = (pts2[0] + pts2[1]) * 0.5
        for g in grounds:
            if g.has_point(mid2):
                river_ok = false # o meio da rodovia deve cair no rio (ponte)
    _check(river_ok, "o meio de cada rodovia é uma ponte sobre o rio")


func _test_weapons_and_shop() -> void:
    print("Armas e loja")
    var complete := true
    for id: String in WeaponsScript.ORDER:
        var w: Dictionary = WeaponsScript.DATA[id]
        for key in ["name", "price", "kind", "anim", "damage", "range", "cooldown", "knock", "desc"]:
            if not w.has(key):
                complete = false
        if w["kind"] == "gun" and not (w.has("spread") and w.has("pellets")):
            complete = false
    _check(complete, "todas as armas têm os campos necessários")
    _check(WeaponsScript.price("fists") == 0 and WeaponsScript.build_model("fists") == null, "punhos são grátis e não têm modelo")
    var model := WeaponsScript.build_model("pistol")
    _check(model != null and model.get_child_count() > 0, "modelo da pistola é criado")
    if model != null:
        model.free()
    var ids := ShopScript.car_ids()
    _check(ids.size() > 50 and not ids.has("police"), "loja vende os carros (menos viatura e ambulância)")
    var sorted_ok := true
    for i in range(1, ids.size()):
        if ShopScript.car_price(ids[i - 1]) > ShopScript.car_price(ids[i]):
            sorted_ok = false
    _check(sorted_ok, "carros ordenados do mais barato ao mais caro")
    _check(ShopScript.car_price("hatch") >= 3000, "preço mínimo de carro")
    _check(ShopScript.fmt_money(25000) == "R$ 25.000" and ShopScript.fmt_money(950) == "R$ 950", "formatação do dinheiro")
    # pedestre reage a golpes
    var ped := PedScript.new()
    root.add_child(ped)
    var hp := ped.health
    ped.hit_by(null, 5.0, Vector3.FORWARD)
    _check(ped.health < hp and ped.state == PedScript.State.STAGGER, "pedestre leva dano e cambaleia")
    ped.hit_by(null, 1000.0, Vector3.FORWARD)
    _check(ped.state == PedScript.State.DEAD, "pedestre cai quando a vida acaba")
    ped.queue_free()


func _test_skin_folders() -> void:
    print("Pasta de skins (jogo instalado)")
    FoldersScript.setup()
    _check(DirAccess.dir_exists_absolute(FoldersScript.cars_dir().path_join("hatch")), "pasta de skins cria uma pasta por carro")
    _check(DirAccess.dir_exists_absolute(FoldersScript.player_dir()), "pasta de skins cria a pasta do jogador")
    _check(FileAccess.file_exists(FoldersScript.root_dir().path_join("LEIA-ME.txt")), "LEIA-ME.txt criado")
    var path := FoldersScript.player_dir().path_join("outfit.json")
    var existed := FileAccess.file_exists(path)
    if not existed:
        var f := FileAccess.open(path, FileAccess.WRITE)
        f.store_string('{"shirt": "#ff0000", "hat": "none", "backpack": false, "scale": 5}')
        f.close()
        var o := PlayerSkinScript.outfit_overrides()
        _check(o.get("shirt") == Color(1, 0, 0) and o.has("hat") and o["hat"] == null and o["scale"] == 1.6, "outfit.json troca a roupa do jogador")
        DirAccess.remove_absolute(path)
    _check(PlayerSkinScript.outfit_overrides().is_empty() or existed, "sem outfit.json não muda nada")


func _test_vehicle_data() -> void:
    print("Dados dos veículos")
    var seen_names := {}
    for id: String in DataScript.IDS:
        var d: Dictionary = DataScript.TYPES[id]
        var nm := str(d["name"])
        _check(not seen_names.has(nm), "nome de modelo único: " + nm)
        seen_names[nm] = true
        var complete := true
        for key in ["name", "mass", "power", "awd", "max_speed", "steer", "size", "cabin", "cabin_z", "wheel_radius", "suspension", "colors"]:
            if not d.has(key):
                complete = false
        _check(complete, "tipo completo: " + id)


func _test_model_wheels() -> void:
    print("Rodas dos modelos 3D")
    for id: String in ["hatch", "compact_suv", "sedan", "sport"]:
        if not SkinScript.has_wheel_layout(id):
            print("  (modelo %s sem rodas separadas ou ainda não importado; pulando)" % id)
            continue
        var lay := SkinScript.wheel_layout(id, DataScript.TYPES[id])
        _check(lay.size() == 4, "%s: layout com 4 rodas" % id)
        var car = FactoryScript.create(id)
        root.add_child(car)
        var steering := 0
        var with_visual := 0
        for child in car.get_children():
            if child is VehicleWheel3D:
                var w := child as VehicleWheel3D
                if w.use_as_steering:
                    steering += 1
                    _check(w.position.z < 0.0, "%s: roda que esterça fica na frente" % id)
                if w.get_child_count() > 0:
                    with_visual += 1
                _check(w.wheel_radius > 0.2 and w.wheel_radius < 0.55, "%s: raio de roda plausível (%.2f)" % [id, w.wheel_radius])
        _check(steering == 2, "%s: 2 rodas esterçam" % id)
        _check(with_visual == 4, "%s: 4 rodas com a malha do modelo" % id)
        car.queue_free()


func _test_virtual_input() -> void:
    print("Entrada virtual (botões da tela)")
    VirtualInput.accel = 1.0
    VirtualInput.steer_left = 1.0
    VirtualInput.horn = true
    VirtualInput.clear()
    _check(VirtualInput.accel == 0.0 and VirtualInput.steer_left == 0.0 and not VirtualInput.horn, "clear() zera os comandos")


func _test_vehicle_skins() -> void:
    print("Skins de veículos")
    for id: String in DataScript.IDS:
        _check(str(DataScript.TYPES[id].get("id", "")) == id, "campo id confere: " + id)
    for id: String in DataScript.TRAFFIC_MIX:
        _check(DataScript.TYPES.has(id), "trânsito usa tipo existente: " + id)
    for id: String in ["hatch", "compact_suv", "sedan", "sport"]:
        if SkinScript.has_model(id):
            _check(SkinScript.has_own_wheels(id), "modelo %s tem rodas próprias (wheel_*)" % id)
            var holder := SkinScript.instance_model(id, DataScript.TYPES[id])
            _check(holder != null, "modelo %s instancia" % id)
            if holder != null:
                holder.free()
        else:
            print("  (modelo %s ainda não importado; pulando)" % id)
    _check(SkinScript.texture_for("nao_existe") == null, "sem imagem de skin devolve null")
    _check(not SkinScript.has_model("nao_existe"), "sem modelo de skin devolve falso")
    _check(not SkinScript.has_own_wheels("nao_existe"), "sem modelo, sem rodas próprias")


func _test_vehicle() -> void:
    print("Veículo")
    var vehicle = FactoryScript.create("sedan")
    root.add_child(vehicle)
    var wheels := 0
    for child in vehicle.get_children():
        if child is VehicleWheel3D:
            wheels += 1
    _check(wheels == 4, "tem 4 rodas")
    _check(vehicle.is_in_group("enterable") and vehicle.is_in_group("vehicles"), "está nos grupos enterable/vehicles")
    _check(vehicle.can_enter(), "livre pode ser ocupado")
    var player := PlayerScript.new()
    root.add_child(player)
    vehicle.set_driver(player)
    _check(not vehicle.can_enter(), "ocupado não pode ser ocupado de novo")
    vehicle.clear_driver()
    _check(vehicle.can_enter(), "libera ao sair")
    var unknown = FactoryScript.create("tipo_inexistente")
    root.add_child(unknown)
    _check(unknown.type_id == "sedan", "tipo desconhecido vira sedan")
    vehicle.queue_free()
    unknown.queue_free()
    player.queue_free()


func _test_npcs() -> void:
    print("NPCs")
    var ped = PedScript.new()
    ped.place(Vector3i(0, 0, 0))
    root.add_child(ped)
    _check(ped.target != Vector3.ZERO, "pedestre escolhe um destino")
    ped.queue_free()
    var car = TrafficScript.new()
    car.setup("suv", Color(0.2, 0.2, 0.2))
    car.start(0, 0, Vector2i(1, 0))
    root.add_child(car)
    _check(car.can_enter() and car.get_display_name() == "SUV", "carro do trânsito é entrável")
    car.queue_free()


func _test_visuals() -> void:
    print("Visuais")
    var holder := Node3D.new()
    root.add_child(holder)
    var rig := HumanoidScript.build(holder, HumanoidScript.random_outfit())
    var skeleton: Skeleton3D = rig["skeleton"]
    _check(skeleton.get_bone_count() == 11, "pessoa tem esqueleto com 11 ossos")
    HumanoidScript.animate(rig, 1.0, 1.0)
    _check(skeleton.get_bone_pose_rotation(HumanoidScript.THIGH_L).get_angle() > 0.1, "animação de andar mexe a coxa")
    _check(skeleton.get_bone_pose_rotation(HumanoidScript.SHIN_L).get_angle() > 0.01, "animação dobra o joelho")
    for id: String in DataScript.IDS:
        var car := Node3D.new()
        holder.add_child(car)
        var parts := BuilderScript.build(car, DataScript.TYPES[id], Color.RED, true)
        var meshes := 0
        for child in car.get_children():
            if child is MeshInstance3D:
                meshes += 1
        _check(parts.has("body_mat") and meshes >= 5, "carro detalhado montado: " + id)
    for tex_name in ["facade_glass", "facade_brick", "facade_concrete", "storefront", "house_wall", "roof_tile", "asphalt", "grass", "concrete"]:
        _check(TexScript.texture(tex_name).get_width() > 0, "textura gerada: " + tex_name)
    var st := GeoScript.new_st()
    GeoScript.box(st, Vector3.ZERO, Vector3.ONE, Vector2.ONE, 0.0, Color.WHITE)
    _check(GeoScript.has_data(st), "geometria de caixa gera triângulos")
    holder.queue_free()
